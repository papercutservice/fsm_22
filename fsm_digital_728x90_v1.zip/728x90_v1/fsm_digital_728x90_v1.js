(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"fsm_digital_728x90_v1_atlas_1", frames: [[0,330,198,39],[1809,263,224,51],[299,330,100,38],[1218,147,529,97],[1896,147,147,83],[0,139,541,189],[1585,263,222,70],[543,265,1040,66],[0,0,1165,137],[543,147,673,116],[401,330,66,56],[1749,147,145,114],[2010,316,38,37],[200,330,97,76],[1809,316,110,95],[469,330,63,52],[1921,316,87,86],[1167,0,865,145]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_45 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_44 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_43 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_42 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_41 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_40 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_39 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_33 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_32 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Image = function() {
	this.initialize(ss["fsm_digital_728x90_v1_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t3summer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_summer
	this.instance = new lib.CachedBmp_45();
	this.instance.setTransform(-49.45,-9.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-49.4,-9.6,99,19.5);


(lib.t3meals = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_meals
	this.instance = new lib.CachedBmp_44();
	this.instance.setTransform(-56.05,-12.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-12.7,112,25.5);


(lib.t3free = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_free
	this.instance = new lib.CachedBmp_43();
	this.instance.setTransform(-25,-9.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25,-9.4,50,19);


(lib.t3bars = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_bars
	this.instance = new lib.CachedBmp_42();
	this.instance.setTransform(-132.2,-24.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-132.2,-24.3,264.5,48.5);


(lib.t2logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2_logos
	this.instance = new lib.CachedBmp_41();
	this.instance.setTransform(37.05,-17.75,0.5,0.5);

	this.instance_1 = new lib.Image();
	this.instance_1.setTransform(-117.1,-13.1,0.1568,0.1568);

	this.instance_2 = new lib.CachedBmp_40();
	this.instance_2.setTransform(-135.25,-47.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135.2,-47.1,270.5,94.5);


(lib.t2button = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2_button
	this.instance = new lib.CachedBmp_39();
	this.instance.setTransform(-55.45,-17.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55.4,-17.5,111,35);


(lib.t2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2
	this.instance = new lib.CachedBmp_38();
	this.instance.setTransform(-262,-18.1,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_37();
	this.instance_1.setTransform(-291.15,-34.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-291.1,-34.1,582.5,68.5);


(lib.t1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt1
	this.instance = new lib.CachedBmp_36();
	this.instance.setTransform(-168.25,-29,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-168.2,-29,336.5,58);


(lib.Symbol14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_dark_blue
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#224EA2").s().p("AEXGBQhZgVg2hDIgggrQgTgbgQgOQgjgfg6gLQghgGhLgCQhRgDg7gJQhLgNg6gaQhDgdgwgyQg0g0gShBQgIgdgCgnIgCggQgBgUAEgMQACgHAHgIIAMgNQASgXAOgOQAjghAtgZQBWguBogGQBVgFBjAUQBLAPBnAjQCLAuBZAuQB3A/BLBSQBOBXAPBdQANBVgtBRQgsBQhOAiQgxAWg1AAQggAAgigIg");
	this.shape.setTransform(-0.0058,0.0091);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.3,-39.3,120.69999999999999,78.6);


(lib.Symbol13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_light_blue
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#568DCA").s().p("ACBHDQgxgQgRgXQgPgTgEgjQgEggALhtQAIhWgVgxQgQglgfgbQgggagogLQgsgMgwAKQgXAEgVAJQgLAFgVAEIgfAKIgZAJQgkANgQAEQgdAJgYABQgkACgfgOQghgQgNgdQgKgUACgZQACgXALgWQAPgeAqgsQBhhgBxhNQA5gnA8ggQAcgQASgBQATgCAlgNQA6gOA7AAQAYAAAOAGQARAIATAfICoEKQANATAOAHQAIAEAKAIIASANQAIAFAQAHIAZALQAsAZAYAnQAXAjACAwQACAbgGAdIgHAcQgCAFgDAFIgGAKQgGAMgIAUIgMAgIgaA/QgYA0gRAUQgYAcgoAUQgbANgxARQgvAQgZAAIgEAAQgbAAgtgOg");
	this.shape.setTransform(-0.0013,0.028);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53.2,-46.5,106.5,93.1);


(lib.Symbol12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_red
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EA6241").s().p("AAAJUQgJgGgSgPQhYhMhtgsQg2gWg6gNQgcgGgdgEIhBgFQgngDgZgHQgjgLgYgYQgRgSgPgcQgPgegGgqQgOhiAyhZQA7hnCJhHQAdgOA8gaQAHgDAIgGQAIgFANgEIAWgIQA9gWAlgWQAegQAPgSQANgQAIgNQAXgigEgaQgCgRgPgZQgSgegEgLQgIgaAJgbQAKgcAYgVQAfgbA8gSQBJgVBIgBQATAAAtAEQAoAEAYgBQAcgCAhAIQASAFAmANQA7AWAtAcQBdA6AbBOIAGASQALAygXAmQgJAOgRAQIgdAbQg9A4gjB+IgcBlQgRA7gUAmQgQAfgdAoIgzBDQhIBtgnA1QhDBchFAsQgTAMgMABIgEAAQgOAAgPgJg");
	this.shape.setTransform(-0.013,0.0348);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.8,-60.4,127.69999999999999,120.9);


(lib.Symbol11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_green
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgxFJQg1gFgpgbQgfgUgngtQgwg3gRgPIgfgbQgPgOgKgTQgZg0gOgjQhDivBAhcIAHgJQBPhhDYAqQC0AjDkB7QArAXAUApQAWAsgUArQgNAbggAgIg4A1QgQAQgWAcIgkAtIgLANQhKBUhaAcQglALgkAAIgZgBg");
	this.shape.setTransform(0.0448,0.0302);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40.8,-32.9,81.69999999999999,65.9);


(lib.Symbol10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_yellow
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FCB11D").s().p("ABZFrImFgSQgsgCgWgEQgjgHgZgSQgdgUgQgnQgSgqADg1QACglAShCIANgwQAHgcAAgSQABgNgEgLIgJgTQgKgbAGgkQAKg1AdgnQAXgdAggTQAVgLAmgOQCbg2BbgDQCDgGBNBUQANAOA5BUQAqA8AkATQANAIBHARQAzANAXAfQAZAkAIBHQAFAvgCBZQgBArgHAYQgWBEhLAPQhDANhRABIgUABQgvAAhOgEg");
	this.shape.setTransform(0.0321,0.0172);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.7,-36.6,97.5,73.30000000000001);


(lib.Symbol9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus
	this.instance = new lib.CachedBmp_35();
	this.instance.setTransform(-16.45,-13.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.4,-13.9,33,28);


(lib.Symbol7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_carrot
	this.instance = new lib.CachedBmp_34();
	this.instance.setTransform(-36.2,-28.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.2,-28.5,72.5,57);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_ritz
	this.instance = new lib.CachedBmp_33();
	this.instance.setTransform(-9.35,-9.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.3,-9.2,19,18.5);


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_banana
	this.instance = new lib.CachedBmp_32();
	this.instance.setTransform(-24.35,-19,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24.3,-19,48.5,38);


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_milk
	this.instance = new lib.CachedBmp_31();
	this.instance.setTransform(-27.45,-23.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.4,-23.8,55,47.5);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_orange
	this.instance = new lib.CachedBmp_30();
	this.instance.setTransform(-15.75,-13,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.7,-13,31.5,26);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_apple
	this.instance = new lib.CachedBmp_29();
	this.instance.setTransform(-21.8,-21.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21.8,-21.5,43.5,43);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_apple_slice
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#224EA2").s().p("AAFBUQgrgJgkgWQgkgWgUgiQgWgmAKgmQACgGAHAAQAEgCAEACIAwAbQAWANAKANIANASQAJAQAEACQAEACAGgGIAJgHQAJgKAJgKQAFgGAHAEQAtAZA0ANIACgCQAFgHAHAFQAIAFgFAGQgdAogjASQgYANgbAAQgMAAgMgDgAhkAJQAcAgAuARQA4AUAjgPQAbgMAYgcQgugOgrgVQgUAYgQAIQgLAFgKgJQgGgFgIgMIgQgYQgJgJgNgJQgOgKgfgSQgEAtAfAjg");
	this.shape.setTransform(-0.4812,-1.5964);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAUBNQhKgGgqgnQgZgXgJgeQgFgRABgRIAAgBIABgHIABgEQADgHADgCQAEgBAGABQB1AOBpA7QAgAQgDAUQgCAKgKAIQgcAbg1AAIgWgBg");
	this.shape_1.setTransform(1.5006,2.5342);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15,-10.3,30.1,20.6);


(lib.Path_19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgTA+QgBgHABgKIAEgRIAMg6IADgQQABgKADgGQADgFAHABQAGACAAAGQABAGgCAKIgEAPIgLA7IgDAQQgBAKgEAFQgDAEgFAAQgHAAAAgFg");
	this.shape.setTransform(2.06,6.7339);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_19, new cjs.Rectangle(0,0,4.1,13.5), null);


(lib.Path_18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgYBOQABgQAFgXIAJgmIAPhPQACgIAJABQAJACgCAJIgWByIgHAnQgDAHgIAAQgIAAAAgIg");
	this.shape.setTransform(2.4593,8.6388);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_18, new cjs.Rectangle(0,0.1,4.9,17.2), null);


(lib.Path_16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgVA6QgBgSAKgpQAHgbAJgcQADgIAJABQAIACgDAIQgIAcgHAaIgEAcQgCASgEAKQgCAGgHABIgBAAQgGAAgBgGg");
	this.shape.setTransform(2.2298,6.3709);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_16, new cjs.Rectangle(0.1,0,4.4,12.8), null);


(lib.Path_13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgQBCQgIgCACgIIANg5QAIgjAHgXQACgHAIABQAIAAgBAHQgEAZgJAiIgQA7QgBAGgGAAIgDAAg");
	this.shape.setTransform(2.3115,6.6107);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_13, new cjs.Rectangle(0,0,4.7,13.3), null);


(lib.Path_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgkBcQAAgLAEgPIAHgZIAPgsQAOguAQgiIAAgBQgCgHAIgEQAFgCAEADIABABQACABgBAFIgsCHIgGAYQgEAOgFAIQgDADgFAAQgFAAgBgFg");
	this.shape.setTransform(3.6889,9.735);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9, new cjs.Rectangle(0,0,7.4,19.5), null);


(lib.Path_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgPA0QgIAAABgHQAJguARgsQADgIAJACQAJABgDAIQgQAngLAxQgBAGgHAAIgCAAg");
	this.shape.setTransform(2.2529,5.2643);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6, new cjs.Rectangle(0,0,4.6,10.5), null);


(lib.Path_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgaBZQgHgCABgHIAOgpIANgnQAMgsAJgmQACgIAIABQAJACgCAIQgIAlgOAuIgMAqQgJAcgGALQgDAFgEAAIgDgBg");
	this.shape.setTransform(3.2808,8.9729);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0,0,6.6,18), null);


(lib.Symbol8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_lines
	this.instance = new lib.Path_3();
	this.instance.setTransform(30.75,8.05,1,1,0,0,0,3.2,9);
	this.instance.compositeOperation = "multiply";

	this.instance_1 = new lib.Path_6();
	this.instance_1.setTransform(22.3,-4,1,1,0,0,0,2.2,5.2);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_9();
	this.instance_2.setTransform(8.4,-2.9,1,1,0,0,0,3.7,9.7);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_13();
	this.instance_3.setTransform(-6.2,-0.3,1,1,0,0,0,2.3,6.6);
	this.instance_3.compositeOperation = "multiply";

	this.instance_4 = new lib.Path_16();
	this.instance_4.setTransform(-17.65,-5.6,1,1,0,0,0,2.2,6.4);
	this.instance_4.compositeOperation = "multiply";

	this.instance_5 = new lib.Path_18();
	this.instance_5.setTransform(-31.6,9.3,1,1,0,0,0,2.5,8.7);
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.Path_19();
	this.instance_6.setTransform(-28.05,-11.1,1,1,0,0,0,2,6.7);
	this.instance_6.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.1,-17.8,68.30000000000001,35.7);


// stage content:
(lib.fsm_digital_728x90_v1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [448];
	// timeline functions:
	this.frame_448 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(448).call(this.frame_448).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Eg43AHCIAAuDMBxvAAAIAAODgEg4xAG8MBxjAAAIAAt3MhxjAAAg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	// Symbol_1
	this.instance = new lib.Symbol1("synched",0);
	this.instance.setTransform(64.5,-51.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:96.3,y:16.45,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:14.9992,x:95.3,y:12.85,startPosition:154},124,cjs.Ease.quadInOut).to({rotation:0,x:74.55,y:-22.6,startPosition:174},20,cjs.Ease.quartInOut).to({startPosition:396},222,cjs.Ease.quadInOut).to({rotation:59.9996,x:-28.35,y:52.3,startPosition:438},42,cjs.Ease.quartInOut).wait(11));

	// Symbol_2
	this.instance_1 = new lib.Symbol2("synched",0);
	this.instance_1.setTransform(145.6,-40.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:156.05,y:30.5,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:14.9992,y:26.5,startPosition:154},124,cjs.Ease.quadInOut).to({rotation:0,x:82.6,y:23.25,startPosition:174},20,cjs.Ease.quartInOut).to({rotation:14.9992,x:77.3,startPosition:396},222,cjs.Ease.quadInOut).to({rotation:0,x:117.05,y:-27.15,startPosition:438},42,cjs.Ease.quartInOut).wait(11));

	// Symbol_3
	this.instance_2 = new lib.Symbol3("synched",0);
	this.instance_2.setTransform(528.3,-23.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:584,y:22.35,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:14.9992,x:577.85,startPosition:154},124,cjs.Ease.quadInOut).to({rotation:0,x:645.45,y:6.05,startPosition:174},20,cjs.Ease.quartInOut).to({rotation:44.9994,x:616.75,y:6.9,startPosition:396},222,cjs.Ease.quadInOut).to({rotation:0,x:289.65,y:-18.65,startPosition:438},42,cjs.Ease.quartInOut).wait(11));

	// Symbol_4
	this.instance_3 = new lib.Symbol4("synched",0);
	this.instance_3.setTransform(639.5,119);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:622.85,y:66.95,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:6.7254,x:623.85,y:71.85,startPosition:154},124,cjs.Ease.quadInOut).to({rotation:0,x:652.95,y:59.2,startPosition:174},20,cjs.Ease.quartInOut).to({rotation:14.9992,startPosition:396},222,cjs.Ease.quadInOut).to({rotation:0,x:622.85,y:116.35,startPosition:438},42,cjs.Ease.quartInOut).wait(11));

	// Symbol_5
	this.instance_4 = new lib.Symbol5("synched",0);
	this.instance_4.setTransform(105.6,123.85);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({x:104.6,y:67,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:-14.9992,y:60,startPosition:154},124,cjs.Ease.quadInOut).to({rotation:0,x:100.1,y:76.4,startPosition:174},20,cjs.Ease.quartInOut).to({rotation:-7.4884,x:107.85,startPosition:396},222,cjs.Ease.quadInOut).to({rotation:105.0002,x:128.95,y:138.2,startPosition:438},42,cjs.Ease.quartInOut).wait(11));

	// Symbol_6
	this.instance_5 = new lib.Symbol6("synched",0);
	this.instance_5.setTransform(326.8,-19.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:336.4,y:11.8,startPosition:30},30,cjs.Ease.quartInOut).to({x:341.75,startPosition:154},124,cjs.Ease.quadInOut).to({x:336.4,y:-34,startPosition:174},20,cjs.Ease.quartInOut).to({startPosition:396},222,cjs.Ease.quadInOut).to({x:431.85,y:-22.4,startPosition:438},42,cjs.Ease.quartInOut).wait(11));

	// Symbol_7
	this.instance_6 = new lib.Symbol7("synched",0);
	this.instance_6.setTransform(539.4,123.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({x:529.15,y:79.9,startPosition:30},30,cjs.Ease.quartInOut).to({y:81.9,startPosition:154},124,cjs.Ease.quadInOut).to({x:510.6,y:127.55,startPosition:174},20,cjs.Ease.quartInOut).to({startPosition:396},222,cjs.Ease.quadInOut).to({x:516.15,y:126.9,startPosition:438},42,cjs.Ease.quartInOut).wait(11));

	// Symbol_8
	this.instance_7 = new lib.Symbol8("synched",0);
	this.instance_7.setTransform(184.85,125.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({x:201.5,y:87,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:-7.2151,x:199.05,y:88.45,startPosition:154},124,cjs.Ease.quadInOut).to({rotation:0,x:192.5,y:113.25,startPosition:174},20,cjs.Ease.quartInOut).to({startPosition:396},222,cjs.Ease.quadInOut).to({x:201.5,y:116.15,startPosition:438},42,cjs.Ease.quartInOut).wait(11));

	// Symbol_9
	this.instance_8 = new lib.Symbol9("synched",0);
	this.instance_8.setTransform(462.85,118.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({x:452,y:74.9,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:14.9992,y:80.45,startPosition:154},124,cjs.Ease.quadInOut).to({rotation:0,x:376.5,y:128.65,startPosition:174},20,cjs.Ease.quartInOut).to({startPosition:396},222,cjs.Ease.quadInOut).to({rotation:29.9992,x:433.25,y:113.7,startPosition:438},42,cjs.Ease.quartInOut).wait(11));

	// Symbol_10
	this.instance_9 = new lib.Symbol10("synched",0);
	this.instance_9.setTransform(0.7,103.35);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({x:43.6,y:103.6,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:-4.7378,x:39.9,y:99.5,startPosition:154},124,cjs.Ease.quadInOut).to({rotation:0,x:32.5,y:103.35,startPosition:174},20,cjs.Ease.quartInOut).to({x:24.15,y:96.4,startPosition:396},222,cjs.Ease.quadInOut).to({x:3.95,y:130.05,startPosition:438},42,cjs.Ease.quartInOut).wait(11));

	// Symbol_11
	this.instance_10 = new lib.Symbol11("synched",0);
	this.instance_10.setTransform(255.05,115.15);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({y:103.6,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:14.9992,x:259.55,y:108.9,startPosition:154},124,cjs.Ease.quadInOut).to({rotation:0,x:292.15,y:131.95,startPosition:174},20,cjs.Ease.quartInOut).to({startPosition:396},222,cjs.Ease.quadInOut).to({x:323.75,y:138.3,startPosition:438},42,cjs.Ease.quartInOut).wait(11));

	// Symbol_12
	this.instance_11 = new lib.Symbol12("synched",0);
	this.instance_11.setTransform(758.35,91.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({x:721.85,y:79.5,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:-3.2435,x:705.85,y:94.95,startPosition:154},124,cjs.Ease.quadInOut).to({rotation:0,x:744.25,y:79.5,startPosition:174},20,cjs.Ease.quartInOut).to({rotation:-7.7389,x:725.05,y:95.75,startPosition:396},222,cjs.Ease.quadInOut).to({rotation:0,x:791.85,y:95.7,startPosition:438},42,cjs.Ease.quartInOut).wait(11));

	// Symbol_13
	this.instance_12 = new lib.Symbol13("synched",0);
	this.instance_12.setTransform(618.6,-37.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({x:634.6,y:-15.3,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:-4.4773,x:641.15,startPosition:154},124,cjs.Ease.quadInOut).to({rotation:0,x:678.75,y:-27.5,startPosition:174},20,cjs.Ease.quartInOut).to({x:673.5,y:-20.95,startPosition:396},222,cjs.Ease.quadInOut).to({x:731.2,y:-54.3,startPosition:438},42,cjs.Ease.quartInOut).wait(11));

	// Symbol_14
	this.instance_13 = new lib.Symbol14("synched",0);
	this.instance_13.setTransform(-34.55,-22.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({x:-5.1,y:9.15,startPosition:30},30,cjs.Ease.quartInOut).to({regX:-0.1,regY:0.1,rotation:-9.2542,x:-9.6,y:3.65,startPosition:154},124,cjs.Ease.quadInOut).to({regX:0,regY:0,rotation:0,x:-12.8,y:-3.95,startPosition:174},20,cjs.Ease.quartInOut).to({rotation:6.2212,x:-18.5,startPosition:396},222,cjs.Ease.quadInOut).to({rotation:0,x:-20.4,y:-41.2,startPosition:438},42,cjs.Ease.quartInOut).wait(11));

	// t3_bars
	this.instance_14 = new lib.t3bars("synched",0);
	this.instance_14.setTransform(179.35,28.05);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(426).to({_off:false},0).wait(1).to({y:35.5287,alpha:0.4491},0).wait(1).to({y:38.4002,alpha:0.6049},0).wait(1).to({y:40.3601,alpha:0.7092},0).wait(1).to({y:41.8327,alpha:0.7863},0).wait(1).to({y:42.9804,alpha:0.8454},0).wait(1).to({y:43.8889,alpha:0.8917},0).wait(1).to({y:44.6064,alpha:0.9276},0).wait(1).to({y:45.1644,alpha:0.9551},0).wait(1).to({y:45.5811,alpha:0.9753},0).wait(1).to({y:45.8714,alpha:0.9893},0).wait(1).to({y:46.0428,alpha:0.9973},0).wait(1).to({y:46.1,alpha:1},0).wait(1).to({startPosition:0},0).wait(10));

	// t3_meals
	this.instance_15 = new lib.t3meals("synched",0);
	this.instance_15.setTransform(255.45,28.75);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(421).to({_off:false},0).wait(1).to({y:36.2287,alpha:0.4491},0).wait(1).to({y:39.1002,alpha:0.6049},0).wait(1).to({y:41.0601,alpha:0.7092},0).wait(1).to({y:42.5327,alpha:0.7863},0).wait(1).to({y:43.6804,alpha:0.8454},0).wait(1).to({y:44.5889,alpha:0.8917},0).wait(1).to({y:45.3064,alpha:0.9276},0).wait(1).to({y:45.8644,alpha:0.9551},0).wait(1).to({y:46.2811,alpha:0.9753},0).wait(1).to({y:46.5714,alpha:0.9893},0).wait(1).to({y:46.7428,alpha:0.9973},0).wait(1).to({y:46.8,alpha:1},0).wait(1).to({startPosition:0},0).wait(15));

	// t3_summer
	this.instance_16 = new lib.t3summer("synched",0);
	this.instance_16.setTransform(148.3,26.5);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(415).to({_off:false},0).wait(1).to({regY:0.1,y:34.05,alpha:0.4491},0).wait(1).to({y:36.95,alpha:0.6049},0).wait(1).to({y:38.9,alpha:0.7092},0).wait(1).to({y:40.35,alpha:0.7863},0).wait(1).to({y:41.5,alpha:0.8454},0).wait(1).to({y:42.4,alpha:0.8917},0).wait(1).to({y:43.15,alpha:0.9276},0).wait(1).to({y:43.7,alpha:0.9551},0).wait(1).to({y:44.1,alpha:0.9753},0).wait(1).to({y:44.4,alpha:0.9893},0).wait(1).to({y:44.55,alpha:0.9973},0).wait(1).to({y:44.65,alpha:1},0).wait(1).to({regY:0,y:44.55},0).wait(21));

	// t3_free
	this.instance_17 = new lib.t3free("synched",0);
	this.instance_17.setTransform(72.8,26.65);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(410).to({_off:false},0).wait(1).to({y:34.1287,alpha:0.4491},0).wait(1).to({y:37.0002,alpha:0.6049},0).wait(1).to({y:38.9601,alpha:0.7092},0).wait(1).to({y:40.4327,alpha:0.7863},0).wait(1).to({y:41.5804,alpha:0.8454},0).wait(1).to({y:42.4889,alpha:0.8917},0).wait(1).to({y:43.2064,alpha:0.9276},0).wait(1).to({y:43.7644,alpha:0.9551},0).wait(1).to({y:44.1811,alpha:0.9753},0).wait(1).to({y:44.4714,alpha:0.9893},0).wait(1).to({y:44.6428,alpha:0.9973},0).wait(1).to({y:44.7,alpha:1},0).wait(1).to({startPosition:0},0).wait(26));

	// t2_button
	this.instance_18 = new lib.t2button("synched",0);
	this.instance_18.setTransform(389.4,27.2);
	this.instance_18.alpha = 0;
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(431).to({_off:false},0).wait(1).to({y:34.6787,alpha:0.4491},0).wait(1).to({y:37.5502,alpha:0.6049},0).wait(1).to({y:39.5101,alpha:0.7092},0).wait(1).to({y:40.9827,alpha:0.7863},0).wait(1).to({y:42.1304,alpha:0.8454},0).wait(1).to({y:43.0389,alpha:0.8917},0).wait(1).to({y:43.7564,alpha:0.9276},0).wait(1).to({y:44.3144,alpha:0.9551},0).wait(1).to({y:44.7311,alpha:0.9753},0).wait(1).to({y:45.0214,alpha:0.9893},0).wait(1).to({y:45.1928,alpha:0.9973},0).wait(1).to({y:45.25,alpha:1},0).wait(1).to({startPosition:0},0).wait(5));

	// t2_logos
	this.instance_19 = new lib.t2logos("synched",0);
	this.instance_19.setTransform(643.85,45.85);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(411).to({_off:false},0).wait(1).to({regY:0.1,x:639.6,y:45.7,alpha:0.4491},0).wait(1).to({x:635.35,y:45.6,alpha:0.6049},0).wait(1).to({x:631.15,y:45.5,alpha:0.7092},0).wait(1).to({x:626.9,y:45.45,alpha:0.7863},0).wait(1).to({x:622.7,alpha:0.8454},0).wait(1).to({x:618.45,y:45.4,alpha:0.8917},0).wait(1).to({x:614.2,y:45.35,alpha:0.9276},0).wait(1).to({x:610,alpha:0.9551},0).wait(1).to({x:605.75,alpha:0.9753},0).wait(1).to({x:601.55,alpha:0.9893},0).wait(1).to({x:597.3,alpha:0.9973},0).wait(1).to({x:593.1,alpha:1},0).wait(1).to({regY:0,y:45.25},0).wait(25));

	// t2
	this.instance_20 = new lib.t2("synched",0);
	this.instance_20.setTransform(364.05,26.9);
	this.instance_20.alpha = 0;
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(169).to({_off:false},0).wait(1).to({regX:0.1,regY:0.1,x:364.15,y:34.45,alpha:0.4491},0).wait(1).to({y:37.35,alpha:0.6049},0).wait(1).to({y:39.3,alpha:0.7092},0).wait(1).to({y:40.75,alpha:0.7863},0).wait(1).to({y:41.9,alpha:0.8454},0).wait(1).to({y:42.8,alpha:0.8917},0).wait(1).to({y:43.55,alpha:0.9276},0).wait(1).to({y:44.1,alpha:0.9551},0).wait(1).to({y:44.5,alpha:0.9753},0).wait(1).to({y:44.8,alpha:0.9893},0).wait(1).to({y:44.95,alpha:0.9973},0).wait(1).to({y:45.05,alpha:1},0).wait(1).to({regX:0,regY:0,x:364.05,y:44.95},0).wait(208).to({regX:-0.1,x:363.95},0).wait(1).to({regX:0.1,regY:0.1,x:364.15,y:45,alpha:0.9982},0).wait(1).to({y:44.9,alpha:0.9923},0).wait(1).to({y:44.8,alpha:0.9816},0).wait(1).to({y:44.55,alpha:0.9652},0).wait(1).to({y:44.3,alpha:0.9419},0).wait(1).to({y:43.85,alpha:0.9101},0).wait(1).to({y:43.35,alpha:0.8676},0).wait(1).to({y:42.65,alpha:0.8113},0).wait(1).to({y:41.75,alpha:0.7365},0).wait(1).to({y:40.6,alpha:0.6361},0).wait(1).to({y:39,alpha:0.4978},0).wait(1).to({y:36.85,alpha:0.2998},0).wait(1).to({y:33.6,alpha:0},0).to({_off:true},1).wait(45));

	// t1
	this.instance_21 = new lib.t1("synched",0);
	this.instance_21.setTransform(372.9,48.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(148).to({startPosition:0},0).wait(1).to({y:48.4262,alpha:0.9982},0).wait(1).to({y:48.3487,alpha:0.9923},0).wait(1).to({y:48.2096,alpha:0.9816},0).wait(1).to({y:47.9982,alpha:0.9652},0).wait(1).to({y:47.7005,alpha:0.9419},0).wait(1).to({y:47.2988,alpha:0.9101},0).wait(1).to({y:46.7695,alpha:0.8676},0).wait(1).to({y:46.0807,alpha:0.8113},0).wait(1).to({y:45.185,alpha:0.7365},0).wait(1).to({y:44.0118,alpha:0.6361},0).wait(1).to({y:42.4458,alpha:0.4978},0).wait(1).to({y:40.2712,alpha:0.2998},0).wait(1).to({y:37,alpha:0},0).to({_off:true},1).wait(287));

	// background
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ECF8FD").s().p("Eg43AHCIAAuDMBxvAAAIgBODg");
	this.shape_1.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(449));

	// stageBackground
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("Eg6bgIlMB03AAAIAARLMh03AAAg");
	this.shape_2.setTransform(364,45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Eg6bAImIAAxLMB03AAAIAARLg");
	this.shape_3.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).wait(449));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(269.1,-55.8,586.6,227.10000000000002);
// library properties:
lib.properties = {
	id: '258793954D556C4AB2E8633DA1CDD02A',
	width: 728,
	height: 90,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/fsm_digital_728x90_v1_atlas_1.png", id:"fsm_digital_728x90_v1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['258793954D556C4AB2E8633DA1CDD02A'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;