(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"fsm_digital_160x600_v1_atlas_1", frames: [[451,679,243,47],[908,385,105,49],[445,397,166,49],[451,619,123,47],[227,619,222,70],[631,225,275,243],[227,691,132,74],[299,0,330,263],[0,619,225,265],[0,0,297,470],[631,0,344,223],[908,225,95,81],[299,265,144,185],[361,691,67,67],[867,581,123,96],[445,265,149,130],[908,308,95,75],[867,470,110,109],[0,472,865,145]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_91 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_90 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_89 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_88 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_87 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_86 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_85 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_84 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_83 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_82 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_81 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_80 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_79 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_78 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_77 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_76 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_75 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_74 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Image_1 = function() {
	this.initialize(ss["fsm_digital_160x600_v1_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t3summer2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_summer
	this.instance = new lib.CachedBmp_91();
	this.instance.setTransform(-60.6,-11.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:true},1).wait(435).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60.6,-11.8,121.5,23.5);


(lib.t3org = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_org
	this.instance = new lib.CachedBmp_90();
	this.instance.setTransform(-26.3,-12.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:true},1).wait(435).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.3,-12.2,52.5,24.5);


(lib.t3meal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_meals
	this.instance = new lib.CachedBmp_89();
	this.instance.setTransform(-41.45,-12.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:true},1).wait(435).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41.4,-12.3,83,24.5);


(lib.t3free2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_free
	this.instance = new lib.CachedBmp_88();
	this.instance.setTransform(-30.65,-11.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:true},1).wait(435).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.6,-11.6,61.5,23.5);


(lib.t3button = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2_button
	this.instance = new lib.CachedBmp_87();
	this.instance.setTransform(-55.45,-17.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55.4,-17.5,111,35);


(lib.t3bar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_bars
	this.instance = new lib.CachedBmp_86();
	this.instance.setTransform(-68.75,-60.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:true},1).wait(435).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68.7,-60.7,137.5,121.5);


(lib.t2logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2_logos
	this.instance = new lib.CachedBmp_85();
	this.instance.setTransform(-31.15,5.1,0.5,0.5);

	this.instance_1 = new lib.Image_1();
	this.instance_1.setTransform(-68.35,-35.9,0.1568,0.1568);

	this.instance_2 = new lib.CachedBmp_84();
	this.instance_2.setTransform(-82.55,-65.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-82.5,-65.8,165,131.5);


(lib.t2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2
	this.instance = new lib.CachedBmp_83();
	this.instance.setTransform(-55.75,-66.65,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_82();
	this.instance_1.setTransform(-74.3,-117.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74.3,-117.4,148.5,235);


(lib.t1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt1
	this.instance = new lib.CachedBmp_81();
	this.instance.setTransform(-86,-55.65,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-86,-55.6,172,111.5);


(lib.Symbol15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_dark_blue
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#224EA2").s().p("AFhHoQhxgbhEhUIgpg4QgYghgUgSQgtgnhKgOQgrgIhegCQhmgEhKgMQhfgQhKggQhUgmg9g+QhChDgWhSQgLglgCgyIgDgoQAAgZAEgPQADgJAIgKIAPgRQAXgdASgRQAqgqA8ggQBrg6CFgIQBrgHB+AaQBdATCFAsQCwA7BwA6QCXBPBeBpQBkBuASB2QAQBrg4BmQg4BlhjAtQg9AbhDAAQgpAAgrgKg");
	this.shape.setTransform(0.0015,-0.0016);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(420).to({_off:true},1).wait(4).to({_off:false},0).wait(4).to({_off:true},1).wait(18).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-76.3,-49.8,152.7,99.6);


(lib.Symbol14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_light_blue
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#568DCA").s().p("ACEJmQgkgChCgMQg8gLgcgPQgggRgrgvQgVgXgKgPQgPgXgEgWQgEgfARgpQAQgkBOhzQA/hbAHhCQAGgygTgyQgTgxglgkQgqgpg7gTQgegKgbgDQgQgCgZgGIgpgJIgggFQgtgHgYgGQglgIgcgOQgogUgZgjQgcgmAEgpQACgcASgaQAQgZAagSQAigYBLgVQClgvCtgPQBQgHBcAAIAgACQARACANAGQANAGAWAFIAjAIQBIATBEAmQAcAQAKAOQAJAMAEATQACALABAXIAVGNQACAdAMAQQAGAJAHAQQAHATAEAGQAGALANARQAPATAFAJQAiA2ADA6QACA4gaA1QgQAfgYAcQgQASgJAIQgFAFgHAEIgNAHQgOAJgUASIghAcIhEA1QgdAVgPAJQgZAQgWAIQglAOgwAAIgPAAg");
	this.shape.setTransform(0.0374,-0.0081);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(420).to({_off:true},1).wait(4).to({_off:false},0).wait(4).to({_off:true},1).wait(18).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.1,-61.4,114.30000000000001,122.8);


(lib.Symbol13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_red
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EA6241").s().p("AAALzQgMgIgXgUQhwhgiJg3QhDgbhLgRQgjgIgmgGQgNgChFgEQgxgDgggJQgsgOgegfQgWgWgTgkQgUgngGgzQgSh9A/hxQBLiBCthaQAVgLAjgPIA5gZIATgLQAKgHAQgGIAdgKQBKgaAxgcQAngXASgVQARgVALgPQAbgrgEgiQgCgVgTggQgXgmgFgOQgKggAMgjQALgjAfgbQAogiBMgXQBZgaBfgBQAXAAA5AFQAzAFAegCQAjgDAqALQAYAGAvARQBLAbA5AkQB1BJAjBjIAHAWQAPA/geAxQgMASgVAUIglAiQhNBIgsCfIgjCAQgVBKgaAxQgUAnglAyIhBBVQgwBChcCLQhVB1hXA3QgYAPgQABIgEAAQgSAAgTgKg");
	this.shape.setTransform(0.0012,0.0333);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(420).to({_off:true},1).wait(4).to({_off:false},0).wait(4).to({_off:true},1).wait(18).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-80.8,-76.5,161.6,153.1);


(lib.Symbol12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_green
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AlpFoQgzgXgNg0QgKgiAGgzQAJg5ADgdQACgbAAgnIAAhVQAFiAA7hYQAhgwAvggQAzghA3gGQApgEBDALQBQAPAaABIAvABQAXABAWAKQA5AaAnAXQC5BsAKB+IAAANQAACOjbB1Qi7BkkeA1QgSADgQAAQgjAAgggOg");
	this.shape.setTransform(0.0339,0.048);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(420).to({_off:true},1).wait(4).to({_off:false},0).wait(4).to({_off:true},1).wait(18).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43.2,-37.4,86.5,74.9);


(lib.Symbol10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_yellow
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FCB11D").s().p("ABwHLInrgXQg3gCgcgGQgtgIgggWQglgbgUgxQgXg1AEhCQADgtAWhXIAQg8QAJgjABgYQAAgQgFgOIgKgYQgOggAJgvQAFghAOgfQANgfASgWQAdglAogYQAagPAwgQQDFhEBygFQCmgHBiBrQAPARBJBqQA1BNAuAYQAQAJBaAWQBBAQAdAoQAgAtAJBaQAHA8gDBwQgBA5gJAcQgbBVhfAUQhVARhnACIgTAAQg+AAhngFg");
	this.shape.setTransform(-0.0078,0.0106);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(420).to({_off:true},1).wait(4).to({_off:false},0).wait(4).to({_off:true},1).wait(18).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.6,-46.4,123.30000000000001,92.8);


(lib.Symbol9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus
	this.instance = new lib.CachedBmp_80();
	this.instance.setTransform(-23.8,-20.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(420).to({_off:true},1).wait(4).to({_off:false},0).wait(4).to({_off:true},1).wait(18).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.8,-20.1,47.5,40.5);


(lib.Symbol7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_carrot
	this.instance = new lib.CachedBmp_79();
	this.instance.setTransform(-35.9,-46.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(420).to({_off:true},1).wait(4).to({_off:false},0).wait(4).to({_off:true},1).wait(18).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-35.9,-46.2,72,92.5);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_ritz
	this.instance = new lib.CachedBmp_78();
	this.instance.setTransform(-16.65,-16.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(420).to({_off:true},1).wait(4).to({_off:false},0).wait(4).to({_off:true},1).wait(18).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.6,-16.7,33.5,33.5);


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_banana
	this.instance = new lib.CachedBmp_77();
	this.instance.setTransform(-30.8,-24.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(420).to({_off:true},1).wait(4).to({_off:false},0).wait(4).to({_off:true},1).wait(18).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.8,-24,61.5,48);


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_milk
	this.instance = new lib.CachedBmp_76();
	this.instance.setTransform(-37.35,-32.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(420).to({_off:true},1).wait(4).to({_off:false},0).wait(4).to({_off:true},1).wait(18).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-37.3,-32.4,74.5,65);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_orange
	this.instance = new lib.CachedBmp_75();
	this.instance.setTransform(-23.85,-18.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(420).to({_off:true},1).wait(4).to({_off:false},0).wait(4).to({_off:true},1).wait(18).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.8,-18.7,47.5,37.5);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_apple
	this.instance = new lib.CachedBmp_74();
	this.instance.setTransform(-27.6,-27.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(420).to({_off:true},1).wait(4).to({_off:false},0).wait(4).to({_off:true},1).wait(18).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.6,-27.2,55,54.5);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_apple_slice
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#224EA2").s().p("AAIC7Qg2gggbgoQgcgpAFg0QAFg4AWgwQAWgwApgeQAsghAxAGQAHABABAJQAEAFgCAGIgaA/QgOAegPAPQgIAJgNAJIgMAJQgIAGgBAEQgBAGAGAHIANAJQAKAJASAMQAIAFgEAJQgYA8gLBFIADABQAJAGgFAKQgDAHgFAAIgGgCgAgSh5QgkAngPA9QgIAiABAYQAAAgAPAZQASAgAoAbQAJg7AWg6QgigWgMgTQgIgNAJgOQAGgJAOgMQAYgTAEgEQAKgMAKgSQAJgRATgtQg5ACgoAtg");
	this.shape.setTransform(1.8772,-0.9951);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgRCwQgLAAgNgLQgtgmgDhYQgChgAqg6QAYgiAlgQQAVgJAUgBIAAAAQATgCASAFIgXgCQALACADAFQACADAAAIQAACXg6CMQgRApgXAAIgCAAg");
	this.shape_1.setTransform(-2.607,2.2611);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape}]},420).to({state:[]},1).to({state:[{t:this.shape_1},{t:this.shape}]},4).to({state:[{t:this.shape_1},{t:this.shape}]},4).to({state:[]},1).to({state:[{t:this.shape_1},{t:this.shape}]},18).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.6,-19.8,23.299999999999997,39.7);


(lib.Path_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AjzIAQgYgPgOgYQgNgXgFgiQgDgVgBgpQgGjIgFjHIgDicIgHh8QgDhMAMguQAJgmAegTQAbgSAogBQA0gDAtAiQATAOA5A6QBFBJBZAuIBAAfQAmATAXAQQAgAWATAcQAXAfAEAhQADAfgNAlQgIAYgWAnIhuDPIgmBFQgXAmgVAcQgpA0g4AnQg5AlhBAUIggAMQgVAIgLADQgHABgHAAQgTAAgUgMg");
	this.shape.setTransform(32.5726,52.4713);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2, new cjs.Rectangle(0,0.1,65.1,104.80000000000001), null);


(lib.Path_19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAoA1QgGgDgHgHIgMgNIgsgsIgNgMQgHgIgDgGQgCgFADgFQAEgGAFADQAHADAIAIIAMANIAsAsQATASAFAIQADAGgFAFQgDADgDAAIgFgCg");
	this.shape.setTransform(5.3857,5.458);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_19, new cjs.Rectangle(0,0,10.8,11), null);


(lib.Path_18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AA0BCIhYhXQgYgWgGgIQgEgGAEgHQAFgIAHAFQAWARAlAqIA9A8QAHAHgHAHQgEAEgDAAQgEAAgDgEg");
	this.shape.setTransform(6.8875,6.9565);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_18, new cjs.Rectangle(0,0,13.8,13.9), null);


(lib.Path_17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AA4BIIg+hAIghgfQgSgTgMgPQgEgGAFgHQAEgGAGAEQAPANATATIAfAiIA+BAQAGAHgGAGQgDAEgEAAQgDAAgDgDg");
	this.shape.setTransform(7.1934,7.4394);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_17, new cjs.Rectangle(0,0,14.4,14.9), null);


(lib.Path_16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAiAzQgOgTgYgbQgfgagMgQQgEgFADgHQAEgHAGAEQAMAGAOAOIAVAXQAXAYAQAWQAFAHgGAHQgDAEgDAAQgEAAgDgEg");
	this.shape.setTransform(4.9818,5.4356);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_16, new cjs.Rectangle(0,0,10,10.9), null);


(lib.Path_15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAdA4QgQgcgUgcQgagcgKgQQgEgGAEgHQAEgHAHAFQAPANAaAmQASAYARAfQAFAIgIAFIgFACQgEAAgDgGg");
	this.shape.setTransform(4.6153,6.1518);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_15, new cjs.Rectangle(0,0,9.2,12.3), null);


(lib.Path_13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAmA3QgTgTgZgcIgqgwQgFgHAGgGQAGgGAFAGIArAvQAaAaAQAVQAFAFgFAHQgDAEgDAAQgCAAgDgCg");
	this.shape.setTransform(5.131,5.6893);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_13, new cjs.Rectangle(0,0,10.3,11.4), null);


(lib.Path_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AA4BUIhdh2IgRgUQgKgMgEgJQgCgEAEgFQADgEAEACQAKAGALAMIASAWIAfAnQAeAoAVAjIABAAQAIACgCAKQgBAGgFABIgBAAIgBABQgDAAgCgEg");
	this.shape.setTransform(6.9336,8.7654);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9, new cjs.Rectangle(0,0,13.9,17.5), null);


(lib.Symbol11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_green2
	this.instance = new lib.Path_2();
	this.instance.setTransform(-0.05,0.05,1,1,0,0,0,32.5,52.5);
	this.instance.alpha = 0.9492;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(420).to({_off:true},1).wait(4).to({_off:false},0).wait(4).to({_off:true},1).wait(18).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-52.4,65.1,104.9);


(lib.Symbol8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_lines
	this.instance = new lib.Path_9();
	this.instance.setTransform(-11.1,29.35,1,1,0,0,0,7,8.8);
	this.instance.compositeOperation = "multiply";

	this.instance_1 = new lib.Path_13();
	this.instance_1.setTransform(-4.9,14.95,1,1,0,0,0,5.1,5.7);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_15();
	this.instance_2.setTransform(-12.1,-7.75,1,1,0,0,0,4.6,6.2);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_16();
	this.instance_3.setTransform(6.65,8,1,1,0,0,0,5,5.5);
	this.instance_3.compositeOperation = "multiply";

	this.instance_4 = new lib.Path_17();
	this.instance_4.setTransform(-15.7,-30.55,1,1,0,0,0,7.2,7.4);
	this.instance_4.compositeOperation = "multiply";

	this.instance_5 = new lib.Path_18();
	this.instance_5.setTransform(1.75,-13.25,1,1,0,0,0,6.9,7);
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.Path_19();
	this.instance_6.setTransform(17.55,1.95,1,1,0,0,0,5.4,5.5);
	this.instance_6.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},420).to({state:[]},1).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},4).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},4).to({state:[]},1).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},18).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.9,-38,45.9,76.1);


// stage content:
(lib.fsm_digital_160x600_v1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [448];
	// timeline functions:
	this.frame_448 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(448).call(this.frame_448).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvgEgMYAuwIYwAAMAAAhdgI4wAAg");
	this.shape.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	// border
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvgEgMYAuwIYwAAMAAAhdgI4wAAg");
	this.shape_1.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(449));

	// Symbol_1
	this.instance = new lib.Symbol1("synched",0);
	this.instance.setTransform(148.35,-38.65);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:128.1,y:2.35,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:14.9992,x:141.1,y:0.7,startPosition:73},43,cjs.Ease.quadInOut).to({startPosition:169},96,cjs.Ease.quadInOut).to({x:149.5,y:-2.05,startPosition:192},23,cjs.Ease.quartInOut).to({x:148.5,y:-0.05,startPosition:310},118,cjs.Ease.quadInOut).to({x:131.1,y:-11.3,startPosition:448},111,cjs.Ease.quadInOut).to({x:143.6,y:-22.2,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// Symbol_2
	this.instance_1 = new lib.Symbol2("synched",0);
	this.instance_1.setTransform(200.65,37.15);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:128.15,y:67.15,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:-14.9992,x:126.15,y:69.15,startPosition:73},43,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,rotation:0,x:126.3,y:69.2,startPosition:169},96,cjs.Ease.quadInOut).to({x:128.3,y:68.2,startPosition:192},23,cjs.Ease.quartInOut).to({rotation:29.9989,x:126.3,y:66.25,startPosition:310},118,cjs.Ease.quadInOut).to({rotation:0,x:135.6,y:56.25,startPosition:448},111,cjs.Ease.quadInOut).to({rotation:14.9994,x:139.8,y:38.25,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// Symbol_3
	this.instance_2 = new lib.Symbol3("synched",0);
	this.instance_2.setTransform(196.9,184.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:108.3,y:202.6,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:14.9992,x:105.3,y:204.6,startPosition:73},43,cjs.Ease.quadInOut).to({regY:0.1,rotation:0,x:107.3,y:202.7,startPosition:169},96,cjs.Ease.quadInOut).to({x:117.3,startPosition:192},23,cjs.Ease.quartInOut).to({regX:0.1,rotation:14.9994,x:122.4,y:199.75,startPosition:310},118,cjs.Ease.quadInOut).to({regX:0,rotation:-90,x:153.65,y:197,startPosition:448},111,cjs.Ease.quadInOut).to({regX:0.1,rotation:60,x:201.55,y:183.95,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// Symbol_4
	this.instance_3 = new lib.Symbol4("synched",0);
	this.instance_3.setTransform(221.65,410.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:141.65,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:-14.9992,x:135.65,y:414.8,startPosition:73},43,cjs.Ease.quadInOut).to({rotation:0,x:137.65,y:417.8,startPosition:169},96,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,rotation:-14.9994,x:136.1,y:434.05,startPosition:192},23,cjs.Ease.quartInOut).to({y:437.05,startPosition:310},118,cjs.Ease.quadInOut).to({regX:0,regY:0,rotation:0,x:152.1,y:431.55,startPosition:448},111,cjs.Ease.quadInOut).to({x:163.95,y:338.6,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// Symbol_5
	this.instance_4 = new lib.Symbol5("synched",0);
	this.instance_4.setTransform(-38.85,558.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({x:49.75,y:514.05,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:-14.9992,x:52.75,y:516.05,startPosition:73},43,cjs.Ease.quadInOut).to({regX:0.1,rotation:0,x:53.8,y:518.05,startPosition:169},96,cjs.Ease.quadInOut).to({x:-55.6,y:501.05,startPosition:192},23,cjs.Ease.quartInOut).to({startPosition:310},118,cjs.Ease.quadInOut).to({x:-53.2,y:518.05,startPosition:448},111,cjs.Ease.quadInOut).to({regY:0.1,scaleX:0.9999,scaleY:0.9999,rotation:-44.9975,x:88.5,y:429.9,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// Symbol_6
	this.instance_5 = new lib.Symbol6("synched",0);
	this.instance_5.setTransform(-30.45,225.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:18.15,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:14.9992,x:16.1,y:221.1,startPosition:73},43,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,rotation:44.9975,x:18.05,y:223.15,startPosition:169},96,cjs.Ease.quadInOut).to({x:22.05,y:217.15,startPosition:192},23,cjs.Ease.quartInOut).to({rotation:59.9968,x:25.55,y:204.8,startPosition:310},118,cjs.Ease.quadInOut).to({rotation:44.9975,x:18.05,y:224,startPosition:448},111,cjs.Ease.quadInOut).to({x:-77.65,y:312.9,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// Symbol_7
	this.instance_6 = new lib.Symbol7("synched",0);
	this.instance_6.setTransform(-54.7,119.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({x:55.3,y:139.2,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:-14.9992,x:59.3,y:138.2,startPosition:73},43,cjs.Ease.quadInOut).to({x:61.3,y:137.2,startPosition:169},96,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,rotation:-29.9984,x:66.4,y:124.25,startPosition:192},23,cjs.Ease.quartInOut).to({regX:0,rotation:-44.9975,x:74.3,y:119.25,startPosition:310},118,cjs.Ease.quadInOut).to({rotation:-14.9994,x:85.9,y:152.3,startPosition:448},111,cjs.Ease.quadInOut).to({regX:0.1,regY:0,rotation:15.0005,x:79.65,y:109.2,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// Symbol_8
	this.instance_7 = new lib.Symbol8("synched",0);
	this.instance_7.setTransform(-41.7,67.25);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({x:9.1,y:127.25,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:-14.9992,x:5.1,y:126.25,startPosition:73},43,cjs.Ease.quadInOut).to({y:128.25,startPosition:169},96,cjs.Ease.quadInOut).to({x:7.1,y:123.25,startPosition:192},23,cjs.Ease.quartInOut).to({x:12.1,y:130.25,startPosition:310},118,cjs.Ease.quadInOut).to({x:9.5,y:130.45,startPosition:448},111,cjs.Ease.quadInOut).to({rotation:-29.9984,x:3.8,y:110.4,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// Symbol_9
	this.instance_8 = new lib.Symbol9("synched",0);
	this.instance_8.setTransform(-37.65,437.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({x:41.1,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:14.9992,x:48.05,y:439.65,startPosition:73},43,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,rotation:0,x:51.1,y:443.75,startPosition:169},96,cjs.Ease.quadInOut).to({rotation:14.9994,x:53,y:441.75,startPosition:192},23,cjs.Ease.quartInOut).to({x:55,y:443.75,startPosition:310},118,cjs.Ease.quadInOut).to({rotation:0,x:63.1,y:443.95,startPosition:448},111,cjs.Ease.quadInOut).to({regX:0,regY:0,rotation:29.9989,x:79.35,y:324.05,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// Symbol_10
	this.instance_9 = new lib.Symbol10("synched",0);
	this.instance_9.setTransform(-12.9,607.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({x:7.65,y:585.55,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:-14.9992,x:10.65,y:593.55,startPosition:73},43,cjs.Ease.quadInOut).to({rotation:-7.5176,x:13.6,y:600.55,startPosition:169},96,cjs.Ease.quadInOut).to({x:-74.1,startPosition:192},23,cjs.Ease.quartInOut).to({startPosition:310},118,cjs.Ease.quadInOut).to({x:-72.75,y:621.55,startPosition:448},111,cjs.Ease.quadInOut).to({regY:0.1,rotation:7.4816,x:-29.45,y:425.55,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// Symbol_11
	this.instance_10 = new lib.Symbol11("synched",0);
	this.instance_10.setTransform(-19.6,405.35);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({x:-9.35,y:384.75,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:14.9992,x:-7.35,y:387.75,startPosition:73},43,cjs.Ease.quadInOut).to({rotation:14.9994,x:-7.3,y:392.75,startPosition:169},96,cjs.Ease.quadInOut).to({x:-8.55,y:404.75,startPosition:192},23,cjs.Ease.quartInOut).to({x:-8,y:417.95,startPosition:310},118,cjs.Ease.quadInOut).to({x:-27.8,y:443.75,startPosition:448},111,cjs.Ease.quadInOut).to({x:-15.05,y:332.05,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// Symbol_12
	this.instance_11 = new lib.Symbol12("synched",0);
	this.instance_11.setTransform(-31.35,86.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({x:-19.35,y:96.65,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:-14.9992,x:-16.3,y:89.65,startPosition:73},43,cjs.Ease.quadInOut).to({x:-13.8,y:89.25,startPosition:169},96,cjs.Ease.quadInOut).to({x:-11.8,y:80.25,startPosition:192},23,cjs.Ease.quartInOut).to({regX:-0.1,regY:0.1,rotation:0,x:-9.9,y:76.4,startPosition:310},118,cjs.Ease.quadInOut).to({regX:0,regY:0,rotation:-14.9992,x:0.2,y:90.3,startPosition:448},111,cjs.Ease.quadInOut).to({x:-8.8,y:78.25,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// Symbol_13
	this.instance_12 = new lib.Symbol13("synched",0);
	this.instance_12.setTransform(220.55,506.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({x:198.45,y:491.2,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:5.2503,x:195.45,y:495.2,startPosition:73},43,cjs.Ease.quadInOut).to({x:198.45,y:499.2,startPosition:169},96,cjs.Ease.quadInOut).to({x:278.45,y:515.45,startPosition:192},23,cjs.Ease.quartInOut).to({startPosition:310},118,cjs.Ease.quadInOut).to({x:264.45,y:535.4,startPosition:448},111,cjs.Ease.quadInOut).to({x:224.2,y:432.65,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// Symbol_14
	this.instance_13 = new lib.Symbol14("synched",0);
	this.instance_13.setTransform(196.9,180.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({x:161,y:191,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:-7.194,x:165,y:185,startPosition:73},43,cjs.Ease.quadInOut).to({rotation:-14.1898,x:166,y:174,startPosition:169},96,cjs.Ease.quadInOut).to({rotation:-7.7081,x:180,y:168.9,startPosition:192},23,cjs.Ease.quartInOut).to({rotation:-0.0017,x:184,y:169.9,startPosition:310},118,cjs.Ease.quadInOut).to({rotation:-14.1898,x:195.2,y:174,startPosition:448},111,cjs.Ease.quadInOut).to({rotation:-14.1902,x:200.7,y:153.75,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// Symbol_15
	this.instance_14 = new lib.Symbol15("synched",0);
	this.instance_14.setTransform(24.2,-27.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({x:18.65,y:-4.45,startPosition:30},30,cjs.Ease.quartInOut).to({rotation:7.201,x:22.35,y:-9.85,startPosition:73},43,cjs.Ease.quadInOut).to({rotation:0.007,startPosition:169},96,cjs.Ease.quadInOut).to({rotation:0.007,x:31.65,y:-15.2,startPosition:192},23,cjs.Ease.quartInOut).to({rotation:-7.2003,y:-21.2,startPosition:310},118,cjs.Ease.quadInOut).to({rotation:0.007,x:25.1,y:-20.85,startPosition:448},111,cjs.Ease.quadInOut).to({rotation:0.007,x:22.35,y:-9.85,startPosition:425},23,cjs.Ease.quartInOut).wait(5));

	// t3_bar
	this.instance_15 = new lib.t3bar("synched",0);
	this.instance_15.setTransform(79.4,209.3);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(432).to({_off:false},0).wait(1).to({y:216.7787,alpha:0.4491,startPosition:1},0).wait(1).to({y:219.6502,alpha:0.6049,startPosition:2},0).wait(1).to({y:221.6101,alpha:0.7092,startPosition:3},0).wait(1).to({y:223.0827,alpha:0.7863,startPosition:4},0).wait(1).to({y:224.2304,alpha:0.8454,startPosition:5},0).wait(1).to({y:225.1389,alpha:0.8917,startPosition:6},0).wait(1).to({y:225.8564,alpha:0.9276,startPosition:7},0).wait(1).to({y:226.4144,alpha:0.9551,startPosition:8},0).wait(1).to({y:226.8311,alpha:0.9753,startPosition:9},0).wait(1).to({y:227.1214,alpha:0.9893,startPosition:10},0).wait(1).to({y:227.2928,alpha:0.9973,startPosition:11},0).wait(1).to({y:227.35,alpha:1,startPosition:12},0).wait(1).to({startPosition:448},0).wait(4));

	// t3_org
	this.instance_16 = new lib.t3org("synched",0);
	this.instance_16.setTransform(122.1,242.65);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(434).to({_off:false},0).wait(1).to({y:250.1287,alpha:0.4491,startPosition:1},0).wait(1).to({y:253.0002,alpha:0.6049,startPosition:2},0).wait(1).to({y:254.9601,alpha:0.7092,startPosition:3},0).wait(1).to({y:256.4327,alpha:0.7863,startPosition:4},0).wait(1).to({y:257.5804,alpha:0.8454,startPosition:5},0).wait(1).to({y:258.4889,alpha:0.8917,startPosition:6},0).wait(1).to({y:259.2064,alpha:0.9276,startPosition:7},0).wait(1).to({y:259.7644,alpha:0.9551,startPosition:8},0).wait(1).to({y:260.1811,alpha:0.9753,startPosition:9},0).wait(1).to({y:260.4714,alpha:0.9893,startPosition:10},0).wait(1).to({y:260.6428,alpha:0.9973,startPosition:11},0).wait(1).to({y:260.7,alpha:1,startPosition:12},0).wait(1).to({startPosition:448},0).wait(2));

	// t3_meal
	this.instance_17 = new lib.t3meal("synched",0);
	this.instance_17.setTransform(51,236.15);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(430).to({_off:false},0).wait(1).to({y:243.6287,alpha:0.4491,startPosition:1},0).wait(1).to({y:246.5002,alpha:0.6049,startPosition:2},0).wait(1).to({y:248.4601,alpha:0.7092,startPosition:3},0).wait(1).to({y:249.9327,alpha:0.7863,startPosition:4},0).wait(1).to({y:251.0804,alpha:0.8454,startPosition:5},0).wait(1).to({y:251.9889,alpha:0.8917,startPosition:6},0).wait(1).to({y:252.7064,alpha:0.9276,startPosition:7},0).wait(1).to({y:253.2644,alpha:0.9551,startPosition:8},0).wait(1).to({y:253.6811,alpha:0.9753,startPosition:9},0).wait(1).to({y:253.9714,alpha:0.9893,startPosition:10},0).wait(1).to({y:254.1428,alpha:0.9973,startPosition:11},0).wait(1).to({y:254.2,alpha:1,startPosition:12},0).wait(1).to({startPosition:448},0).wait(6));

	// t3_summer2
	this.instance_18 = new lib.t3summer2("synched",0);
	this.instance_18.setTransform(69.6,208.1);
	this.instance_18.alpha = 0;
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(428).to({_off:false},0).wait(1).to({regX:0.1,regY:-0.1,x:69.7,y:215.45,alpha:0.4491,startPosition:1},0).wait(1).to({y:218.35,alpha:0.6049,startPosition:2},0).wait(1).to({y:220.3,alpha:0.7092,startPosition:3},0).wait(1).to({y:221.75,alpha:0.7863,startPosition:4},0).wait(1).to({y:222.9,alpha:0.8454,startPosition:5},0).wait(1).to({y:223.8,alpha:0.8917,startPosition:6},0).wait(1).to({y:224.55,alpha:0.9276,startPosition:7},0).wait(1).to({y:225.1,alpha:0.9551,startPosition:8},0).wait(1).to({y:225.5,alpha:0.9753,startPosition:9},0).wait(1).to({y:225.8,alpha:0.9893,startPosition:10},0).wait(1).to({y:225.95,alpha:0.9973,startPosition:11},0).wait(1).to({y:226.05,alpha:1,startPosition:12},0).wait(1).to({regX:0,regY:0,x:69.6,y:226.15,startPosition:448},0).wait(8));

	// t3_free2
	this.instance_19 = new lib.t3free2("synched",0);
	this.instance_19.setTransform(42.45,180.75);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(426).to({_off:false},0).wait(1).to({regX:0.1,regY:0.1,x:42.55,y:188.3,alpha:0.4491,startPosition:1},0).wait(1).to({y:191.2,alpha:0.6049,startPosition:2},0).wait(1).to({y:193.15,alpha:0.7092,startPosition:3},0).wait(1).to({y:194.6,alpha:0.7863,startPosition:4},0).wait(1).to({y:195.75,alpha:0.8454,startPosition:5},0).wait(1).to({y:196.65,alpha:0.8917,startPosition:6},0).wait(1).to({y:197.4,alpha:0.9276,startPosition:7},0).wait(1).to({y:197.95,alpha:0.9551,startPosition:8},0).wait(1).to({y:198.35,alpha:0.9753,startPosition:9},0).wait(1).to({y:198.65,alpha:0.9893,startPosition:10},0).wait(1).to({y:198.8,alpha:0.9973,startPosition:11},0).wait(1).to({y:198.9,alpha:1,startPosition:12},0).wait(1).to({regX:0,regY:0,x:42.45,y:198.8,startPosition:448},0).wait(10));

	// t3_button
	this.instance_20 = new lib.t3button("synched",0);
	this.instance_20.setTransform(81.3,365.15);
	this.instance_20.alpha = 0;
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(435).to({_off:false},0).wait(1).to({y:372.6287,alpha:0.4491},0).wait(1).to({y:375.5002,alpha:0.6049},0).wait(1).to({y:377.4601,alpha:0.7092},0).wait(1).to({y:378.9327,alpha:0.7863},0).wait(1).to({y:380.0804,alpha:0.8454},0).wait(1).to({y:380.9889,alpha:0.8917},0).wait(1).to({y:381.7064,alpha:0.9276},0).wait(1).to({y:382.2644,alpha:0.9551},0).wait(1).to({y:382.6811,alpha:0.9753},0).wait(1).to({y:382.9714,alpha:0.9893},0).wait(1).to({y:383.1428,alpha:0.9973},0).wait(1).to({y:383.2,alpha:1},0).wait(1).to({startPosition:0},0).wait(1));

	// t2_logos
	this.instance_21 = new lib.t2logos("synched",0);
	this.instance_21.setTransform(80.5,516.55);
	this.instance_21.alpha = 0;
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(176).to({_off:false},0).wait(1).to({y:524.0287,alpha:0.4491},0).wait(1).to({y:526.9002,alpha:0.6049},0).wait(1).to({y:528.8601,alpha:0.7092},0).wait(1).to({y:530.3327,alpha:0.7863},0).wait(1).to({y:531.4804,alpha:0.8454},0).wait(1).to({y:532.3889,alpha:0.8917},0).wait(1).to({y:533.1064,alpha:0.9276},0).wait(1).to({y:533.6644,alpha:0.9551},0).wait(1).to({y:534.0811,alpha:0.9753},0).wait(1).to({y:534.3714,alpha:0.9893},0).wait(1).to({y:534.5428,alpha:0.9973},0).wait(1).to({y:534.6,alpha:1},0).wait(1).to({startPosition:0},0).wait(260));

	// t2
	this.instance_22 = new lib.t2("synched",0);
	this.instance_22.setTransform(79.35,296.35);
	this.instance_22.alpha = 0;
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(176).to({_off:false},0).wait(1).to({y:303.8287,alpha:0.4491},0).wait(1).to({y:306.7002,alpha:0.6049},0).wait(1).to({y:308.6601,alpha:0.7092},0).wait(1).to({y:310.1327,alpha:0.7863},0).wait(1).to({y:311.2804,alpha:0.8454},0).wait(1).to({y:312.1889,alpha:0.8917},0).wait(1).to({y:312.9064,alpha:0.9276},0).wait(1).to({y:313.4644,alpha:0.9551},0).wait(1).to({y:313.8811,alpha:0.9753},0).wait(1).to({y:314.1714,alpha:0.9893},0).wait(1).to({y:314.3428,alpha:0.9973},0).wait(1).to({y:314.4,alpha:1},0).wait(1).to({startPosition:0},0).wait(220).to({startPosition:0},0).wait(1).to({y:314.3762,alpha:0.9982},0).wait(1).to({y:314.2987,alpha:0.9923},0).wait(1).to({y:314.1596,alpha:0.9816},0).wait(1).to({y:313.9482,alpha:0.9652},0).wait(1).to({y:313.6505,alpha:0.9419},0).wait(1).to({y:313.2488,alpha:0.9101},0).wait(1).to({y:312.7195,alpha:0.8676},0).wait(1).to({y:312.0307,alpha:0.8113},0).wait(1).to({y:311.135,alpha:0.7365},0).wait(1).to({y:309.9618,alpha:0.6361},0).wait(1).to({y:308.3958,alpha:0.4978},0).wait(1).to({y:306.2212,alpha:0.2998},0).wait(1).to({y:302.95,alpha:0},0).to({_off:true},1).wait(26));

	// t1
	this.instance_23 = new lib.t1("synched",0);
	this.instance_23.setTransform(78,303.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(149).to({startPosition:0},0).wait(1).to({regY:0.1,y:303.15,alpha:0.9982},0).wait(1).to({y:303.05,alpha:0.9923},0).wait(1).to({y:302.95,alpha:0.9816},0).wait(1).to({y:302.7,alpha:0.9652},0).wait(1).to({y:302.45,alpha:0.9419},0).wait(1).to({y:302,alpha:0.9101},0).wait(1).to({y:301.5,alpha:0.8676},0).wait(1).to({y:300.8,alpha:0.8113},0).wait(1).to({y:299.9,alpha:0.7365},0).wait(1).to({y:298.75,alpha:0.6361},0).wait(1).to({y:297.15,alpha:0.4978},0).wait(1).to({y:295,alpha:0.2998},0).wait(1).to({y:291.75,alpha:0},0).to({_off:true},1).wait(286));

	// background
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#ECF8FD").s().p("EgMfAu4MAAAhdvIY/AAMgABBdvg");
	this.shape_2.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(449));

	// stageBackground
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("EgODgwbIcHAAMAAABg3I8HAAg");
	this.shape_3.setTransform(80,300);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("EgODAwcMAAAhg3IcHAAMAAABg3g");
	this.shape_4.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3}]}).wait(449));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-54.5,222.7,417.4,447.40000000000003);
// library properties:
lib.properties = {
	id: '20ED164D3C794E46A22334D2B4CB10CD',
	width: 160,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/fsm_digital_160x600_v1_atlas_1.png", id:"fsm_digital_160x600_v1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['20ED164D3C794E46A22334D2B4CB10CD'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;