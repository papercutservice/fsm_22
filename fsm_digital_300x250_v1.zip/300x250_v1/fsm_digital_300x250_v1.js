(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"fsm_digital_300x250_v1_atlas_1", frames: [[1204,495,504,169],[1204,299,522,194],[1873,142,122,69],[0,649,600,118],[1666,157,205,65],[1204,0,460,297],[1876,213,93,35],[1728,448,184,36],[1666,224,208,47],[602,649,492,91],[1971,213,56,56],[1988,49,56,56],[1121,502,73,75],[1121,579,73,75],[867,502,125,109],[994,502,125,109],[1666,0,121,155],[1710,495,121,155],[1884,49,102,80],[1728,366,102,80],[1789,49,93,91],[1728,273,93,91],[1823,311,93,35],[1823,273,184,36],[1789,0,208,47],[1096,666,492,91],[0,0,600,500],[602,0,600,500],[0,502,865,145]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_119 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_118 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_117 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_116 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_115 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_114 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_113 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_112 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_111 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_110 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_109 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_108 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_107 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_106 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_105 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_104 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_103 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_102 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_101 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_100 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_99 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_98 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_97 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_96 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_95 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_94 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_93 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_92 = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Image = function() {
	this.initialize(ss["fsm_digital_300x250_v1_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt2_v2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2
	this.instance = new lib.CachedBmp_119();
	this.instance.setTransform(-122.55,-40.55,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_118();
	this.instance_1.setTransform(-130.4,-48.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130.4,-48.4,261,97);


(lib.txt2_logos_v3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2_logos
	this.instance = new lib.CachedBmp_117();
	this.instance.setTransform(39.25,-17.3,0.5,0.5);

	this.instance_1 = new lib.Image();
	this.instance_1.setTransform(-112.85,-11.75,0.1571,0.1571);

	this.instance_2 = new lib.CachedBmp_116();
	this.instance_2.setTransform(-150,-29.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-29.3,300,59);


(lib.txt2_button = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_115();
	this.instance.setTransform(-51.2,-16.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51.2,-16.2,102.5,32.5);


(lib.title = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_114();
	this.instance.setTransform(-114.95,-74.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114.9,-74.3,230,148.5);


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_113();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(0,0,46.5,17.5), null);


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_112();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(0,0,92,18), null);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_111();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(0,0,104,23.5), null);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_110();
	this.instance.setTransform(-0.75,-0.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-0.7,-0.7,246,45.5), null);


(lib.sh_y = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_yellow
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FCB11D").s().p("ADpFcQg3gIg/gVQgmgNhIgeIkmh4QghgNgQgJQgagPgOgVQgRgYgCgiQgCglARgnQAKgZAhgxIAXghQANgUAGgPQADgJAAgKIgBgRQgBgWAPgbQAXgnAhgWQAZgQAegFQATgEAhAAQCGACBGAVQBnAgAkBWQAGAOAWBQQAQA6AWAZQAIAJAyAfQAkAYAJAfQAJAigOA5QgJAlgaBFQgLAhgNAQQgdAogwAAQgJAAgLgCg");
	this.shape.setTransform(0.001,0.0049);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39.8,-34.9,79.6,69.9);


(lib.sh_red = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_red
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EA6241").s().p("ABAHsQgJgEgQgLQhOg1hbgYQgvgNgtgEQgYgDgYAAIg0ACQggACgUgEQgxgJgggwQgPgWgJghQgUhOAghMQAlhYBnhFQAWgPAugaQAFgDAGgGQAFgEAcgOQAwgYAagUQAXgRAKgPQAHgLAIgOQAOgdgFgVQgDgNgPgTQgRgWgEgJQgJgUAFgXQAFgXARgTQAXgZAvgUQAzgWA+gJQAOgCAmgBQAgAAATgEQAWgEAcADQAQACAeAHQAxAMAoATQBQAlAdA8IAGAOQAPAogQAgQgGAMgMAPIgVAYQgrAzgQBoQgVCHgMAeQgKAagUAjIgiA7QgwBfgaAuQgtBQgzApQgOAMgLACIgHAAQgJAAgKgEg");
	this.shape.setTransform(-0.0056,0.0332);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.8,-49.6,97.6,99.30000000000001);


(lib.sh_ltb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_light_blue
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#568DCA").s().p("ABvIDQgegBg4gLIglgIQgVgFgQgIQgbgPgjgnQglgngFgeQgEgZAPgkQAMgeBDhhQA0hMAGg4QAFgpgQgqQgQgpgfgfQgjgigxgQQgXgIgZgDQgNgBgVgFIgjgIIgbgEQglgGgUgFQgggHgXgMQgigQgVgeQgXggADgiQACgXAPgXQANgUAWgPQAdgVA+gRQCNgoCPgMQBHgGBJAAQAiAAASAIQALAFASAEIAeAHQBAASA2AeQAWAMAJANQAMAQACAnIASFNQABAYAKAOQAFAHAGANIAJAWQAFAJALAOQANAQAEAHQAdAuACAxQABAugVAsQgNAbgUAXQgJALgNALQgDAEgHADIgKAHQgNAHgQAPIgcAYIg5AsQgtAigfAMQgfALgmAAIgPAAg");
	this.shape.setTransform(0.0376,-0.0073);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.9,-51.5,95.9,103);


(lib.sh_g = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_green
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AkvEuQgqgUgMgrQgHgdAEgqQAIgxACgYQACgXgBggIAAg3IAAgQQAFhrAxhKQAcgpAogaQAqgcAvgFQAigDA4AJQBDAMAWABIAnABQAUACARAIQAxAVAhAUQCbBYAIBrIAAALQABB2i4BjQidBUjwAtQgPADgNAAQgeAAgbgMg");
	this.shape.setTransform(0,0.0284);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.2,-31.3,72.5,62.7);


(lib.sh_db = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_dark_blue
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#224EA2").s().p("AEpGZQhfgXg6hGIgigvQgUgcgRgPQglggg/gMQgjgHhPgCQhVgDg/gKQhQgNg+gcQhHgfgzg1Qg3g3gThEQgIgfgDgqIgCgiQgBgVAEgNQACgHAIgJIAMgOQAWgbANgMQAkgjAxgaQBagxBwgHQBZgGBqAWQBOAQBwAlQCTAwBfAyQB+BCBPBYQBUBdAPBiQANBaguBVQgvBWhTAkQg0AXg4AAQgiAAgkgIg");
	this.shape.setTransform(0.0169,0.0194);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64,-41.7,128.1,83.5);


(lib.il_rz = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_ritz
	this.instance = new lib.CachedBmp_108();
	this.instance.setTransform(-13.9,-14.05,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_109();
	this.instance_1.setTransform(-13.9,-14.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.9,-14,28,28);


(lib.il_or = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_orange
	this.instance = new lib.CachedBmp_106();
	this.instance.setTransform(-18.25,-18.75,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_107();
	this.instance_1.setTransform(-18.25,-18.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-18.2,-18.7,36.5,37.5);


(lib.il_mlk = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_milk
	this.instance = new lib.CachedBmp_104();
	this.instance.setTransform(-31.35,-27.2,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_105();
	this.instance_1.setTransform(-31.35,-27.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.3,-27.2,62.5,54.5);


(lib.il_car = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_carrot
	this.instance = new lib.CachedBmp_102();
	this.instance.setTransform(-30.15,-38.75,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_103();
	this.instance_1.setTransform(-30.15,-38.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.1,-38.7,60.5,77.5);


(lib.il_ban = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_banana
	this.instance = new lib.CachedBmp_100();
	this.instance.setTransform(-25.45,-19.9,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_101();
	this.instance_1.setTransform(-25.45,-19.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.4,-19.9,51,40);


(lib.il_apsl = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_apple_slice
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#224EA2").s().p("AAHCdQgugbgWgiQgYghAEgtQAEgvATgoQATgoAigZQAlgcApAGQAHABAAAHQADAEgCAFIgWA1QgLAZgNANIgSAPIgKAHQgGAFgBAEQgBAEAGAGIAKAIQAJAIAOAJQAHAEgDAIQgUAxgKA7IADABQAIAFgEAJQgCAFgFAAIgFgBgAgPhlQgeAhgMAzQgPA8AVAkQAQAaAhAXQAHgyATgwQgcgRgLgRQgHgLAIgMQAFgHAMgKIAMgJQAHgGAEgFQAIgJAIgPQAJgRAPgjQgwABghAmg");
	this.shape.setTransform(1.5573,-0.8179);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLCTQgKAAgKgJQgmgggDhKQgChQAjgwQAVgcAfgOQATgIASgBIAHABQALABADAFQACADAAAGQAAB+gxB2QgOAjgTAAIgCgBg");
	this.shape_1.setTransform(-2.4804,1.9053);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.7,-16.6,19.5,33.3);


(lib.il_ap = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_apple
	this.instance = new lib.CachedBmp_98();
	this.instance.setTransform(-23.15,-22.8,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_99();
	this.instance_1.setTransform(-23.15,-22.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.1,-22.8,46.5,45.5);


(lib.Path_19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAiAtQgFgDgQgQIglglQgRgQgDgGQgBgEADgFQADgEAEACQAGADAGAGIALALIAlAlQAQAQADAGQADAFgEAEQgDACgCAAIgEgBg");
	this.shape.setTransform(4.535,4.5835);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_19, new cjs.Rectangle(0,0,9.1,9.2), null);


(lib.Path_18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAsA3IhKhIQgSgRgHgJQgEgFAEgGQAEgGAGAEQAMAJAOAPIAXAZIAzAyQAGAGgGAGQgDADgDAAQgCAAgDgDg");
	this.shape.setTransform(5.7875,5.858);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_18, new cjs.Rectangle(0,0,11.6,11.7), null);


(lib.Path_16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAdArQgNgRgTgWQgbgVgKgOQgDgEADgGQADgGAFADQAOAIAZAdQARARAQAVQAEAGgFAGQgCADgDAAQgCAAgDgDg");
	this.shape.setTransform(4.2013,4.544);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_16, new cjs.Rectangle(0,0,8.4,9.2), null);


(lib.Path_15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAYAwQgNgXgSgZQgVgXgJgOQgDgFAEgFQADgGAGAEQANALAVAgQAQAUAOAaQAEAHgHAEIgEABQgDAAgDgEg");
	this.shape.setTransform(3.9035,5.1398);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_15, new cjs.Rectangle(0,0,7.8,10.3), null);


(lib.Path_14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAoA8QgYgegUgYIgXgbQgOgQgJgMQgDgEAEgGQAEgGAFAEQAXAWAYAgQAOAQAeAoQAEAGgFAGQgDADgCAAQgDAAgCgEg");
	this.shape.setTransform(5.2446,6.3226);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_14, new cjs.Rectangle(0,0,10.5,12.7), null);


(lib.Path_13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAgAuQgQgQgUgYIgkgoQgFgFAFgFQAFgGAFAGIAkAnQAWAVAOASQADAEgEAGQgCAEgDAAQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape.setTransform(4.3251,4.7589);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_13, new cjs.Rectangle(0,0,8.7,9.6), null);


(lib.Path_12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAhA9QgPgXhAhYQgEgGAFgFQAFgGAFAGQAmAqAsBIQAEAHgHAEIgEABQgEAAgDgEg");
	this.shape.setTransform(4.8588,6.4988);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_12, new cjs.Rectangle(0,0,9.7,13), null);


(lib.Path_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAoA7QgPgWgbgiIgYgZIgYgbQgEgEAEgFQAFgGAEAEQAWATAcAiQAWAZAUAfQAEAGgFAFQgBABAAAAQgBABgBAAQAAAAgBAAQAAAAgBAAQgCAAgDgDg");
	this.shape.setTransform(5.2842,6.2294);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_11, new cjs.Rectangle(0,0,10.6,12.5), null);


(lib.Path_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAvBHIhOhjIgPgRQgIgKgDgIQgCgDADgEQADgEAEACQAIAFAJALIAPASIAZAhQAaAgATAeIAAAAQAGACgBAIQAAAFgFABIgBAAIgBAAQgBAAgDgCg");
	this.shape.setTransform(5.8535,7.3202);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9, new cjs.Rectangle(0,0,11.7,14.7), null);


(lib.Path_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAoBGQgbgog/hYQgEgGAFgFQAFgGAFAGQAwA/AqBBQAEAGgFAFQgDADgCAAQgDAAgCgDg");
	this.shape.setTransform(5.2453,7.275);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_8, new cjs.Rectangle(0,0,10.5,14.6), null);


(lib.Path_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAVAmQgXgigdgeQgEgEAFgGQAEgGAFAEQAdAfAYAhQAEAGgFAGQgDADgCAAQgDAAgCgDg");
	this.shape.setTransform(3.3198,4.0476);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6, new cjs.Rectangle(0,0,6.7,8.2), null);


(lib.Path_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAwBLQglg5hEhSQgFgGAFgEQAFgFAFAFQA0A2A2BUQAEAGgGAFQgCADgCAAQgDAAgCgDg");
	this.shape.setTransform(6.0276,7.7815);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5, new cjs.Rectangle(0,0,12.1,15.6), null);


(lib.Path_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AArBAQgegfgVgbIgYgdQgSgWgEgJQgDgFAFgEQAFgEAFAEIAXAfIAXAdQAYAcAaAcQAEAGgFAFQgCACgDAAQgDAAgCgCg");
	this.shape.setTransform(5.6036,6.5934);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0,0,11.2,13.2), null);


(lib.Path_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAiA2QgUghgQgUIgWgXQgPgOgHgJQgDgEADgFQADgFAEACQAUAMAeAlQAUAYAQAeQAEAHgHAEIgEACQgEAAgCgFg");
	this.shape.setTransform(4.8727,5.8953);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(0,0,9.8,11.8), null);


(lib.il_li = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_lines
	this.instance = new lib.Path_1();
	this.instance.setTransform(-27.4,29.3,1,1,0,0,0,4.9,5.9);
	this.instance.compositeOperation = "multiply";

	this.instance_1 = new lib.Path_3();
	this.instance_1.setTransform(-15.45,25.75,1,1,0,0,0,5.6,6.5);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_5();
	this.instance_2.setTransform(-20.2,4.9,1,1,0,0,0,6,7.8);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_6();
	this.instance_3.setTransform(-2.4,25.4,1,1,0,0,0,3.3,4);
	this.instance_3.compositeOperation = "multiply";

	this.instance_4 = new lib.Path_8();
	this.instance_4.setTransform(-14.25,-2.65,1,1,0,0,0,5.2,7.2);
	this.instance_4.compositeOperation = "multiply";

	this.instance_5 = new lib.Path_9();
	this.instance_5.setTransform(3.8,14.5,1,1,0,0,0,5.9,7.3);
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.Path_11();
	this.instance_6.setTransform(-19.05,-24.45,1,1,0,0,0,5.2,6.2);
	this.instance_6.compositeOperation = "multiply";

	this.instance_7 = new lib.Path_12();
	this.instance_7.setTransform(-5.6,-11,1,1,0,0,0,4.9,6.5);
	this.instance_7.compositeOperation = "multiply";

	this.instance_8 = new lib.Path_13();
	this.instance_8.setTransform(9,2.5,1,1,0,0,0,4.3,4.8);
	this.instance_8.compositeOperation = "multiply";

	this.instance_9 = new lib.Path_14();
	this.instance_9.setTransform(-9.35,-28.7,1,1,0,0,0,5.2,6.4);
	this.instance_9.compositeOperation = "multiply";

	this.instance_10 = new lib.Path_15();
	this.instance_10.setTransform(3,-16.65,1,1,0,0,0,3.9,5.1);
	this.instance_10.compositeOperation = "multiply";

	this.instance_11 = new lib.Path_16();
	this.instance_11.setTransform(18.7,-3.45,1,1,0,0,0,4.2,4.5);
	this.instance_11.compositeOperation = "multiply";

	this.instance_12 = new lib.Path_18();
	this.instance_12.setTransform(14.6,-21.15,1,1,0,0,0,5.8,5.9);
	this.instance_12.compositeOperation = "multiply";

	this.instance_13 = new lib.Path_19();
	this.instance_13.setTransform(27.8,-8.45,1,1,0,0,0,4.5,4.6);
	this.instance_13.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.3,-35.1,64.69999999999999,70.30000000000001);


// stage content:
(lib.fsm_digital_300x250_v1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [448];
	// timeline functions:
	this.frame_448 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(448).call(this.frame_448).wait(1));

	// border
	this.instance = new lib.CachedBmp_92();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_93();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},448).wait(1));

	// il_ap_sl
	this.instance_2 = new lib.il_apsl("synched",0);
	this.instance_2.setTransform(276.05,-19.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:259.1,y:6.1,startPosition:31},31,cjs.Ease.quartInOut).to({rotation:14.9992,x:271.7,startPosition:170},139,cjs.Ease.quadInOut).to({x:258.7,y:5.2,startPosition:211},41,cjs.Ease.quartInOut).to({y:10,startPosition:324},113,cjs.Ease.quadInOut).to({y:5.2,startPosition:418},94,cjs.Ease.quadInOut).to({x:208.55,y:0.4,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// il_ap
	this.instance_3 = new lib.il_ap("synched",0);
	this.instance_3.setTransform(235.05,-30.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:227.25,y:40.75,startPosition:31},31,cjs.Ease.quartInOut).to({rotation:-14.9992,x:226.05,y:38.3,startPosition:170},139,cjs.Ease.quadInOut).to({x:216.7,y:38,startPosition:211},41,cjs.Ease.quartInOut).to({rotation:0,x:217.9,y:43.4,startPosition:324},113,cjs.Ease.quadInOut).to({rotation:-14.9992,x:216.7,y:38,startPosition:418},94,cjs.Ease.quadInOut).to({x:181.75,y:47,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// il_or
	this.instance_4 = new lib.il_or("synched",0);
	this.instance_4.setTransform(329,92.75);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({x:275.3,y:98.2,startPosition:31},31,cjs.Ease.quartInOut).to({rotation:29.9992,x:278.3,startPosition:170},139,cjs.Ease.quadInOut).to({regX:0.1,regY:-0.1,rotation:89.9991,x:272.5,y:79.05,startPosition:211},41,cjs.Ease.quartInOut).to({scaleX:0.9999,scaleY:0.9999,rotation:74.9999,x:274.3,y:78.45,startPosition:324},113,cjs.Ease.quadInOut).to({scaleX:1,scaleY:1,rotation:89.9991,x:272.5,y:79.05,startPosition:418},94,cjs.Ease.quadInOut).to({regY:0,scaleX:0.9999,scaleY:0.9999,rotation:0,x:263.6,y:45.15,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// il_mlk
	this.instance_5 = new lib.il_mlk("synched",0);
	this.instance_5.setTransform(342.1,222.75);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:263.95,y:180.15,startPosition:31},31,cjs.Ease.quartInOut).to({rotation:29.9992,y:188.55,startPosition:170},139,cjs.Ease.quadInOut).to({x:276.8,y:184.7,startPosition:211},41,cjs.Ease.quartInOut).to({regX:0.1,regY:-0.1,rotation:44.9988,x:263.65,y:171.15,startPosition:324},113,cjs.Ease.quadInOut).to({regX:0,regY:0,rotation:29.9992,x:276.8,y:178.15,startPosition:418},94,cjs.Ease.quadInOut).to({rotation:0,x:262.85,y:169.65,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// il_ban
	this.instance_6 = new lib.il_ban("synched",0);
	this.instance_6.setTransform(-30.55,224.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({x:39.95,y:186.8,startPosition:31},31,cjs.Ease.quartInOut).to({rotation:14.9992,x:39.9,y:196.4,startPosition:170},139,cjs.Ease.quadInOut).to({x:40.2,y:175.4,startPosition:211},41,cjs.Ease.quartInOut).to({rotation:29.9984,x:40.55,y:173.6,startPosition:324},113,cjs.Ease.quadInOut).to({rotation:14.9992,x:42.25,y:172.55,startPosition:418},94,cjs.Ease.quadInOut).to({rotation:0,x:39.45,y:165.45,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// il_rz
	this.instance_7 = new lib.il_rz("synched",0);
	this.instance_7.setTransform(-23.55,153.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({x:28.45,y:144.35,startPosition:31},31,cjs.Ease.quartInOut).to({rotation:14.9992,x:23,y:144.95,startPosition:170},139,cjs.Ease.quadInOut).to({x:0,y:106.35,startPosition:211},41,cjs.Ease.quartInOut).to({rotation:0,x:-1.15,y:102.15,startPosition:324},113,cjs.Ease.quadInOut).to({rotation:14.9992,x:0,y:106.35,startPosition:418},94,cjs.Ease.quadInOut).to({x:82.8,y:18.4,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// il_car
	this.instance_8 = new lib.il_car("synched",0);
	this.instance_8.setTransform(-30,69.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({x:54.15,startPosition:31},31,cjs.Ease.quartInOut).to({rotation:14.9992,y:62.4,startPosition:170},139,cjs.Ease.quadInOut).to({x:56.3,y:55.25,startPosition:211},41,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,rotation:29.9977,x:51.6,y:52.35,startPosition:324},113,cjs.Ease.quadInOut).to({regX:-1.1,regY:-4.5,rotation:14.9994,x:56.4,y:46.5,startPosition:418},94,cjs.Ease.quadInOut).to({regX:-1,scaleX:0.9999,scaleY:0.9999,rotation:29.9985,x:20.45,y:63.2,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// il_li
	this.instance_9 = new lib.il_li("synched",0);
	this.instance_9.setTransform(-13.55,-18.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({x:22.75,y:27.2,startPosition:31},31,cjs.Ease.quartInOut).to({x:28.75,y:24.8,startPosition:170},139,cjs.Ease.quadInOut).to({x:22.35,y:11.4,startPosition:211},41,cjs.Ease.quartInOut).to({x:21.15,y:4.2,startPosition:324},113,cjs.Ease.quadInOut).to({x:22.35,y:11.4,startPosition:418},94,cjs.Ease.quadInOut).to({x:26.75,y:4.55,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// sh_y
	this.instance_10 = new lib.sh_y("synched",0);
	this.instance_10.setTransform(-27.6,256.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({x:-6.05,y:233.3,startPosition:31},31,cjs.Ease.quartInOut).to({startPosition:170},139,cjs.Ease.quadInOut).to({rotation:5.231,y:229,startPosition:211},41,cjs.Ease.quartInOut).to({rotation:7.7063,y:227.05,startPosition:324},113,cjs.Ease.quadInOut).to({rotation:0,x:-8.5,y:222.85,startPosition:418},94,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,rotation:-5.5138,x:5.3,y:239,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// sh_g
	this.instance_11 = new lib.sh_g("synched",0);
	this.instance_11.setTransform(-17.45,-18.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({x:3.65,y:23.3,startPosition:31},31,cjs.Ease.quartInOut).to({rotation:14.9992,x:1.8,y:26.3,startPosition:170},139,cjs.Ease.quadInOut).to({y:11.7,startPosition:211},41,cjs.Ease.quartInOut).to({y:9.3,startPosition:324},113,cjs.Ease.quadInOut).to({y:11.7,startPosition:418},94,cjs.Ease.quadInOut).to({x:16.75,y:5.75,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// sh_red
	this.instance_12 = new lib.sh_red("synched",0);
	this.instance_12.setTransform(344.8,245.15);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({x:315.1,y:217.3,startPosition:31},31,cjs.Ease.quartInOut).to({rotation:6.7474,x:313.3,y:221.5,startPosition:170},139,cjs.Ease.quadInOut).to({x:312.7,y:233.15,startPosition:211},41,cjs.Ease.quartInOut).to({x:313.4,y:229.55,startPosition:324},113,cjs.Ease.quadInOut).to({x:312.7,y:237.65,startPosition:418},94,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,rotation:-6.6859,x:302.75,y:231.15,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// sh_lt_b
	this.instance_13 = new lib.sh_ltb("synched",0);
	this.instance_13.setTransform(358.7,79.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({x:316.6,y:86.3,startPosition:31},31,cjs.Ease.quartInOut).to({x:319,y:83.9,startPosition:170},139,cjs.Ease.quadInOut).to({y:72.05,startPosition:211},41,cjs.Ease.quartInOut).to({x:322,y:69.65,startPosition:324},113,cjs.Ease.quadInOut).to({x:319,y:72.05,startPosition:418},94,cjs.Ease.quadInOut).to({rotation:-21.9594,x:293.2,y:19.4,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// sh_d_b
	this.instance_14 = new lib.sh_db("synched",0);
	this.instance_14.setTransform(124.4,-44.15);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({y:6,startPosition:31},31,cjs.Ease.quartInOut).to({rotation:4.9958,x:128.55,y:-1.65,startPosition:170},139,cjs.Ease.quadInOut).to({rotation:-4.4615,y:-0.65,startPosition:211},41,cjs.Ease.quartInOut).to({y:-2.45,startPosition:324},113,cjs.Ease.quadInOut).to({y:-0.65,startPosition:418},94,cjs.Ease.quadInOut).to({rotation:10.5375,x:115.5,y:-24.55,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// txt3_bars
	this.instance_15 = new lib.Symbol2();
	this.instance_15.setTransform(152,86.35,1,1,0,0,0,122.2,21.9);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.instance_16 = new lib.CachedBmp_94();
	this.instance_16.setTransform(29.05,81.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_15}]},428).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).wait(8));
	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(428).to({_off:false},0).wait(1).to({regY:22,y:93.9,alpha:0.4491},0).wait(1).to({y:96.8,alpha:0.6049},0).wait(1).to({y:98.75,alpha:0.7092},0).wait(1).to({y:100.2,alpha:0.7863},0).wait(1).to({y:101.35,alpha:0.8454},0).wait(1).to({y:102.25,alpha:0.8917},0).wait(1).to({y:103,alpha:0.9276},0).wait(1).to({y:103.55,alpha:0.9551},0).wait(1).to({y:103.95,alpha:0.9753},0).wait(1).to({y:104.25,alpha:0.9893},0).wait(1).to({y:104.4,alpha:0.9973},0).wait(1).to({y:104.5,alpha:1},0).to({_off:true},1).wait(8));

	// txt3_meals
	this.instance_17 = new lib.Symbol3();
	this.instance_17.setTransform(222.7,87,1,1,0,0,0,52.1,11.8);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.instance_18 = new lib.CachedBmp_95();
	this.instance_18.setTransform(170.6,93.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_17}]},425).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).wait(11));
	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(425).to({_off:false},0).wait(1).to({regX:52,x:222.6,y:94.45,alpha:0.4491},0).wait(1).to({y:97.35,alpha:0.6049},0).wait(1).to({y:99.3,alpha:0.7092},0).wait(1).to({y:100.75,alpha:0.7863},0).wait(1).to({y:101.9,alpha:0.8454},0).wait(1).to({y:102.8,alpha:0.8917},0).wait(1).to({y:103.55,alpha:0.9276},0).wait(1).to({y:104.1,alpha:0.9551},0).wait(1).to({y:104.5,alpha:0.9753},0).wait(1).to({y:104.8,alpha:0.9893},0).wait(1).to({y:104.95,alpha:0.9973},0).wait(1).to({y:105.05,alpha:1},0).to({_off:true},1).wait(11));

	// txt3_summer
	this.instance_19 = new lib.Symbol4();
	this.instance_19.setTransform(123.1,84.85,1,1,0,0,0,46,8.9);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;

	this.instance_20 = new lib.CachedBmp_96();
	this.instance_20.setTransform(77.1,94,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_19}]},422).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(422).to({_off:false},0).wait(1).to({regY:9,y:92.4,alpha:0.4491},0).wait(1).to({y:95.3,alpha:0.6049},0).wait(1).to({y:97.25,alpha:0.7092},0).wait(1).to({y:98.7,alpha:0.7863},0).wait(1).to({y:99.85,alpha:0.8454},0).wait(1).to({y:100.75,alpha:0.8917},0).wait(1).to({y:101.5,alpha:0.9276},0).wait(1).to({y:102.05,alpha:0.9551},0).wait(1).to({y:102.45,alpha:0.9753},0).wait(1).to({y:102.75,alpha:0.9893},0).wait(1).to({y:102.9,alpha:0.9973},0).wait(1).to({y:103,alpha:1},0).to({_off:true},1).wait(14));

	// txt3_free
	this.instance_21 = new lib.Symbol5();
	this.instance_21.setTransform(52.85,85,1,1,0,0,0,23.2,8.8);
	this.instance_21.alpha = 0;
	this.instance_21._off = true;

	this.instance_22 = new lib.CachedBmp_97();
	this.instance_22.setTransform(29.65,94.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_21}]},419).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).wait(17));
	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(419).to({_off:false},0).wait(1).to({y:92.45,alpha:0.4491},0).wait(1).to({y:95.35,alpha:0.6049},0).wait(1).to({y:97.3,alpha:0.7092},0).wait(1).to({y:98.75,alpha:0.7863},0).wait(1).to({y:99.9,alpha:0.8454},0).wait(1).to({y:100.8,alpha:0.8917},0).wait(1).to({y:101.55,alpha:0.9276},0).wait(1).to({y:102.1,alpha:0.9551},0).wait(1).to({y:102.5,alpha:0.9753},0).wait(1).to({y:102.8,alpha:0.9893},0).wait(1).to({y:102.95,alpha:0.9973},0).wait(1).to({y:103.05,alpha:1},0).to({_off:true},1).wait(17));

	// txt2_button
	this.instance_23 = new lib.txt2_button("synched",0);
	this.instance_23.setTransform(149.95,142.2);
	this.instance_23.alpha = 0;
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(434).to({_off:false},0).wait(1).to({y:150.2834,alpha:0.4887},0).wait(1).to({y:153.4662,alpha:0.6621},0).wait(1).to({y:155.6698,alpha:0.7801},0).wait(1).to({y:157.3545,alpha:0.869},0).wait(1).to({y:158.6962,alpha:0.9388},0).wait(1).to({y:159.7867,alpha:0.9949},0).wait(1).to({y:160.25,alpha:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1));

	// txt2_logos_v3
	this.instance_24 = new lib.txt2_logos_v3("synched",0);
	this.instance_24.setTransform(150,258.4);
	this.instance_24.alpha = 0;
	this.instance_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(187).to({_off:false},0).wait(1).to({regY:0.1,y:242.55,alpha:0.4491},0).wait(1).to({y:236.45,alpha:0.6049},0).wait(1).to({y:232.3,alpha:0.7092},0).wait(1).to({y:229.15,alpha:0.7863},0).wait(1).to({y:226.7,alpha:0.8454},0).wait(1).to({y:224.8,alpha:0.8917},0).wait(1).to({y:223.25,alpha:0.9276},0).wait(1).to({y:222.05,alpha:0.9551},0).wait(1).to({y:221.2,alpha:0.9753},0).wait(1).to({y:220.55,alpha:0.9893},0).wait(1).to({y:220.2,alpha:0.9973},0).wait(1).to({y:220.1,alpha:1},0).wait(1).to({regY:0,y:220.6},0).wait(249));

	// txt2_v2
	this.instance_25 = new lib.txt2_v2("synched",0);
	this.instance_25.setTransform(149.2,97);
	this.instance_25.alpha = 0;
	this.instance_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(172).to({_off:false},0).wait(1).to({y:104.4787,alpha:0.4491},0).wait(1).to({y:107.3502,alpha:0.6049},0).wait(1).to({y:109.3101,alpha:0.7092},0).wait(1).to({y:110.7827,alpha:0.7863},0).wait(1).to({y:111.9304,alpha:0.8454},0).wait(1).to({y:112.8389,alpha:0.8917},0).wait(1).to({y:113.5564,alpha:0.9276},0).wait(1).to({y:114.1144,alpha:0.9551},0).wait(1).to({y:114.5311,alpha:0.9753},0).wait(1).to({y:114.8214,alpha:0.9893},0).wait(1).to({y:114.9928,alpha:0.9973},0).wait(1).to({y:115.05,alpha:1},0).wait(1).to({startPosition:0},0).wait(218).to({startPosition:0},0).wait(1).to({y:115.0262,alpha:0.9982},0).wait(1).to({y:114.9487,alpha:0.9923},0).wait(1).to({y:114.8096,alpha:0.9816},0).wait(1).to({y:114.5982,alpha:0.9652},0).wait(1).to({y:114.3005,alpha:0.9419},0).wait(1).to({y:113.8988,alpha:0.9101},0).wait(1).to({y:113.3695,alpha:0.8676},0).wait(1).to({y:112.6807,alpha:0.8113},0).wait(1).to({y:111.785,alpha:0.7365},0).wait(1).to({y:110.6118,alpha:0.6361},0).wait(1).to({y:109.0458,alpha:0.4978},0).wait(1).to({y:106.8712,alpha:0.2998},0).wait(1).to({y:103.6,alpha:0},0).to({_off:true},1).wait(32));

	// txt1
	this.instance_26 = new lib.title("synched",0);
	this.instance_26.setTransform(143.25,134.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(149).to({startPosition:0},0).wait(1).to({regY:-0.1,y:134.3,alpha:0.9982},0).wait(1).to({y:134.2,alpha:0.9923},0).wait(1).to({y:134.1,alpha:0.9816},0).wait(1).to({y:133.85,alpha:0.9652},0).wait(1).to({y:133.6,alpha:0.9419},0).wait(1).to({y:133.15,alpha:0.9101},0).wait(1).to({y:132.65,alpha:0.8676},0).wait(1).to({y:131.95,alpha:0.8113},0).wait(1).to({y:131.05,alpha:0.7365},0).wait(1).to({y:129.9,alpha:0.6361},0).wait(1).to({y:128.3,alpha:0.4978},0).wait(1).to({y:126.15,alpha:0.2998},0).wait(1).to({y:122.9,alpha:0},0).to({_off:true},1).wait(286));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ECF8FD").s().p("A3aTiMAAAgnDMAu1AAAMAAAAnDg");
	this.shape.setTransform(150.075,124.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	// stageBackground
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("A4/1FMAx/AAAMAAAAqLMgx/AAAg");
	this.shape_1.setTransform(150,125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("A4/VGMAAAgqLMAx/AAAMAAAAqLg");
	this.shape_2.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(449));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(82.6,39.2,324.1,255.60000000000002);
// library properties:
lib.properties = {
	id: '51C29B3F566DCA459FEE44EC96F655BE',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/fsm_digital_300x250_v1_atlas_1.png", id:"fsm_digital_300x250_v1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['51C29B3F566DCA459FEE44EC96F655BE'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;