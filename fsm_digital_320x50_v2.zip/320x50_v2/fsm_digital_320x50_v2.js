(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"fsm_digital_320x50_v2_atlas_1", frames: [[0,0,1040,93],[1841,104,112,22],[1841,73,127,29],[1841,128,57,21],[1042,80,299,55],[1605,73,234,102],[0,95,1040,41],[1042,0,561,78],[1605,0,433,71],[2000,124,32,27],[1970,73,57,49],[1955,124,43,43]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_131 = function() {
	this.initialize(ss["fsm_digital_320x50_v2_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_130 = function() {
	this.initialize(ss["fsm_digital_320x50_v2_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_129 = function() {
	this.initialize(ss["fsm_digital_320x50_v2_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_128 = function() {
	this.initialize(ss["fsm_digital_320x50_v2_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_127 = function() {
	this.initialize(ss["fsm_digital_320x50_v2_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_126 = function() {
	this.initialize(ss["fsm_digital_320x50_v2_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_125 = function() {
	this.initialize(ss["fsm_digital_320x50_v2_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_124 = function() {
	this.initialize(ss["fsm_digital_320x50_v2_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_123 = function() {
	this.initialize(ss["fsm_digital_320x50_v2_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_122 = function() {
	this.initialize(ss["fsm_digital_320x50_v2_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_121 = function() {
	this.initialize(ss["fsm_digital_320x50_v2_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_120 = function() {
	this.initialize(ss["fsm_digital_320x50_v2_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_save_horizontal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt_save
	this.instance = new lib.CachedBmp_131();
	this.instance.setTransform(-277.7,-18.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-277.7,-18.6,520,46.5);


(lib.t3summer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_summer
	this.instance = new lib.CachedBmp_130();
	this.instance.setTransform(-27.95,-5.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.9,-5.4,56,11);


(lib.t3meals = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_meals
	this.instance = new lib.CachedBmp_129();
	this.instance.setTransform(-31.7,-7.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.7,-7.1,63.5,14.5);


(lib.t3free = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_free
	this.instance = new lib.CachedBmp_128();
	this.instance.setTransform(-14.15,-5.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.1,-5.3,28.5,10.5);


(lib.t3bars = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_bars
	this.instance = new lib.CachedBmp_127();
	this.instance.setTransform(-74.8,-13.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-74.8,-13.8,149.5,27.5);


(lib.t2logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2_logos
	this.instance = new lib.CachedBmp_126();
	this.instance.setTransform(-58.6,-25.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-58.6,-25.4,117,51);


(lib.t2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2
	this.instance = new lib.CachedBmp_125();
	this.instance.setTransform(-260.7,-10.55,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_124();
	this.instance_1.setTransform(-140.2,-19.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-260.7,-19.5,520,39);


(lib.t1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt1
	this.instance = new lib.CachedBmp_123();
	this.instance.setTransform(-108.35,-17.65,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.3,-17.6,216.5,35.5);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_dark_blue
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#224EA2").s().p("ACxD0Qg4gNgjgqIgUgcQgMgRgLgJQgWgTgkgHQgWgEgvgCQgzgBglgGQgwgIglgRQgqgSgfggQghgggLgpQgFgVgBgXIgBgUQgBgNACgHQACgFAEgFIAHgIQALgOAKgKQAWgVAdgPQA2geBCgEQA2gDA/ANQAvAKBCAWQBYAdA4AdQBLAoAwA0QAyA4AJA6QAIA2gcAzQgcAzgyAWQgfANghAAQgVAAgVgFg");
	this.shape.setTransform(-0.0161,0.0286);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(143).to({_off:true},1).wait(11).to({_off:false},0).wait(136).to({_off:true},1).wait(103).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38.2,-24.9,76.5,49.9);


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_red
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EA6241").s().p("AAAGlQgGgEgNgLQg+g2hNgfQgngQgogJQgWgFgSgCQgJgBglgCQgcgCgRgFQgqgNgWgtQgLgUgEgeQgKhGAjg/QAqhHBggyQAVgLAqgSIALgGQAFgDAZgJQAogOAdgRQAVgMALgMIAPgVQAQgXgCgTQgCgMgKgSQgNgVgDgIQgGgSAHgTQAGgUARgPQAXgTAqgNQAxgOA1gBQAOAAAfADQAdADAQgBQAUgCAXAGQANADAaAKQAoAOAiAVQBCApATA3IAEANQAJAjgSAbQgGAKgMALIgUATQgrAogZBZQggBygOAZQgLAWgVAcIgjAvQg0BOgbAlQgvBBgxAfQgPAIgHABIgDAAQgJAAgLgGg");
	this.shape.setTransform(-0.0071,0.0313);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(143).to({_off:true},1).wait(11).to({_off:false},0).wait(136).to({_off:true},1).wait(103).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-45,-42.6,90.1,85.30000000000001);


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus
	this.instance = new lib.CachedBmp_122();
	this.instance.setTransform(-8.1,-6.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(143).to({_off:true},1).wait(11).to({_off:false},0).wait(136).to({_off:true},1).wait(103).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.1,-6.8,16,13.5);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_milk
	this.instance = new lib.CachedBmp_121();
	this.instance.setTransform(-14.05,-12.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(143).to({_off:true},1).wait(11).to({_off:false},0).wait(136).to({_off:true},1).wait(103).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14,-12.2,28.5,24.5);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_apple
	this.instance = new lib.CachedBmp_120();
	this.instance.setTransform(-10.7,-10.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(143).to({_off:true},1).wait(11).to({_off:false},0).wait(136).to({_off:true},1).wait(103).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.7,-10.6,21.5,21.5);


(lib.Path_19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgNAkIAEgUIAJghQACgPACgEQACgDAEABQAEABAAAEQAAAEgEAOIgIAiQgDAPgCADQgCADgEAAQgDgBgBgDg");
	this.shape.setTransform(1.375,3.9389);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_19, new cjs.Rectangle(0,0,2.8,7.9), null);


(lib.Path_18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgLAzQgFAAAAgFQABgJAEgOIAGgXIALgtQABgFAGABQAFABgBAFIgRBDQgCAQgDAHQgBAEgEAAIgBAAg");
	this.shape.setTransform(1.6811,5.0442);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_18, new cjs.Rectangle(0,0,3.4,10.1), null);


(lib.Path_16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgOAiQAAgMAIgXQADgOAHgSQABgEAGABQAFABgCAFIgLAfIgDARQgBAKgDAGQgBADgEAAIgBAAQgDAAgBgDg");
	this.shape.setTransform(1.4501,3.7187);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_16, new cjs.Rectangle(0,0,2.9,7.5), null);


(lib.Path_13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgLAnQgFgBACgFQAQg6ADgJQABgEAFAAQAFAAgBAFQgDAOgGAUIgLAiQgBAEgDAAIgCAAg");
	this.shape.setTransform(1.566,3.8813);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_13, new cjs.Rectangle(0,0,3.1,7.8), null);


(lib.Path_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgUA5QgBAAgBgBQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAgGADgJIAFgPIAKgaQAJgaALgVQgBgEAFgCQACgBADACIABAAQAAABAAAAQABABAAAAQAAABAAAAQAAABgBAAIgdBPIgFANQgCAJgEAEQAAAAAAABQgBAAAAAAQAAAAgBABQAAAAgBAAIgBAAg");
	this.shape.setTransform(2.47,5.6479);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9, new cjs.Rectangle(0,0,5,11.3), null);


(lib.Path_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgKAeQgEAAAAgEQAHgaALgaQACgFAFABQAFABgCAFQgKAXgIAcQgBAEgDAAIgCgBg");
	this.shape.setTransform(1.4761,3.0509);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6, new cjs.Rectangle(0,0,3,6.1), null);


(lib.Path_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgSA0QgEgCABgEIAJgXIAYhHQABgEAFABQAFABgBAFQgIAbgIAVIgIAYIgKAXQAAABAAAAQgBABAAAAQgBAAAAAAQgBABgBAAIgCgBg");
	this.shape.setTransform(2.1733,5.2384);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0,0,4.4,10.5), null);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_lines
	this.instance = new lib.Path_3();
	this.instance.setTransform(18.25,5.8,1,1,0,0,0,2.1,5.2);
	this.instance.compositeOperation = "multiply";

	this.instance_1 = new lib.Path_6();
	this.instance_1.setTransform(13.55,-1.45,1,1,0,0,0,1.4,3.1);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_9();
	this.instance_2.setTransform(5.35,-1.2,1,1,0,0,0,2.5,5.7);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_13();
	this.instance_3.setTransform(-3.35,-0.1,1,1,0,0,0,1.6,3.9);
	this.instance_3.compositeOperation = "multiply";

	this.instance_4 = new lib.Path_16();
	this.instance_4.setTransform(-10.05,-3.65,1,1,0,0,0,1.4,3.7);
	this.instance_4.compositeOperation = "multiply";

	this.instance_5 = new lib.Path_18();
	this.instance_5.setTransform(-18.75,4.75,1,1,0,0,0,1.7,5);
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.Path_19();
	this.instance_6.setTransform(-16,-7.05,1,1,0,0,0,1.4,4);
	this.instance_6.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},143).to({state:[]},1).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},11).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},136).to({state:[]},1).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},103).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20.4,-11,40.9,22.1);


// stage content:
(lib.fsm_digital_320x50_v2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [448];
	// timeline functions:
	this.frame_448 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(448).call(this.frame_448).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A4/D6IAAnzMAx/AAAIAAHzgA48D3MAx5AAAIAAntMgx5AAAg");
	this.shape.setTransform(160,25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	// Symbol_1
	this.instance = new lib.Symbol1("synched",0);
	this.instance.setTransform(-25.5,1.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({startPosition:0},144,cjs.Ease.quartInOut).to({x:30.2,y:13.75,startPosition:29},23,cjs.Ease.quartInOut).to({rotation:14.9992,x:26.9,y:13.85,startPosition:155},91,cjs.Ease.quadInOut).to({x:16.7,y:13.75,startPosition:182},27,cjs.Ease.quartInOut).to({regX:0.1,regY:0.1,rotation:29.9984,x:16.75,y:16.95,startPosition:395},110,cjs.Ease.quadInOut).to({regX:0,regY:0,rotation:14.9992,x:3.2,y:-17.35,startPosition:431},36,cjs.Ease.quartInOut).wait(18));

	// Symbol_2
	this.instance_1 = new lib.Symbol2("synched",0);
	this.instance_1.setTransform(305.85,-14.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({startPosition:0},144,cjs.Ease.quartInOut).to({x:291.15,y:19.05,startPosition:29},23,cjs.Ease.quartInOut).to({rotation:14.9992,y:15.55,startPosition:155},91,cjs.Ease.quadInOut).to({x:306.35,y:16.25,startPosition:182},27,cjs.Ease.quartInOut).to({regX:0.1,regY:-0.1,rotation:44.9988,x:306.45,y:21.5,startPosition:395},110,cjs.Ease.quadInOut).to({regX:0,regY:0,rotation:14.9992,x:336.8,y:-0.95,startPosition:431},36,cjs.Ease.quartInOut).wait(18));

	// Symbol_3
	this.instance_2 = new lib.Symbol3("synched",0);
	this.instance_2.setTransform(82.5,67.65);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({startPosition:0},144,cjs.Ease.quartInOut).to({x:87.4,y:48,startPosition:29},23,cjs.Ease.quartInOut).to({rotation:-14.9992,x:85.35,y:50.85,startPosition:155},91,cjs.Ease.quadInOut).to({rotation:0,x:87.4,y:63.15,startPosition:182},27,cjs.Ease.quartInOut).to({startPosition:395},110,cjs.Ease.quadInOut).to({startPosition:431},36,cjs.Ease.quartInOut).wait(18));

	// Symbol_4
	this.instance_3 = new lib.Symbol4("synched",0);
	this.instance_3.setTransform(210.3,63.45);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({startPosition:0},144,cjs.Ease.quartInOut).to({x:201.3,y:41.75,startPosition:29},23,cjs.Ease.quartInOut).to({rotation:14.9992,startPosition:155},91,cjs.Ease.quadInOut).to({rotation:0,y:64.3,startPosition:182},27,cjs.Ease.quartInOut).to({startPosition:395},110,cjs.Ease.quadInOut).to({startPosition:431},36,cjs.Ease.quartInOut).wait(18));

	// Symbol_5
	this.instance_4 = new lib.Symbol5("synched",0);
	this.instance_4.setTransform(331.45,54.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({rotation:6.4429,x:322.6},144,cjs.Ease.quartInOut).to({rotation:0,x:320,y:45.9,startPosition:29},23,cjs.Ease.quartInOut).to({rotation:7.4814,x:319.5,y:53.3,startPosition:155},91,cjs.Ease.quadInOut).to({rotation:14.9992,x:314.7,y:62.3,startPosition:182},27,cjs.Ease.quartInOut).to({regX:0.1,regY:0.1,rotation:29.9984,x:314.8,y:63.4,startPosition:395},110,cjs.Ease.quadInOut).to({regX:0,regY:0,rotation:14.9992,x:325.75,y:71.15,startPosition:431},36,cjs.Ease.quartInOut).wait(18));

	// Symbol_6
	this.instance_5 = new lib.Symbol6("synched",0);
	this.instance_5.setTransform(-8.3,56.25);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({rotation:4.9449,x:1.2,y:53.8},144,cjs.Ease.quartInOut).to({rotation:0,x:5.6,y:42.7,startPosition:29},23,cjs.Ease.quartInOut).to({rotation:-4.7062,x:10.1,y:48.45,startPosition:155},91,cjs.Ease.quadInOut).to({rotation:0,x:-3.4,y:49.3,startPosition:182},27,cjs.Ease.quartInOut).to({x:8.85,y:55.85,startPosition:395},110,cjs.Ease.quadInOut).to({x:-28.75,y:67.3,startPosition:431},36,cjs.Ease.quartInOut).wait(18));

	// t3_bars
	this.instance_6 = new lib.t3bars("synched",0);
	this.instance_6.setTransform(101.2,6.4);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(424).to({_off:false},0).wait(1).to({y:13.8787,alpha:0.4491},0).wait(1).to({y:16.7502,alpha:0.6049},0).wait(1).to({y:18.7101,alpha:0.7092},0).wait(1).to({y:20.1827,alpha:0.7863},0).wait(1).to({y:21.3304,alpha:0.8454},0).wait(1).to({y:22.2389,alpha:0.8917},0).wait(1).to({y:22.9564,alpha:0.9276},0).wait(1).to({y:23.5144,alpha:0.9551},0).wait(1).to({y:23.9311,alpha:0.9753},0).wait(1).to({y:24.2214,alpha:0.9893},0).wait(1).to({y:24.3928,alpha:0.9973},0).wait(1).to({y:24.45,alpha:1},0).wait(1).to({startPosition:0},0).wait(12));

	// t3_meals
	this.instance_7 = new lib.t3meals("synched",0);
	this.instance_7.setTransform(144.25,6.75);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(420).to({_off:false},0).wait(1).to({y:14.2287,alpha:0.4491},0).wait(1).to({y:17.1002,alpha:0.6049},0).wait(1).to({y:19.0601,alpha:0.7092},0).wait(1).to({y:20.5327,alpha:0.7863},0).wait(1).to({y:21.6804,alpha:0.8454},0).wait(1).to({y:22.5889,alpha:0.8917},0).wait(1).to({y:23.3064,alpha:0.9276},0).wait(1).to({y:23.8644,alpha:0.9551},0).wait(1).to({y:24.2811,alpha:0.9753},0).wait(1).to({y:24.5714,alpha:0.9893},0).wait(1).to({y:24.7428,alpha:0.9973},0).wait(1).to({y:24.8,alpha:1},0).wait(1).to({startPosition:0},0).wait(16));

	// t3_summer
	this.instance_8 = new lib.t3summer("synched",0);
	this.instance_8.setTransform(83.65,5.5);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(416).to({_off:false},0).wait(1).to({y:12.9787,alpha:0.4491},0).wait(1).to({y:15.8502,alpha:0.6049},0).wait(1).to({y:17.8101,alpha:0.7092},0).wait(1).to({y:19.2827,alpha:0.7863},0).wait(1).to({y:20.4304,alpha:0.8454},0).wait(1).to({y:21.3389,alpha:0.8917},0).wait(1).to({y:22.0564,alpha:0.9276},0).wait(1).to({y:22.6144,alpha:0.9551},0).wait(1).to({y:23.0311,alpha:0.9753},0).wait(1).to({y:23.3214,alpha:0.9893},0).wait(1).to({y:23.4928,alpha:0.9973},0).wait(1).to({y:23.55,alpha:1},0).wait(1).to({startPosition:0},0).wait(20));

	// t3_free
	this.instance_9 = new lib.t3free("synched",0);
	this.instance_9.setTransform(40.95,5.6);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(412).to({_off:false},0).wait(1).to({regX:0.1,regY:-0.1,x:41.05,y:12.95,alpha:0.4491},0).wait(1).to({y:15.85,alpha:0.6049},0).wait(1).to({y:17.8,alpha:0.7092},0).wait(1).to({y:19.25,alpha:0.7863},0).wait(1).to({y:20.4,alpha:0.8454},0).wait(1).to({y:21.3,alpha:0.8917},0).wait(1).to({y:22.05,alpha:0.9276},0).wait(1).to({y:22.6,alpha:0.9551},0).wait(1).to({y:23,alpha:0.9753},0).wait(1).to({y:23.3,alpha:0.9893},0).wait(1).to({y:23.45,alpha:0.9973},0).wait(1).to({y:23.55,alpha:1},0).wait(1).to({regX:0,regY:0,x:40.95,y:23.65},0).wait(24));

	// t2_logos
	this.instance_10 = new lib.t2logos("synched",0);
	this.instance_10.setTransform(300.65,25.85);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(433).to({_off:false},0).wait(1).to({regX:-0.1,regY:0.1,x:297.3,y:25.6,alpha:0.4491},0).wait(1).to({x:294.05,y:25.5,alpha:0.6049},0).wait(1).to({x:290.8,y:25.4,alpha:0.7092},0).wait(1).to({x:287.55,y:25.35,alpha:0.7863},0).wait(1).to({x:284.3,y:25.3,alpha:0.8454},0).wait(1).to({x:281.1,y:25.25,alpha:0.8917},0).wait(1).to({x:277.85,alpha:0.9276},0).wait(1).to({x:274.6,y:25.2,alpha:0.9551},0).wait(1).to({x:271.35,alpha:0.9753},0).wait(1).to({x:268.1,alpha:0.9893},0).wait(1).to({x:264.85,alpha:0.9973},0).wait(1).to({x:261.65,alpha:1},0).wait(1).to({regX:0,regY:0,x:261.75,y:24.65},0).wait(3));

	// t2
	this.instance_11 = new lib.t2("synched",0);
	this.instance_11.setTransform(160.05,6.9);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(264).to({_off:false},0).wait(1).to({regX:-0.7,x:159.35,y:14.35,alpha:0.4491},0).wait(1).to({y:17.25,alpha:0.6049},0).wait(1).to({y:19.2,alpha:0.7092},0).wait(1).to({y:20.65,alpha:0.7863},0).wait(1).to({y:21.8,alpha:0.8454},0).wait(1).to({y:22.7,alpha:0.8917},0).wait(1).to({y:23.45,alpha:0.9276},0).wait(1).to({y:24,alpha:0.9551},0).wait(1).to({y:24.4,alpha:0.9753},0).wait(1).to({y:24.7,alpha:0.9893},0).wait(1).to({y:24.85,alpha:0.9973},0).wait(1).to({y:24.95,alpha:1},0).wait(1).to({regX:0,x:160.05},0).wait(125).to({startPosition:0},0).wait(1).to({regX:-0.7,x:159.35,y:24.9,alpha:0.9982},0).wait(1).to({y:24.8,alpha:0.9923},0).wait(1).to({y:24.7,alpha:0.9816},0).wait(1).to({y:24.45,alpha:0.9652},0).wait(1).to({y:24.2,alpha:0.9419},0).wait(1).to({y:23.75,alpha:0.9101},0).wait(1).to({y:23.25,alpha:0.8676},0).wait(1).to({y:22.55,alpha:0.8113},0).wait(1).to({y:21.65,alpha:0.7365},0).wait(1).to({y:20.5,alpha:0.6361},0).wait(1).to({y:18.9,alpha:0.4978},0).wait(1).to({y:16.75,alpha:0.2998},0).wait(1).to({y:13.5,alpha:0},0).to({_off:true},1).wait(33));

	// t1
	this.instance_12 = new lib.t1("synched",0);
	this.instance_12.setTransform(160.95,26.95);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(142).to({_off:false},0).wait(105).to({startPosition:0},0).wait(1).to({regX:-0.1,regY:0.1,x:160.85,y:27,alpha:0.9982},0).wait(1).to({y:26.9,alpha:0.9923},0).wait(1).to({y:26.8,alpha:0.9816},0).wait(1).to({y:26.55,alpha:0.9652},0).wait(1).to({y:26.3,alpha:0.9419},0).wait(1).to({y:25.85,alpha:0.9101},0).wait(1).to({y:25.35,alpha:0.8676},0).wait(1).to({y:24.65,alpha:0.8113},0).wait(1).to({y:23.75,alpha:0.7365},0).wait(1).to({y:22.6,alpha:0.6361},0).wait(1).to({y:21,alpha:0.4978},0).wait(1).to({y:18.85,alpha:0.2998},0).wait(1).to({y:15.6,alpha:0},0).to({_off:true},1).wait(188));

	// t1_save
	this.instance_13 = new lib.txt_save_horizontal("synched",0);
	this.instance_13.setTransform(162.65,24.6,0.5503,0.5503,0,0,0,-17.8,4.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({_off:true},142).wait(307));

	// background
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ECF8FD").s().p("A4/D6IAAnzMAx/AAAIAAHzg");
	this.shape_1.setTransform(160,25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(449));

	// stageBackground
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("A6jldMA1HAAAIAAK7Mg1HAAAg");
	this.shape_2.setTransform(160,25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("A6jFeIAAq7MA1HAAAIAAK7g");
	this.shape_3.setTransform(160,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).wait(449));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(59.4,-5.4,360,118.5);
// library properties:
lib.properties = {
	id: '8CC78090B0811A48AF33A41637441988',
	width: 320,
	height: 50,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/fsm_digital_320x50_v2_atlas_1.png", id:"fsm_digital_320x50_v2_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['8CC78090B0811A48AF33A41637441988'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;