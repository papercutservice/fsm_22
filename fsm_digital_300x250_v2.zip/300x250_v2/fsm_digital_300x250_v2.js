(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"fsm_digital_300x250_v2_atlas_1", frames: [[1108,688,93,35],[867,608,184,36],[1666,157,208,47],[1108,730,492,91],[0,649,504,165],[1204,299,522,194],[1728,372,122,69],[506,649,600,118],[1666,222,205,65],[1204,495,423,233],[1204,0,460,297],[1852,405,107,72],[987,502,119,102],[1873,222,110,99],[867,502,118,104],[1985,222,56,56],[1704,517,56,56],[1961,405,73,75],[1629,495,73,75],[1912,0,125,109],[1912,111,125,109],[1666,0,121,155],[1789,0,121,155],[1000,769,102,80],[1938,323,102,80],[1108,502,93,91],[1108,595,93,91],[1914,482,93,35],[1728,479,184,36],[1728,323,208,47],[506,769,492,91],[0,0,600,500],[602,0,600,500],[0,502,865,145]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_241 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_240 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_239 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_238 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_237 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_236 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_235 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_234 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_233 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_232 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_231 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_230 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_229 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_228 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_227 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_226 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_225 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_224 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_223 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_222 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_221 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_220 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_219 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_218 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_217 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_216 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_215 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_214 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_213 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_212 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_211 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_210 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_209 = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.Image = function() {
	this.initialize(ss["fsm_digital_300x250_v2_atlas_1"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_241();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(0,0,46.5,17.5), null);


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_240();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(0,0,92,18), null);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_239();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(0,0,104,23.5), null);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_238();
	this.instance.setTransform(-0.75,-0.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-0.7,-0.7,246,45.5), null);


(lib.txt2_v2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2
	this.instance = new lib.CachedBmp_237();
	this.instance.setTransform(-118.55,-42.05,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_236();
	this.instance_1.setTransform(-130.4,-48.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130.4,-48.4,263.9,97);


(lib.txt2_logos_v3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2_logos
	this.instance = new lib.CachedBmp_235();
	this.instance.setTransform(39.25,-17.3,0.5,0.5);

	this.instance_1 = new lib.Image();
	this.instance_1.setTransform(-112.85,-11.75,0.1571,0.1571);

	this.instance_2 = new lib.CachedBmp_234();
	this.instance_2.setTransform(-150,-29.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-29.3,300,59);


(lib.txt2_button = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_233();
	this.instance.setTransform(-51.2,-16.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51.2,-16.2,102.5,32.5);


(lib.txt_save = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt_save
	this.instance = new lib.CachedBmp_232();
	this.instance.setTransform(-105.8,-58.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-105.8,-58.1,211.5,116.5);


(lib.title = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.CachedBmp_231();
	this.instance.setTransform(-114.95,-74.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114.9,-74.3,230,148.5);


(lib.sh_y = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_yellow
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FCB11D").s().p("ADpFcQg3gIg/gVQgmgNhIgeIkmh4QghgNgQgJQgagPgOgVQgRgYgCgiQgCglARgnQAKgZAhgxIAXghQANgUAGgPQADgJAAgKIgBgRQgBgWAPgbQAXgnAhgWQAZgQAegFQATgEAhAAQCGACBGAVQBnAgAkBWQAGAOAWBQQAQA6AWAZQAIAJAyAfQAkAYAJAfQAJAigOA5QgJAlgaBFQgLAhgNAQQgdAogwAAQgJAAgLgCg");
	this.shape.setTransform(0.001,0.0049);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39.8,-34.9,79.6,69.9);


(lib.sh_red = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_red
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EA6241").s().p("ABAHsQgJgEgQgLQhOg1hbgYQgvgNgtgEQgYgDgYAAIg0ACQggACgUgEQgxgJgggwQgPgWgJghQgUhOAghMQAlhYBnhFQAWgPAugaQAFgDAGgGQAFgEAcgOQAwgYAagUQAXgRAKgPQAHgLAIgOQAOgdgFgVQgDgNgPgTQgRgWgEgJQgJgUAFgXQAFgXARgTQAXgZAvgUQAzgWA+gJQAOgCAmgBQAgAAATgEQAWgEAcADQAQACAeAHQAxAMAoATQBQAlAdA8IAGAOQAPAogQAgQgGAMgMAPIgVAYQgrAzgQBoQgVCHgMAeQgKAagUAjIgiA7QgwBfgaAuQgtBQgzApQgOAMgLACIgHAAQgJAAgKgEg");
	this.shape.setTransform(-0.0056,0.0332);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.8,-49.6,97.6,99.30000000000001);


(lib.sh_ltb = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_light_blue
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#568DCA").s().p("ABvIDQgegBg4gLIglgIQgVgFgQgIQgbgPgjgnQglgngFgeQgEgZAPgkQAMgeBDhhQA0hMAGg4QAFgpgQgqQgQgpgfgfQgjgigxgQQgXgIgZgDQgNgBgVgFIgjgIIgbgEQglgGgUgFQgggHgXgMQgigQgVgeQgXggADgiQACgXAPgXQANgUAWgPQAdgVA+gRQCNgoCPgMQBHgGBJAAQAiAAASAIQALAFASAEIAeAHQBAASA2AeQAWAMAJANQAMAQACAnIASFNQABAYAKAOQAFAHAGANIAJAWQAFAJALAOQANAQAEAHQAdAuACAxQABAugVAsQgNAbgUAXQgJALgNALQgDAEgHADIgKAHQgNAHgQAPIgcAYIg5AsQgtAigfAMQgfALgmAAIgPAAg");
	this.shape.setTransform(0.0376,-0.0073);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.9,-51.5,95.9,103);


(lib.sh_g = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_green
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AkvEuQgqgUgMgrQgHgdAEgqQAIgxACgYQACgXgBggIAAg3IAAgQQAFhrAxhKQAcgpAogaQAqgcAvgFQAigDA4AJQBDAMAWABIAnABQAUACARAIQAxAVAhAUQCbBYAIBrIAAALQABB2i4BjQidBUjwAtQgPADgNAAQgeAAgbgMg");
	this.shape.setTransform(0,0.0284);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.2,-31.3,72.5,62.7);


(lib.sh_db = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_dark_blue
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#224EA2").s().p("AEpGZQhfgXg6hGIgigvQgUgcgRgPQglggg/gMQgjgHhPgCQhVgDg/gKQhQgNg+gcQhHgfgzg1Qg3g3gThEQgIgfgDgqIgCgiQgBgVAEgNQACgHAIgJIAMgOQAWgbANgMQAkgjAxgaQBagxBwgHQBZgGBqAWQBOAQBwAlQCTAwBfAyQB+BCBPBYQBUBdAPBiQANBaguBVQgvBWhTAkQg0AXg4AAQgiAAgkgIg");
	this.shape.setTransform(0.0169,0.0194);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64,-41.7,128.1,83.5);


(lib.ill_money_r = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ill_money_r
	this.instance = new lib.CachedBmp_230();
	this.instance.setTransform(-26.75,-17.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.7,-17.8,53.5,36);


(lib.ill_money_g2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ill_money_g2
	this.instance = new lib.CachedBmp_229();
	this.instance.setTransform(-29.5,-25.35,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.5,-25.3,59.5,51);


(lib.ill_money_g1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ill_money_g1
	this.instance = new lib.CachedBmp_228();
	this.instance.setTransform(-27.55,-24.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.5,-24.5,55,49.5);


(lib.ill_money_b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ill_money_b
	this.instance = new lib.CachedBmp_227();
	this.instance.setTransform(-29.5,-25.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.5,-25.7,59,52);


(lib.il_rz = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_ritz
	this.instance = new lib.CachedBmp_225();
	this.instance.setTransform(-13.9,-14.05,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_226();
	this.instance_1.setTransform(-13.9,-14.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.9,-14,28,28);


(lib.il_or = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_orange
	this.instance = new lib.CachedBmp_223();
	this.instance.setTransform(-18.25,-18.75,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_224();
	this.instance_1.setTransform(-18.25,-18.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-18.2,-18.7,36.5,37.5);


(lib.il_mlk = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_milk
	this.instance = new lib.CachedBmp_221();
	this.instance.setTransform(-31.35,-27.2,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_222();
	this.instance_1.setTransform(-31.35,-27.2,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.3,-27.2,62.5,54.5);


(lib.il_car = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_carrot
	this.instance = new lib.CachedBmp_219();
	this.instance.setTransform(-30.15,-38.75,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_220();
	this.instance_1.setTransform(-30.15,-38.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.1,-38.7,60.5,77.5);


(lib.il_ban = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_banana
	this.instance = new lib.CachedBmp_217();
	this.instance.setTransform(-25.45,-19.9,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_218();
	this.instance_1.setTransform(-25.45,-19.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25.4,-19.9,51,40);


(lib.il_apsl = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_apple_slice
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#224EA2").s().p("AAHCdQgugbgWgiQgYghAEgtQAEgvATgoQATgoAigZQAlgcApAGQAHABAAAHQADAEgCAFIgWA1QgLAZgNANIgSAPIgKAHQgGAFgBAEQgBAEAGAGIAKAIQAJAIAOAJQAHAEgDAIQgUAxgKA7IADABQAIAFgEAJQgCAFgFAAIgFgBgAgPhlQgeAhgMAzQgPA8AVAkQAQAaAhAXQAHgyATgwQgcgRgLgRQgHgLAIgMQAFgHAMgKIAMgJQAHgGAEgFQAIgJAIgPQAJgRAPgjQgwABghAmg");
	this.shape.setTransform(1.5573,-0.8179);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLCTQgKAAgKgJQgmgggDhKQgChQAjgwQAVgcAfgOQATgIASgBIAHABQALABADAFQACADAAAGQAAB+gxB2QgOAjgTAAIgCgBg");
	this.shape_1.setTransform(-2.4804,1.9053);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.7,-16.6,19.5,33.3);


(lib.il_ap = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_apple
	this.instance = new lib.CachedBmp_215();
	this.instance.setTransform(-23.15,-22.8,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_216();
	this.instance_1.setTransform(-23.15,-22.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-23.1,-22.8,46.5,45.5);


(lib.Path_19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAiAtQgFgDgQgQIglglQgRgQgDgGQgBgEADgFQADgEAEACQAGADAGAGIALALIAlAlQAQAQADAGQADAFgEAEQgDACgCAAIgEgBg");
	this.shape.setTransform(4.535,4.5835);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_19, new cjs.Rectangle(0,0,9.1,9.2), null);


(lib.Path_18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAsA3IhKhIQgSgRgHgJQgEgFAEgGQAEgGAGAEQAMAJAOAPIAXAZIAzAyQAGAGgGAGQgDADgDAAQgCAAgDgDg");
	this.shape.setTransform(5.7875,5.858);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_18, new cjs.Rectangle(0,0,11.6,11.7), null);


(lib.Path_16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAdArQgNgRgTgWQgbgVgKgOQgDgEADgGQADgGAFADQAOAIAZAdQARARAQAVQAEAGgFAGQgCADgDAAQgCAAgDgDg");
	this.shape.setTransform(4.2013,4.544);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_16, new cjs.Rectangle(0,0,8.4,9.2), null);


(lib.Path_15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAYAwQgNgXgSgZQgVgXgJgOQgDgFAEgFQADgGAGAEQANALAVAgQAQAUAOAaQAEAHgHAEIgEABQgDAAgDgEg");
	this.shape.setTransform(3.9035,5.1398);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_15, new cjs.Rectangle(0,0,7.8,10.3), null);


(lib.Path_14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAoA8QgYgegUgYIgXgbQgOgQgJgMQgDgEAEgGQAEgGAFAEQAXAWAYAgQAOAQAeAoQAEAGgFAGQgDADgCAAQgDAAgCgEg");
	this.shape.setTransform(5.2446,6.3226);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_14, new cjs.Rectangle(0,0,10.5,12.7), null);


(lib.Path_13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAgAuQgQgQgUgYIgkgoQgFgFAFgFQAFgGAFAGIAkAnQAWAVAOASQADAEgEAGQgCAEgDAAQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAgBgBAAg");
	this.shape.setTransform(4.3251,4.7589);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_13, new cjs.Rectangle(0,0,8.7,9.6), null);


(lib.Path_12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAhA9QgPgXhAhYQgEgGAFgFQAFgGAFAGQAmAqAsBIQAEAHgHAEIgEABQgEAAgDgEg");
	this.shape.setTransform(4.8588,6.4988);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_12, new cjs.Rectangle(0,0,9.7,13), null);


(lib.Path_11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAoA7QgPgWgbgiIgYgZIgYgbQgEgEAEgFQAFgGAEAEQAWATAcAiQAWAZAUAfQAEAGgFAFQgBABAAAAQgBABgBAAQAAAAgBAAQAAAAgBAAQgCAAgDgDg");
	this.shape.setTransform(5.2842,6.2294);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_11, new cjs.Rectangle(0,0,10.6,12.5), null);


(lib.Path_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAvBHIhOhjIgPgRQgIgKgDgIQgCgDADgEQADgEAEACQAIAFAJALIAPASIAZAhQAaAgATAeIAAAAQAGACgBAIQAAAFgFABIgBAAIgBAAQgBAAgDgCg");
	this.shape.setTransform(5.8535,7.3202);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9, new cjs.Rectangle(0,0,11.7,14.7), null);


(lib.Path_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAoBGQgbgog/hYQgEgGAFgFQAFgGAFAGQAwA/AqBBQAEAGgFAFQgDADgCAAQgDAAgCgDg");
	this.shape.setTransform(5.2453,7.275);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_8, new cjs.Rectangle(0,0,10.5,14.6), null);


(lib.Path_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAVAmQgXgigdgeQgEgEAFgGQAEgGAFAEQAdAfAYAhQAEAGgFAGQgDADgCAAQgDAAgCgDg");
	this.shape.setTransform(3.3198,4.0476);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6, new cjs.Rectangle(0,0,6.7,8.2), null);


(lib.Path_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAwBLQglg5hEhSQgFgGAFgEQAFgFAFAFQA0A2A2BUQAEAGgGAFQgCADgCAAQgDAAgCgDg");
	this.shape.setTransform(6.0276,7.7815);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5, new cjs.Rectangle(0,0,12.1,15.6), null);


(lib.Path_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AArBAQgegfgVgbIgYgdQgSgWgEgJQgDgFAFgEQAFgEAFAEIAXAfIAXAdQAYAcAaAcQAEAGgFAFQgCACgDAAQgDAAgCgCg");
	this.shape.setTransform(5.6036,6.5934);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0,0,11.2,13.2), null);


(lib.Path_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAiA2QgUghgQgUIgWgXQgPgOgHgJQgDgEADgFQADgFAEACQAUAMAeAlQAUAYAQAeQAEAHgHAEIgEACQgEAAgCgFg");
	this.shape.setTransform(4.8727,5.8953);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(0,0,9.8,11.8), null);


(lib.il_li = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_lines
	this.instance = new lib.Path_1();
	this.instance.setTransform(-27.4,29.3,1,1,0,0,0,4.9,5.9);
	this.instance.compositeOperation = "multiply";

	this.instance_1 = new lib.Path_3();
	this.instance_1.setTransform(-15.45,25.75,1,1,0,0,0,5.6,6.5);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_5();
	this.instance_2.setTransform(-20.2,4.9,1,1,0,0,0,6,7.8);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_6();
	this.instance_3.setTransform(-2.4,25.4,1,1,0,0,0,3.3,4);
	this.instance_3.compositeOperation = "multiply";

	this.instance_4 = new lib.Path_8();
	this.instance_4.setTransform(-14.25,-2.65,1,1,0,0,0,5.2,7.2);
	this.instance_4.compositeOperation = "multiply";

	this.instance_5 = new lib.Path_9();
	this.instance_5.setTransform(3.8,14.5,1,1,0,0,0,5.9,7.3);
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.Path_11();
	this.instance_6.setTransform(-19.05,-24.45,1,1,0,0,0,5.2,6.2);
	this.instance_6.compositeOperation = "multiply";

	this.instance_7 = new lib.Path_12();
	this.instance_7.setTransform(-5.6,-11,1,1,0,0,0,4.9,6.5);
	this.instance_7.compositeOperation = "multiply";

	this.instance_8 = new lib.Path_13();
	this.instance_8.setTransform(9,2.5,1,1,0,0,0,4.3,4.8);
	this.instance_8.compositeOperation = "multiply";

	this.instance_9 = new lib.Path_14();
	this.instance_9.setTransform(-9.35,-28.7,1,1,0,0,0,5.2,6.4);
	this.instance_9.compositeOperation = "multiply";

	this.instance_10 = new lib.Path_15();
	this.instance_10.setTransform(3,-16.65,1,1,0,0,0,3.9,5.1);
	this.instance_10.compositeOperation = "multiply";

	this.instance_11 = new lib.Path_16();
	this.instance_11.setTransform(18.7,-3.45,1,1,0,0,0,4.2,4.5);
	this.instance_11.compositeOperation = "multiply";

	this.instance_12 = new lib.Path_18();
	this.instance_12.setTransform(14.6,-21.15,1,1,0,0,0,5.8,5.9);
	this.instance_12.compositeOperation = "multiply";

	this.instance_13 = new lib.Path_19();
	this.instance_13.setTransform(27.8,-8.45,1,1,0,0,0,4.5,4.6);
	this.instance_13.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},448).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.3,-35.1,64.69999999999999,70.30000000000001);


// stage content:
(lib.fsm_digital_300x250_v2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [448];
	// timeline functions:
	this.frame_448 = function() {
		var _this = this;
		/*
		Stop a Movie Clip/Video
		Stops the specified movie clip or video.
		*/
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(448).call(this.frame_448).wait(1));

	// border
	this.instance = new lib.CachedBmp_209();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_210();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},448).wait(1));

	// il_m_b
	this.instance_2 = new lib.ill_money_b("synched",0);
	this.instance_2.setTransform(245.55,-36.45,1,1,0,0,0,-0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:237.55,y:32.05},31,cjs.Ease.cubicInOut).to({regY:0.2,rotation:-14.9992,y:25.2},82,cjs.Ease.cubicInOut).to({regY:0.1,rotation:0,y:-26},21,cjs.Ease.quartInOut).to({_off:true},1).wait(314));

	// il_m_g1
	this.instance_3 = new lib.ill_money_g1("synched",0);
	this.instance_3.setTransform(-40.5,138.95,1,1,0,0,0,0,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:20.3,y:146},31,cjs.Ease.cubicInOut).to({rotation:14.9992,x:20.25,y:139.65},82,cjs.Ease.cubicInOut).to({rotation:0,x:-48.85,y:146},21,cjs.Ease.quartInOut).to({_off:true},1).wait(314));

	// il_m_g2
	this.instance_4 = new lib.ill_money_g2("synched",0);
	this.instance_4.setTransform(339.65,151.35,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({x:261.55},31,cjs.Ease.cubicInOut).to({y:147.5},82,cjs.Ease.cubicInOut).to({x:346.7,y:151.35},21,cjs.Ease.quartInOut).to({_off:true},1).wait(314));

	// il_m_r
	this.instance_5 = new lib.ill_money_r("synched",0);
	this.instance_5.setTransform(153.55,285.55,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:141.35,y:224},31,cjs.Ease.cubicInOut).to({rotation:14.9992,x:153.55},82,cjs.Ease.cubicInOut).to({rotation:0,x:141.35,y:275.85},21,cjs.Ease.quartInOut).to({_off:true},1).wait(314));

	// il_ap_sl
	this.instance_6 = new lib.il_apsl("synched",0);
	this.instance_6.setTransform(276.05,-19.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({x:290.25,startPosition:31},31,cjs.Ease.quartInOut).wait(1).to({rotation:0.0083,x:290.2586,y:-19.0558,startPosition:32},0).wait(1).to({rotation:0.0188,x:290.2697,y:-19.0633,startPosition:33},0).wait(1).to({rotation:0.0318,x:290.2833,y:-19.0724,startPosition:34},0).wait(1).to({rotation:0.0472,x:290.2994,y:-19.0832,startPosition:35},0).wait(1).to({rotation:0.065,x:290.3181,y:-19.0958,startPosition:36},0).wait(1).to({rotation:0.0854,x:290.3394,y:-19.1101,startPosition:37},0).wait(1).to({rotation:0.1083,x:290.3633,y:-19.1262,startPosition:38},0).wait(1).to({rotation:0.1337,x:290.39,y:-19.1441,startPosition:39},0).wait(1).to({rotation:0.1618,x:290.4194,y:-19.1639,startPosition:40},0).wait(1).to({rotation:0.1926,x:290.4516,y:-19.1855,startPosition:41},0).wait(1).to({rotation:0.2261,x:290.4867,y:-19.2091,startPosition:42},0).wait(1).to({rotation:0.2623,x:290.5246,y:-19.2346,startPosition:43},0).wait(1).to({rotation:0.3014,x:290.5655,y:-19.262,startPosition:44},0).wait(1).to({rotation:0.3433,x:290.6094,y:-19.2915,startPosition:45},0).wait(1).to({rotation:0.3881,x:290.6563,y:-19.3231,startPosition:46},0).wait(1).to({rotation:0.4359,x:290.7063,y:-19.3566,startPosition:47},0).wait(1).to({rotation:0.4866,x:290.7594,y:-19.3923,startPosition:48},0).wait(1).to({rotation:0.5404,x:290.8157,y:-19.4302,startPosition:49},0).wait(1).to({rotation:0.5972,x:290.8752,y:-19.4702,startPosition:50},0).wait(1).to({rotation:0.6572,x:290.938,y:-19.5124,startPosition:51},0).wait(1).to({rotation:0.7204,x:291.0041,y:-19.5568,startPosition:52},0).wait(1).to({rotation:0.7867,x:291.0736,y:-19.6035,startPosition:53},0).wait(1).to({rotation:0.8564,x:291.1465,y:-19.6525,startPosition:54},0).wait(1).to({rotation:0.9293,x:291.2228,y:-19.7038,startPosition:55},0).wait(1).to({rotation:1.0056,x:291.3027,y:-19.7574,startPosition:56},0).wait(1).to({rotation:1.0852,x:291.3861,y:-19.8135,startPosition:57},0).wait(1).to({rotation:1.1683,x:291.473,y:-19.8719,startPosition:58},0).wait(1).to({rotation:1.2548,x:291.5636,y:-19.9328,startPosition:59},0).wait(1).to({rotation:1.3449,x:291.6579,y:-19.9961,startPosition:60},0).wait(1).to({rotation:1.4384,x:291.7558,y:-20.0619,startPosition:61},0).wait(1).to({rotation:1.5355,x:291.8575,y:-20.1303,startPosition:62},0).wait(1).to({rotation:1.6362,x:291.9629,y:-20.2011,startPosition:63},0).wait(1).to({rotation:1.7405,x:292.0721,y:-20.2745,startPosition:64},0).wait(1).to({rotation:1.8485,x:292.1851,y:-20.3504,startPosition:65},0).wait(1).to({rotation:1.9601,x:292.3019,y:-20.429,startPosition:66},0).wait(1).to({rotation:2.0753,x:292.4226,y:-20.51,startPosition:67},0).wait(1).to({rotation:2.1943,x:292.5471,y:-20.5937,startPosition:68},0).wait(1).to({rotation:2.3169,x:292.6754,y:-20.68,startPosition:69},0).wait(1).to({rotation:2.4431,x:292.8076,y:-20.7688,startPosition:70},0).wait(1).to({rotation:2.5731,x:292.9437,y:-20.8602,startPosition:71},0).wait(1).to({rotation:2.7067,x:293.0835,y:-20.9542,startPosition:72},0).wait(1).to({rotation:2.8439,x:293.2272,y:-21.0507,startPosition:73},0).wait(1).to({rotation:2.9847,x:293.3746,y:-21.1498,startPosition:74},0).wait(1).to({rotation:3.1291,x:293.5257,y:-21.2514,startPosition:75},0).wait(1).to({rotation:3.277,x:293.6806,y:-21.3554,startPosition:76},0).wait(1).to({rotation:3.4284,x:293.839,y:-21.4619,startPosition:77},0).wait(1).to({rotation:3.5832,x:294.0011,y:-21.5708,startPosition:78},0).wait(1).to({rotation:3.7413,x:294.1666,y:-21.6821,startPosition:79},0).wait(1).to({rotation:3.9027,x:294.3355,y:-21.7956,startPosition:80},0).wait(1).to({rotation:4.0672,x:294.5078,y:-21.9114,startPosition:81},0).wait(1).to({rotation:4.2348,x:294.6833,y:-22.0293,startPosition:82},0).wait(1).to({rotation:4.4054,x:294.8618,y:-22.1493,startPosition:83},0).wait(1).to({rotation:4.5788,x:295.0434,y:-22.2713,startPosition:84},0).wait(1).to({rotation:4.7549,x:295.2277,y:-22.3952,startPosition:85},0).wait(1).to({rotation:4.9336,x:295.4148,y:-22.5209,startPosition:86},0).wait(1).to({rotation:5.1147,x:295.6044,y:-22.6483,startPosition:87},0).wait(1).to({rotation:5.298,x:295.7963,y:-22.7773,startPosition:88},0).wait(1).to({rotation:5.4835,x:295.9904,y:-22.9077,startPosition:89},0).wait(1).to({rotation:5.6708,x:296.1866,y:-23.0396,startPosition:90},0).wait(1).to({rotation:5.8599,x:296.3845,y:-23.1726,startPosition:91},0).wait(1).to({rotation:6.0506,x:296.5841,y:-23.3067,startPosition:92},0).wait(1).to({rotation:6.2425,x:296.785,y:-23.4417,startPosition:93},0).wait(1).to({rotation:6.4356,x:296.9871,y:-23.5776,startPosition:94},0).wait(1).to({rotation:6.6296,x:297.1902,y:-23.7141,startPosition:95},0).wait(1).to({rotation:6.8243,x:297.3941,y:-23.851,startPosition:96},0).wait(1).to({rotation:7.0195,x:297.5984,y:-23.9884,startPosition:97},0).wait(1).to({rotation:7.215,x:297.8031,y:-24.1259,startPosition:98},0).wait(1).to({rotation:7.4106,x:298.0078,y:-24.2635,startPosition:99},0).wait(1).to({rotation:7.6059,x:298.2123,y:-24.4009,startPosition:100},0).wait(1).to({rotation:7.801,x:298.4165,y:-24.5381,startPosition:101},0).wait(1).to({rotation:7.9954,x:298.62,y:-24.6749,startPosition:102},0).wait(1).to({rotation:8.189,x:298.8227,y:-24.8111,startPosition:103},0).wait(1).to({rotation:8.3816,x:299.0244,y:-24.9467,startPosition:104},0).wait(1).to({rotation:8.5731,x:299.2248,y:-25.0813,startPosition:105},0).wait(1).to({rotation:8.7631,x:299.4237,y:-25.215,startPosition:106},0).wait(1).to({rotation:8.9516,x:299.621,y:-25.3476,startPosition:107},0).wait(1).to({rotation:9.1383,x:299.8165,y:-25.479,startPosition:108},0).wait(1).to({rotation:9.3231,x:300.0099,y:-25.609,startPosition:109},0).wait(1).to({rotation:9.5058,x:300.2012,y:-25.7375,startPosition:110},0).wait(1).to({rotation:9.6863,x:300.3901,y:-25.8645,startPosition:111},0).wait(1).to({rotation:9.8644,x:300.5766,y:-25.9898,startPosition:112},0).wait(1).to({rotation:10.04,x:300.7604,y:-26.1133,startPosition:113},0).wait(1).to({rotation:10.2129,x:300.9415,y:-26.235,startPosition:114},0).wait(1).to({rotation:10.3832,x:301.1197,y:-26.3548,startPosition:115},0).wait(1).to({rotation:10.5506,x:301.295,y:-26.4725,startPosition:116},0).wait(1).to({rotation:10.715,x:301.4671,y:-26.5882,startPosition:117},0).wait(1).to({rotation:10.8765,x:301.6361,y:-26.7018,startPosition:118},0).wait(1).to({rotation:11.0349,x:301.8019,y:-26.8132,startPosition:119},0).wait(1).to({rotation:11.1901,x:301.9644,y:-26.9224,startPosition:120},0).wait(1).to({rotation:11.3421,x:302.1235,y:-27.0294,startPosition:121},0).wait(1).to({rotation:11.4908,x:302.2793,y:-27.134,startPosition:122},0).wait(1).to({rotation:11.6363,x:302.4315,y:-27.2364,startPosition:123},0).wait(1).to({rotation:11.7784,x:302.5803,y:-27.3363,startPosition:124},0).wait(1).to({rotation:11.9172,x:302.7256,y:-27.434,startPosition:125},0).wait(1).to({rotation:12.0525,x:302.8673,y:-27.5292,startPosition:126},0).wait(1).to({rotation:12.1845,x:303.0055,y:-27.6221,startPosition:127},0).wait(1).to({rotation:12.3131,x:303.1401,y:-27.7125,startPosition:128},0).wait(1).to({rotation:12.4383,x:303.2711,y:-27.8006,startPosition:129},0).wait(1).to({rotation:12.5601,x:303.3986,y:-27.8863,startPosition:130},0).wait(1).to({rotation:12.6785,x:303.5226,y:-27.9696,startPosition:131},0).wait(1).to({rotation:12.7935,x:303.643,y:-28.0505,startPosition:132},0).wait(1).to({rotation:12.9051,x:303.7598,y:-28.129,startPosition:133},0).wait(1).to({rotation:13.0134,x:303.8732,y:-28.2052,startPosition:134},0).wait(1).to({rotation:13.1184,x:303.9831,y:-28.2791,startPosition:135},0).wait(1).to({rotation:13.2201,x:304.0895,y:-28.3506,startPosition:136},0).wait(1).to({rotation:13.3184,x:304.1925,y:-28.4198,startPosition:137},0).wait(1).to({rotation:13.4136,x:304.2921,y:-28.4867,startPosition:138},0).wait(1).to({rotation:13.5055,x:304.4,y:-28.6,startPosition:139},0).to({rotation:14.9992,x:271.7,y:6.1,startPosition:170},31,cjs.Ease.cubicInOut).to({x:258.7,y:5.2,startPosition:211},41,cjs.Ease.quartInOut).to({y:10,startPosition:324},113,cjs.Ease.quadInOut).to({y:5.2,startPosition:418},94,cjs.Ease.quadInOut).to({x:208.55,y:0.4,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// il_ap
	this.instance_7 = new lib.il_ap("synched",0);
	this.instance_7.setTransform(235.05,-30.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({x:245.45,y:-38.8,startPosition:31},31,cjs.Ease.quartInOut).wait(1).to({rotation:-0.0083,x:245.4442,y:-38.8076,startPosition:32},0).wait(1).to({rotation:-0.0188,x:245.4368,y:-38.8172,startPosition:33},0).wait(1).to({rotation:-0.0318,x:245.4277,y:-38.8291,startPosition:34},0).wait(1).to({rotation:-0.0472,x:245.417,y:-38.8432,startPosition:35},0).wait(1).to({rotation:-0.065,x:245.4045,y:-38.8595,startPosition:36},0).wait(1).to({rotation:-0.0854,x:245.3903,y:-38.8781,startPosition:37},0).wait(1).to({rotation:-0.1083,x:245.3742,y:-38.8991,startPosition:38},0).wait(1).to({rotation:-0.1337,x:245.3564,y:-38.9224,startPosition:39},0).wait(1).to({rotation:-0.1618,x:245.3367,y:-38.9481,startPosition:40},0).wait(1).to({rotation:-0.1926,x:245.3152,y:-38.9763,startPosition:41},0).wait(1).to({rotation:-0.2261,x:245.2918,y:-39.0069,startPosition:42},0).wait(1).to({rotation:-0.2623,x:245.2664,y:-39.0401,startPosition:43},0).wait(1).to({rotation:-0.3014,x:245.2391,y:-39.0759,startPosition:44},0).wait(1).to({rotation:-0.3433,x:245.2097,y:-39.1142,startPosition:45},0).wait(1).to({rotation:-0.3881,x:245.1784,y:-39.1553,startPosition:46},0).wait(1).to({rotation:-0.4359,x:245.145,y:-39.199,startPosition:47},0).wait(1).to({rotation:-0.4866,x:245.1095,y:-39.2454,startPosition:48},0).wait(1).to({rotation:-0.5404,x:245.0718,y:-39.2946,startPosition:49},0).wait(1).to({rotation:-0.5972,x:245.032,y:-39.3467,startPosition:50},0).wait(1).to({rotation:-0.6572,x:244.9901,y:-39.4016,startPosition:51},0).wait(1).to({rotation:-0.7204,x:244.9459,y:-39.4594,startPosition:52},0).wait(1).to({rotation:-0.7867,x:244.8994,y:-39.5201,startPosition:53},0).wait(1).to({rotation:-0.8564,x:244.8507,y:-39.5838,startPosition:54},0).wait(1).to({rotation:-0.9293,x:244.7997,y:-39.6506,startPosition:55},0).wait(1).to({rotation:-1.0056,x:244.7463,y:-39.7204,startPosition:56},0).wait(1).to({rotation:-1.0852,x:244.6905,y:-39.7933,startPosition:57},0).wait(1).to({rotation:-1.1683,x:244.6324,y:-39.8693,startPosition:58},0).wait(1).to({rotation:-1.2548,x:244.5719,y:-39.9485,startPosition:59},0).wait(1).to({rotation:-1.3449,x:244.5088,y:-40.031,startPosition:60},0).wait(1).to({rotation:-1.4384,x:244.4434,y:-40.1166,startPosition:61},0).wait(1).to({rotation:-1.5355,x:244.3754,y:-40.2055,startPosition:62},0).wait(1).to({rotation:-1.6362,x:244.3049,y:-40.2976,startPosition:63},0).wait(1).to({rotation:-1.7405,x:244.2319,y:-40.3931,startPosition:64},0).wait(1).to({rotation:-1.8485,x:244.1564,y:-40.4919,startPosition:65},0).wait(1).to({rotation:-1.9601,x:244.0783,y:-40.5941,startPosition:66},0).wait(1).to({rotation:-2.0753,x:243.9976,y:-40.6996,startPosition:67},0).wait(1).to({rotation:-2.1943,x:243.9144,y:-40.8084,startPosition:68},0).wait(1).to({rotation:-2.3169,x:243.8286,y:-40.9206,startPosition:69},0).wait(1).to({rotation:-2.4431,x:243.7402,y:-41.0362,startPosition:70},0).wait(1).to({rotation:-2.5731,x:243.6493,y:-41.1552,startPosition:71},0).wait(1).to({rotation:-2.7067,x:243.5558,y:-41.2774,startPosition:72},0).wait(1).to({rotation:-2.8439,x:243.4598,y:-41.403,startPosition:73},0).wait(1).to({rotation:-2.9847,x:243.3612,y:-41.5319,startPosition:74},0).wait(1).to({rotation:-3.1291,x:243.2602,y:-41.6641,startPosition:75},0).wait(1).to({rotation:-3.277,x:243.1567,y:-41.7995,startPosition:76},0).wait(1).to({rotation:-3.4284,x:243.0507,y:-41.938,startPosition:77},0).wait(1).to({rotation:-3.5832,x:242.9424,y:-42.0797,startPosition:78},0).wait(1).to({rotation:-3.7413,x:242.8318,y:-42.2244,startPosition:79},0).wait(1).to({rotation:-3.9027,x:242.7188,y:-42.3721,startPosition:80},0).wait(1).to({rotation:-4.0672,x:242.6037,y:-42.5228,startPosition:81},0).wait(1).to({rotation:-4.2348,x:242.4864,y:-42.6762,startPosition:82},0).wait(1).to({rotation:-4.4054,x:242.367,y:-42.8323,startPosition:83},0).wait(1).to({rotation:-4.5788,x:242.2457,y:-42.991,startPosition:84},0).wait(1).to({rotation:-4.7549,x:242.1224,y:-43.1522,startPosition:85},0).wait(1).to({rotation:-4.9336,x:241.9974,y:-43.3158,startPosition:86},0).wait(1).to({rotation:-5.1147,x:241.8706,y:-43.4815,startPosition:87},0).wait(1).to({rotation:-5.298,x:241.7423,y:-43.6493,startPosition:88},0).wait(1).to({rotation:-5.4835,x:241.6126,y:-43.8191,startPosition:89},0).wait(1).to({rotation:-5.6708,x:241.4814,y:-43.9906,startPosition:90},0).wait(1).to({rotation:-5.8599,x:241.3491,y:-44.1636,startPosition:91},0).wait(1).to({rotation:-6.0506,x:241.2157,y:-44.3381,startPosition:92},0).wait(1).to({rotation:-6.2425,x:241.0814,y:-44.5138,startPosition:93},0).wait(1).to({rotation:-6.4356,x:240.9463,y:-44.6905,startPosition:94},0).wait(1).to({rotation:-6.6296,x:240.8105,y:-44.8681,startPosition:95},0).wait(1).to({rotation:-6.8243,x:240.6742,y:-45.0463,startPosition:96},0).wait(1).to({rotation:-7.0195,x:240.5376,y:-45.225,startPosition:97},0).wait(1).to({rotation:-7.215,x:240.4008,y:-45.404,startPosition:98},0).wait(1).to({rotation:-7.4106,x:240.264,y:-45.5829,startPosition:99},0).wait(1).to({rotation:-7.6059,x:240.1272,y:-45.7618,startPosition:100},0).wait(1).to({rotation:-7.801,x:239.9907,y:-45.9403,startPosition:101},0).wait(1).to({rotation:-7.9954,x:239.8547,y:-46.1182,startPosition:102},0).wait(1).to({rotation:-8.189,x:239.7192,y:-46.2955,startPosition:103},0).wait(1).to({rotation:-8.3816,x:239.5844,y:-46.4718,startPosition:104},0).wait(1).to({rotation:-8.5731,x:239.4504,y:-46.647,startPosition:105},0).wait(1).to({rotation:-8.7631,x:239.3174,y:-46.8209,startPosition:106},0).wait(1).to({rotation:-8.9516,x:239.1855,y:-46.9934,startPosition:107},0).wait(1).to({rotation:-9.1383,x:239.0549,y:-47.1643,startPosition:108},0).wait(1).to({rotation:-9.3231,x:238.9255,y:-47.3335,startPosition:109},0).wait(1).to({rotation:-9.5058,x:238.7977,y:-47.5007,startPosition:110},0).wait(1).to({rotation:-9.6863,x:238.6714,y:-47.6659,startPosition:111},0).wait(1).to({rotation:-9.8644,x:238.5467,y:-47.8289,startPosition:112},0).wait(1).to({rotation:-10.04,x:238.4239,y:-47.9897,startPosition:113},0).wait(1).to({rotation:-10.2129,x:238.3028,y:-48.148,startPosition:114},0).wait(1).to({rotation:-10.3832,x:238.1837,y:-48.3038,startPosition:115},0).wait(1).to({rotation:-10.5506,x:238.0665,y:-48.457,startPosition:116},0).wait(1).to({rotation:-10.715,x:237.9514,y:-48.6076,startPosition:117},0).wait(1).to({rotation:-10.8765,x:237.8384,y:-48.7553,startPosition:118},0).wait(1).to({rotation:-11.0349,x:237.7276,y:-48.9003,startPosition:119},0).wait(1).to({rotation:-11.1901,x:237.619,y:-49.0424,startPosition:120},0).wait(1).to({rotation:-11.3421,x:237.5126,y:-49.1815,startPosition:121},0).wait(1).to({rotation:-11.4908,x:237.4085,y:-49.3176,startPosition:122},0).wait(1).to({rotation:-11.6363,x:237.3067,y:-49.4508,startPosition:123},0).wait(1).to({rotation:-11.7784,x:237.2073,y:-49.5809,startPosition:124},0).wait(1).to({rotation:-11.9172,x:237.1102,y:-49.7079,startPosition:125},0).wait(1).to({rotation:-12.0525,x:237.0154,y:-49.8318,startPosition:126},0).wait(1).to({rotation:-12.1845,x:236.9231,y:-49.9526,startPosition:127},0).wait(1).to({rotation:-12.3131,x:236.8331,y:-50.0703,startPosition:128},0).wait(1).to({rotation:-12.4383,x:236.7455,y:-50.1849,startPosition:129},0).wait(1).to({rotation:-12.5601,x:236.6602,y:-50.2963,startPosition:130},0).wait(1).to({rotation:-12.6785,x:236.5774,y:-50.4047,startPosition:131},0).wait(1).to({rotation:-12.7935,x:236.4969,y:-50.51,startPosition:132},0).wait(1).to({rotation:-12.9051,x:236.4188,y:-50.6122,startPosition:133},0).wait(1).to({rotation:-13.0134,x:236.343,y:-50.7113,startPosition:134},0).wait(1).to({rotation:-13.1184,x:236.2695,y:-50.8074,startPosition:135},0).wait(1).to({rotation:-13.2201,x:236.1984,y:-50.9004,startPosition:136},0).wait(1).to({rotation:-13.3184,x:236.1295,y:-50.9905,startPosition:137},0).wait(1).to({rotation:-13.4136,x:236.0629,y:-51.0775,startPosition:138},0).wait(1).to({rotation:-13.5055,x:235.95,y:-51.15,startPosition:139},0).to({rotation:-14.9992,x:226.05,y:38.3,startPosition:170},31,cjs.Ease.cubicInOut).to({x:216.7,y:38,startPosition:211},41,cjs.Ease.quartInOut).to({rotation:0,x:217.9,y:43.4,startPosition:324},113,cjs.Ease.quadInOut).to({rotation:-14.9992,x:216.7,y:38,startPosition:418},94,cjs.Ease.quadInOut).to({x:181.75,y:47,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// il_or
	this.instance_8 = new lib.il_or("synched",0);
	this.instance_8.setTransform(329,92.75);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({y:96.1,startPosition:31},31,cjs.Ease.quartInOut).wait(1).to({rotation:0.0165,x:329.0061,y:96.0903,startPosition:32},0).wait(1).to({rotation:0.0377,x:329.014,y:96.0778,startPosition:33},0).wait(1).to({rotation:0.0636,x:329.0236,y:96.0625,startPosition:34},0).wait(1).to({rotation:0.0944,x:329.035,y:96.0444,startPosition:35},0).wait(1).to({rotation:0.1301,x:329.0483,y:96.0234,startPosition:36},0).wait(1).to({rotation:0.1708,x:329.0634,y:95.9994,startPosition:37},0).wait(1).to({rotation:0.2166,x:329.0804,y:95.9725,startPosition:38},0).wait(1).to({rotation:0.2675,x:329.0993,y:95.9425,startPosition:39},0).wait(1).to({rotation:0.3237,x:329.1202,y:95.9094,startPosition:40},0).wait(1).to({rotation:0.3853,x:329.143,y:95.8732,startPosition:41},0).wait(1).to({rotation:0.4522,x:329.1679,y:95.8337,startPosition:42},0).wait(1).to({rotation:0.5248,x:329.1948,y:95.791,startPosition:43},0).wait(1).to({rotation:0.6029,x:329.2238,y:95.745,startPosition:44},0).wait(1).to({rotation:0.6867,x:329.2549,y:95.6957,startPosition:45},0).wait(1).to({rotation:0.7763,x:329.2882,y:95.6429,startPosition:46},0).wait(1).to({rotation:0.8719,x:329.3236,y:95.5867,startPosition:47},0).wait(1).to({rotation:0.9733,x:329.3613,y:95.5269,startPosition:48},0).wait(1).to({rotation:1.0809,x:329.4012,y:95.4636,startPosition:49},0).wait(1).to({rotation:1.1946,x:329.4434,y:95.3966,startPosition:50},0).wait(1).to({rotation:1.3146,x:329.488,y:95.326,startPosition:51},0).wait(1).to({rotation:1.4409,x:329.5349,y:95.2516,startPosition:52},0).wait(1).to({rotation:1.5737,x:329.5841,y:95.1734,startPosition:53},0).wait(1).to({rotation:1.7129,x:329.6358,y:95.0915,startPosition:54},0).wait(1).to({rotation:1.8588,x:329.69,y:95.0056,startPosition:55},0).wait(1).to({rotation:2.0114,x:329.7466,y:94.9157,startPosition:56},0).wait(1).to({rotation:2.1707,x:329.8057,y:94.8219,startPosition:57},0).wait(1).to({rotation:2.3369,x:329.8674,y:94.7241,startPosition:58},0).wait(1).to({rotation:2.51,x:329.9317,y:94.6222,startPosition:59},0).wait(1).to({rotation:2.69,x:329.9985,y:94.5162,startPosition:60},0).wait(1).to({rotation:2.8772,x:330.068,y:94.406,startPosition:61},0).wait(1).to({rotation:3.0714,x:330.1401,y:94.2916,startPosition:62},0).wait(1).to({rotation:3.2729,x:330.2148,y:94.173,startPosition:63},0).wait(1).to({rotation:3.4815,x:330.2923,y:94.0502,startPosition:64},0).wait(1).to({rotation:3.6974,x:330.3724,y:93.923,startPosition:65},0).wait(1).to({rotation:3.9206,x:330.4553,y:93.7916,startPosition:66},0).wait(1).to({rotation:4.1512,x:330.5409,y:93.6559,startPosition:67},0).wait(1).to({rotation:4.3891,x:330.6292,y:93.5158,startPosition:68},0).wait(1).to({rotation:4.6343,x:330.7202,y:93.3714,startPosition:69},0).wait(1).to({rotation:4.8869,x:330.8139,y:93.2227,startPosition:70},0).wait(1).to({rotation:5.1468,x:330.9104,y:93.0697,startPosition:71},0).wait(1).to({rotation:5.414,x:331.0096,y:92.9123,startPosition:72},0).wait(1).to({rotation:5.6885,x:331.1115,y:92.7507,startPosition:73},0).wait(1).to({rotation:5.9702,x:331.216,y:92.5849,startPosition:74},0).wait(1).to({rotation:6.259,x:331.3232,y:92.4148,startPosition:75},0).wait(1).to({rotation:6.5548,x:331.4331,y:92.2406,startPosition:76},0).wait(1).to({rotation:6.8576,x:331.5454,y:92.0624,startPosition:77},0).wait(1).to({rotation:7.1672,x:331.6604,y:91.8801,startPosition:78},0).wait(1).to({rotation:7.4835,x:331.7778,y:91.6939,startPosition:79},0).wait(1).to({rotation:7.8063,x:331.8976,y:91.5038,startPosition:80},0).wait(1).to({rotation:8.1354,x:332.0197,y:91.31,startPosition:81},0).wait(1).to({rotation:8.4707,x:332.1442,y:91.1126,startPosition:82},0).wait(1).to({rotation:8.8119,x:332.2708,y:90.9117,startPosition:83},0).wait(1).to({rotation:9.1587,x:332.3996,y:90.7075,startPosition:84},0).wait(1).to({rotation:9.511,x:332.5303,y:90.5001,startPosition:85},0).wait(1).to({rotation:9.8684,x:332.663,y:90.2897,startPosition:86},0).wait(1).to({rotation:10.2306,x:332.7975,y:90.0764,startPosition:87},0).wait(1).to({rotation:10.5974,x:332.9336,y:89.8605,startPosition:88},0).wait(1).to({rotation:10.9683,x:333.0713,y:89.6421,startPosition:89},0).wait(1).to({rotation:11.3431,x:333.2104,y:89.4214,startPosition:90},0).wait(1).to({rotation:11.7213,x:333.3508,y:89.1987,startPosition:91},0).wait(1).to({rotation:12.1026,x:333.4923,y:88.9742,startPosition:92},0).wait(1).to({rotation:12.4865,x:333.6348,y:88.7482,startPosition:93},0).wait(1).to({rotation:12.8728,x:333.7782,y:88.5208,startPosition:94},0).wait(1).to({rotation:13.2608,x:333.9222,y:88.2923,startPosition:95},0).wait(1).to({rotation:13.6503,x:334.0668,y:88.063,startPosition:96},0).wait(1).to({rotation:14.0408,x:334.2117,y:87.8331,startPosition:97},0).wait(1).to({rotation:14.4318,x:334.3569,y:87.6029,startPosition:98},0).wait(1).to({rotation:14.8229,x:334.502,y:87.3726,startPosition:99},0).wait(1).to({rotation:15.2138,x:334.6471,y:87.1425,startPosition:100},0).wait(1).to({rotation:15.6038,x:334.7919,y:86.9128,startPosition:101},0).wait(1).to({rotation:15.9927,x:334.9363,y:86.6838,startPosition:102},0).wait(1).to({rotation:16.38,x:335.08,y:86.4558,startPosition:103},0).wait(1).to({rotation:16.7653,x:335.223,y:86.2289,startPosition:104},0).wait(1).to({rotation:17.1483,x:335.3652,y:86.0035,startPosition:105},0).wait(1).to({rotation:17.5284,x:335.5063,y:85.7797,startPosition:106},0).wait(1).to({rotation:17.9054,x:335.6462,y:85.5577,startPosition:107},0).wait(1).to({rotation:18.2788,x:335.7848,y:85.3378,startPosition:108},0).wait(1).to({rotation:18.6484,x:335.922,y:85.1202,startPosition:109},0).wait(1).to({rotation:19.0139,x:336.0577,y:84.905,startPosition:110},0).wait(1).to({rotation:19.3749,x:336.1917,y:84.6925,startPosition:111},0).wait(1).to({rotation:19.7312,x:336.3239,y:84.4827,startPosition:112},0).wait(1).to({rotation:20.0824,x:336.4543,y:84.2759,startPosition:113},0).wait(1).to({rotation:20.4284,x:336.5827,y:84.0722,startPosition:114},0).wait(1).to({rotation:20.7689,x:336.7091,y:83.8717,startPosition:115},0).wait(1).to({rotation:21.1037,x:336.8334,y:83.6746,startPosition:116},0).wait(1).to({rotation:21.4327,x:336.9555,y:83.4809,startPosition:117},0).wait(1).to({rotation:21.7557,x:337.0754,y:83.2907,startPosition:118},0).wait(1).to({rotation:22.0724,x:337.1929,y:83.1042,startPosition:119},0).wait(1).to({rotation:22.3829,x:337.3082,y:82.9214,startPosition:120},0).wait(1).to({rotation:22.687,x:337.421,y:82.7424,startPosition:121},0).wait(1).to({rotation:22.9845,x:337.5315,y:82.5672,startPosition:122},0).wait(1).to({rotation:23.2754,x:337.6395,y:82.3959,startPosition:123},0).wait(1).to({rotation:23.5597,x:337.745,y:82.2286,startPosition:124},0).wait(1).to({rotation:23.8372,x:337.848,y:82.0651,startPosition:125},0).wait(1).to({rotation:24.108,x:337.9485,y:81.9057,startPosition:126},0).wait(1).to({rotation:24.372,x:338.0465,y:81.7503,startPosition:127},0).wait(1).to({rotation:24.6292,x:338.142,y:81.5988,startPosition:128},0).wait(1).to({rotation:24.8796,x:338.2349,y:81.4514,startPosition:129},0).wait(1).to({rotation:25.1232,x:338.3254,y:81.308,startPosition:130},0).wait(1).to({rotation:25.3601,x:338.4133,y:81.1685,startPosition:131},0).wait(1).to({rotation:25.5901,x:338.4987,y:81.0331,startPosition:132},0).wait(1).to({rotation:25.8134,x:338.5815,y:80.9016,startPosition:133},0).wait(1).to({rotation:26.03,x:338.662,y:80.7741,startPosition:134},0).wait(1).to({rotation:26.24,x:338.7399,y:80.6504,startPosition:135},0).wait(1).to({rotation:26.4434,x:338.8154,y:80.5307,startPosition:136},0).wait(1).to({rotation:26.6401,x:338.8884,y:80.4148,startPosition:137},0).wait(1).to({rotation:26.8304,x:338.959,y:80.3028,startPosition:138},0).wait(1).to({rotation:27.0143,x:339.05,y:80.15,startPosition:139},0).to({rotation:29.9992,x:278.3,y:98.2,startPosition:170},31,cjs.Ease.cubicInOut).to({regX:0.1,regY:-0.1,rotation:89.9991,x:272.5,y:79.05,startPosition:211},41,cjs.Ease.quartInOut).to({scaleX:0.9999,scaleY:0.9999,rotation:74.9999,x:274.3,y:78.45,startPosition:324},113,cjs.Ease.quadInOut).to({scaleX:1,scaleY:1,rotation:89.9991,x:272.5,y:79.05,startPosition:418},94,cjs.Ease.quadInOut).to({regY:0,scaleX:0.9999,scaleY:0.9999,rotation:0,x:263.6,y:45.15,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// il_mlk
	this.instance_9 = new lib.il_mlk("synched",0);
	this.instance_9.setTransform(342.1,222.75);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({x:338.05,y:241,startPosition:31},31,cjs.Ease.quartInOut).wait(1).to({regX:-0.1,rotation:0.0165,x:337.95,y:240.95,startPosition:32},0).wait(1).to({rotation:0.0377,startPosition:33},0).wait(1).to({rotation:0.0636,y:240.9,startPosition:34},0).wait(1).to({rotation:0.0944,startPosition:35},0).wait(1).to({rotation:0.1301,y:240.85,startPosition:36},0).wait(1).to({rotation:0.1708,y:240.8,startPosition:37},0).wait(1).to({rotation:0.2166,y:240.75,startPosition:38},0).wait(1).to({rotation:0.2675,y:240.7,startPosition:39},0).wait(1).to({rotation:0.3237,y:240.65,startPosition:40},0).wait(1).to({rotation:0.3853,y:240.6,startPosition:41},0).wait(1).to({rotation:0.4522,y:240.55,startPosition:42},0).wait(1).to({rotation:0.5248,y:240.5,startPosition:43},0).wait(1).to({rotation:0.6029,x:338,y:240.4,startPosition:44},0).wait(1).to({rotation:0.6867,y:240.35,startPosition:45},0).wait(1).to({rotation:0.7763,y:240.25,startPosition:46},0).wait(1).to({rotation:0.8719,y:240.15,startPosition:47},0).wait(1).to({rotation:0.9733,y:240.05,startPosition:48},0).wait(1).to({rotation:1.0809,y:239.95,startPosition:49},0).wait(1).to({rotation:1.1946,x:338.05,y:239.85,startPosition:50},0).wait(1).to({rotation:1.3146,y:239.75,startPosition:51},0).wait(1).to({rotation:1.4409,y:239.6,startPosition:52},0).wait(1).to({rotation:1.5737,y:239.5,startPosition:53},0).wait(1).to({rotation:1.7129,y:239.35,startPosition:54},0).wait(1).to({rotation:1.8588,x:338.1,y:239.2,startPosition:55},0).wait(1).to({rotation:2.0114,y:239.05,startPosition:56},0).wait(1).to({rotation:2.1707,y:238.9,startPosition:57},0).wait(1).to({rotation:2.3369,x:338.15,y:238.75,startPosition:58},0).wait(1).to({rotation:2.51,y:238.6,startPosition:59},0).wait(1).to({rotation:2.69,y:238.45,startPosition:60},0).wait(1).to({rotation:2.8772,y:238.25,startPosition:61},0).wait(1).to({rotation:3.0714,x:338.2,y:238.05,startPosition:62},0).wait(1).to({rotation:3.2729,y:237.9,startPosition:63},0).wait(1).to({rotation:3.4815,x:338.25,y:237.7,startPosition:64},0).wait(1).to({rotation:3.6974,y:237.5,startPosition:65},0).wait(1).to({rotation:3.9206,y:237.25,startPosition:66},0).wait(1).to({rotation:4.1512,x:338.3,y:237.05,startPosition:67},0).wait(1).to({rotation:4.3891,y:236.85,startPosition:68},0).wait(1).to({rotation:4.6343,x:338.35,y:236.6,startPosition:69},0).wait(1).to({rotation:4.8869,y:236.35,startPosition:70},0).wait(1).to({rotation:5.1468,y:236.1,startPosition:71},0).wait(1).to({rotation:5.414,x:338.4,y:235.85,startPosition:72},0).wait(1).to({rotation:5.6885,y:235.6,startPosition:73},0).wait(1).to({rotation:5.9702,x:338.45,y:235.35,startPosition:74},0).wait(1).to({rotation:6.259,y:235.05,startPosition:75},0).wait(1).to({rotation:6.5548,x:338.5,y:234.8,startPosition:76},0).wait(1).to({rotation:6.8576,y:234.5,startPosition:77},0).wait(1).to({rotation:7.1672,x:338.55,y:234.2,startPosition:78},0).wait(1).to({rotation:7.4835,y:233.9,startPosition:79},0).wait(1).to({rotation:7.8063,x:338.6,y:233.6,startPosition:80},0).wait(1).to({rotation:8.1354,x:338.65,y:233.3,startPosition:81},0).wait(1).to({rotation:8.4707,y:232.95,startPosition:82},0).wait(1).to({rotation:8.8119,x:338.7,y:232.65,startPosition:83},0).wait(1).to({rotation:9.1587,y:232.3,startPosition:84},0).wait(1).to({rotation:9.511,x:338.75,y:232,startPosition:85},0).wait(1).to({rotation:9.8684,x:338.8,y:231.65,startPosition:86},0).wait(1).to({rotation:10.2306,y:231.3,startPosition:87},0).wait(1).to({rotation:10.5974,x:338.85,y:230.95,startPosition:88},0).wait(1).to({rotation:10.9683,x:338.9,y:230.6,startPosition:89},0).wait(1).to({rotation:11.3431,y:230.25,startPosition:90},0).wait(1).to({rotation:11.7213,x:338.95,y:229.9,startPosition:91},0).wait(1).to({rotation:12.1026,x:339,y:229.55,startPosition:92},0).wait(1).to({rotation:12.4865,y:229.2,startPosition:93},0).wait(1).to({rotation:12.8728,x:339.05,y:228.8,startPosition:94},0).wait(1).to({rotation:13.2608,x:339.1,y:228.45,startPosition:95},0).wait(1).to({rotation:13.6503,y:228.1,startPosition:96},0).wait(1).to({rotation:14.0408,x:339.15,y:227.7,startPosition:97},0).wait(1).to({rotation:14.4318,x:339.2,y:227.35,startPosition:98},0).wait(1).to({rotation:14.8229,y:226.9,startPosition:99},0).wait(1).to({rotation:15.2138,x:339.25,y:226.55,startPosition:100},0).wait(1).to({rotation:15.6038,x:339.3,y:226.2,startPosition:101},0).wait(1).to({rotation:15.9927,y:225.8,startPosition:102},0).wait(1).to({rotation:16.38,x:339.35,y:225.45,startPosition:103},0).wait(1).to({rotation:16.7653,x:339.4,y:225.1,startPosition:104},0).wait(1).to({rotation:17.1483,y:224.7,startPosition:105},0).wait(1).to({rotation:17.5284,x:339.45,y:224.35,startPosition:106},0).wait(1).to({rotation:17.9054,x:339.5,y:224,startPosition:107},0).wait(1).to({rotation:18.2788,y:223.65,startPosition:108},0).wait(1).to({rotation:18.6484,x:339.55,y:223.3,startPosition:109},0).wait(1).to({rotation:19.0139,x:339.6,y:222.95,startPosition:110},0).wait(1).to({rotation:19.3749,y:222.6,startPosition:111},0).wait(1).to({rotation:19.7312,x:339.65,y:222.3,startPosition:112},0).wait(1).to({rotation:20.0824,y:221.95,startPosition:113},0).wait(1).to({rotation:20.4284,x:339.7,y:221.6,startPosition:114},0).wait(1).to({rotation:20.7689,x:339.75,y:221.3,startPosition:115},0).wait(1).to({rotation:21.1037,y:221,startPosition:116},0).wait(1).to({rotation:21.4327,x:339.8,y:220.65,startPosition:117},0).wait(1).to({rotation:21.7557,y:220.35,startPosition:118},0).wait(1).to({rotation:22.0724,x:339.85,y:220.05,startPosition:119},0).wait(1).to({rotation:22.3829,y:219.75,startPosition:120},0).wait(1).to({rotation:22.687,x:339.9,y:219.5,startPosition:121},0).wait(1).to({rotation:22.9845,y:219.2,startPosition:122},0).wait(1).to({rotation:23.2754,x:339.95,y:218.95,startPosition:123},0).wait(1).to({rotation:23.5597,y:218.65,startPosition:124},0).wait(1).to({rotation:23.8372,x:340,y:218.4,startPosition:125},0).wait(1).to({rotation:24.108,y:218.15,startPosition:126},0).wait(1).to({rotation:24.372,x:340.05,y:217.9,startPosition:127},0).wait(1).to({rotation:24.6292,y:217.65,startPosition:128},0).wait(1).to({rotation:24.8796,x:340.1,y:217.4,startPosition:129},0).wait(1).to({rotation:25.1232,y:217.2,startPosition:130},0).wait(1).to({rotation:25.3601,x:340.15,y:216.95,startPosition:131},0).wait(1).to({rotation:25.5901,y:216.75,startPosition:132},0).wait(1).to({rotation:25.8134,y:216.55,startPosition:133},0).wait(1).to({rotation:26.03,x:340.2,y:216.35,startPosition:134},0).wait(1).to({rotation:26.24,y:216.15,startPosition:135},0).wait(1).to({rotation:26.4434,y:215.95,startPosition:136},0).wait(1).to({rotation:26.6401,x:340.25,y:215.75,startPosition:137},0).wait(1).to({rotation:26.8304,y:215.55,startPosition:138},0).wait(1).to({regX:0,rotation:27.0143,x:340.35,y:215.45,startPosition:139},0).to({rotation:29.9992,x:263.95,y:188.55,startPosition:170},31,cjs.Ease.cubicInOut).to({x:276.8,y:184.7,startPosition:211},41,cjs.Ease.quartInOut).to({regX:0.1,regY:-0.1,rotation:44.9988,x:263.65,y:171.15,startPosition:324},113,cjs.Ease.quadInOut).to({regX:0,regY:0,rotation:29.9992,x:276.8,y:178.15,startPosition:418},94,cjs.Ease.quadInOut).to({rotation:0,x:262.85,y:169.65,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// il_ban
	this.instance_10 = new lib.il_ban("synched",0);
	this.instance_10.setTransform(-30.55,224.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({x:48.9,y:202.45,startPosition:31},31,cjs.Ease.quartInOut).wait(1).to({rotation:0.0083,x:48.895,y:202.4467,startPosition:32},0).wait(1).to({rotation:0.0188,x:48.8887,y:202.4425,startPosition:33},0).wait(1).to({rotation:0.0318,x:48.8809,y:202.4373,startPosition:34},0).wait(1).to({rotation:0.0472,x:48.8717,y:202.4311,startPosition:35},0).wait(1).to({rotation:0.065,x:48.861,y:202.424,startPosition:36},0).wait(1).to({rotation:0.0854,x:48.8488,y:202.4159,startPosition:37},0).wait(1).to({rotation:0.1083,x:48.8351,y:202.4067,startPosition:38},0).wait(1).to({rotation:0.1337,x:48.8198,y:202.3965,startPosition:39},0).wait(1).to({rotation:0.1618,x:48.8029,y:202.3853,startPosition:40},0).wait(1).to({rotation:0.1926,x:48.7845,y:202.373,startPosition:41},0).wait(1).to({rotation:0.2261,x:48.7644,y:202.3596,startPosition:42},0).wait(1).to({rotation:0.2623,x:48.7427,y:202.3451,startPosition:43},0).wait(1).to({rotation:0.3014,x:48.7192,y:202.3295,startPosition:44},0).wait(1).to({rotation:0.3433,x:48.6941,y:202.3127,startPosition:45},0).wait(1).to({rotation:0.3881,x:48.6672,y:202.2948,startPosition:46},0).wait(1).to({rotation:0.4359,x:48.6386,y:202.2757,startPosition:47},0).wait(1).to({rotation:0.4866,x:48.6081,y:202.2554,startPosition:48},0).wait(1).to({rotation:0.5404,x:48.5759,y:202.2339,startPosition:49},0).wait(1).to({rotation:0.5972,x:48.5418,y:202.2112,startPosition:50},0).wait(1).to({rotation:0.6572,x:48.5058,y:202.1872,startPosition:51},0).wait(1).to({rotation:0.7204,x:48.4679,y:202.162,startPosition:52},0).wait(1).to({rotation:0.7867,x:48.4281,y:202.1354,startPosition:53},0).wait(1).to({rotation:0.8564,x:48.3864,y:202.1076,startPosition:54},0).wait(1).to({rotation:0.9293,x:48.3426,y:202.0784,startPosition:55},0).wait(1).to({rotation:1.0056,x:48.2969,y:202.0479,startPosition:56},0).wait(1).to({rotation:1.0852,x:48.2491,y:202.0161,startPosition:57},0).wait(1).to({rotation:1.1683,x:48.1993,y:201.9829,startPosition:58},0).wait(1).to({rotation:1.2548,x:48.1474,y:201.9483,startPosition:59},0).wait(1).to({rotation:1.3449,x:48.0934,y:201.9123,startPosition:60},0).wait(1).to({rotation:1.4384,x:48.0373,y:201.8749,startPosition:61},0).wait(1).to({rotation:1.5355,x:47.9791,y:201.836,startPosition:62},0).wait(1).to({rotation:1.6362,x:47.9187,y:201.7958,startPosition:63},0).wait(1).to({rotation:1.7405,x:47.8561,y:201.7541,startPosition:64},0).wait(1).to({rotation:1.8485,x:47.7914,y:201.7109,startPosition:65},0).wait(1).to({rotation:1.9601,x:47.7244,y:201.6663,startPosition:66},0).wait(1).to({rotation:2.0753,x:47.6553,y:201.6202,startPosition:67},0).wait(1).to({rotation:2.1943,x:47.584,y:201.5727,startPosition:68},0).wait(1).to({rotation:2.3169,x:47.5104,y:201.5236,startPosition:69},0).wait(1).to({rotation:2.4431,x:47.4347,y:201.4731,startPosition:70},0).wait(1).to({rotation:2.5731,x:47.3568,y:201.4212,startPosition:71},0).wait(1).to({rotation:2.7067,x:47.2767,y:201.3678,startPosition:72},0).wait(1).to({rotation:2.8439,x:47.1944,y:201.3129,startPosition:73},0).wait(1).to({rotation:2.9847,x:47.1099,y:201.2566,startPosition:74},0).wait(1).to({rotation:3.1291,x:47.0233,y:201.1989,startPosition:75},0).wait(1).to({rotation:3.277,x:46.9346,y:201.1397,startPosition:76},0).wait(1).to({rotation:3.4284,x:46.8438,y:201.0792,startPosition:77},0).wait(1).to({rotation:3.5832,x:46.751,y:201.0173,startPosition:78},0).wait(1).to({rotation:3.7413,x:46.6561,y:200.9541,startPosition:79},0).wait(1).to({rotation:3.9027,x:46.5593,y:200.8896,startPosition:80},0).wait(1).to({rotation:4.0672,x:46.4607,y:200.8238,startPosition:81},0).wait(1).to({rotation:4.2348,x:46.3601,y:200.7568,startPosition:82},0).wait(1).to({rotation:4.4054,x:46.2578,y:200.6886,startPosition:83},0).wait(1).to({rotation:4.5788,x:46.1538,y:200.6192,startPosition:84},0).wait(1).to({rotation:4.7549,x:46.0482,y:200.5488,startPosition:85},0).wait(1).to({rotation:4.9336,x:45.941,y:200.4774,startPosition:86},0).wait(1).to({rotation:5.1147,x:45.8324,y:200.405,startPosition:87},0).wait(1).to({rotation:5.298,x:45.7225,y:200.3316,startPosition:88},0).wait(1).to({rotation:5.4835,x:45.6112,y:200.2575,startPosition:89},0).wait(1).to({rotation:5.6708,x:45.4989,y:200.1826,startPosition:90},0).wait(1).to({rotation:5.8599,x:45.3855,y:200.107,startPosition:91},0).wait(1).to({rotation:6.0506,x:45.2711,y:200.0308,startPosition:92},0).wait(1).to({rotation:6.2425,x:45.156,y:199.954,startPosition:93},0).wait(1).to({rotation:6.4356,x:45.0402,y:199.8768,startPosition:94},0).wait(1).to({rotation:6.6296,x:44.9239,y:199.7992,startPosition:95},0).wait(1).to({rotation:6.8243,x:44.8071,y:199.7214,startPosition:96},0).wait(1).to({rotation:7.0195,x:44.69,y:199.6433,startPosition:97},0).wait(1).to({rotation:7.215,x:44.5728,y:199.5652,startPosition:98},0).wait(1).to({rotation:7.4106,x:44.4555,y:199.487,startPosition:99},0).wait(1).to({rotation:7.6059,x:44.3383,y:199.4089,startPosition:100},0).wait(1).to({rotation:7.801,x:44.2213,y:199.3309,startPosition:101},0).wait(1).to({rotation:7.9954,x:44.1047,y:199.2531,startPosition:102},0).wait(1).to({rotation:8.189,x:43.9886,y:199.1757,startPosition:103},0).wait(1).to({rotation:8.3816,x:43.8731,y:199.0987,startPosition:104},0).wait(1).to({rotation:8.5731,x:43.7582,y:199.0222,startPosition:105},0).wait(1).to({rotation:8.7631,x:43.6443,y:198.9462,startPosition:106},0).wait(1).to({rotation:8.9516,x:43.5312,y:198.8708,startPosition:107},0).wait(1).to({rotation:9.1383,x:43.4193,y:198.7962,startPosition:108},0).wait(1).to({rotation:9.3231,x:43.3084,y:198.7223,startPosition:109},0).wait(1).to({rotation:9.5058,x:43.1988,y:198.6492,startPosition:110},0).wait(1).to({rotation:9.6863,x:43.0906,y:198.5771,startPosition:111},0).wait(1).to({rotation:9.8644,x:42.9838,y:198.5059,startPosition:112},0).wait(1).to({rotation:10.04,x:42.8785,y:198.4356,startPosition:113},0).wait(1).to({rotation:10.2129,x:42.7747,y:198.3665,startPosition:114},0).wait(1).to({rotation:10.3832,x:42.6726,y:198.2984,startPosition:115},0).wait(1).to({rotation:10.5506,x:42.5722,y:198.2315,startPosition:116},0).wait(1).to({rotation:10.715,x:42.4736,y:198.1657,startPosition:117},0).wait(1).to({rotation:10.8765,x:42.3768,y:198.1012,startPosition:118},0).wait(1).to({rotation:11.0349,x:42.2818,y:198.0378,startPosition:119},0).wait(1).to({rotation:11.1901,x:42.1887,y:197.9758,startPosition:120},0).wait(1).to({rotation:11.3421,x:42.0975,y:197.915,startPosition:121},0).wait(1).to({rotation:11.4908,x:42.0083,y:197.8555,startPosition:122},0).wait(1).to({rotation:11.6363,x:41.9211,y:197.7974,startPosition:123},0).wait(1).to({rotation:11.7784,x:41.8358,y:197.7406,startPosition:124},0).wait(1).to({rotation:11.9172,x:41.7526,y:197.6851,startPosition:125},0).wait(1).to({rotation:12.0525,x:41.6714,y:197.6309,startPosition:126},0).wait(1).to({rotation:12.1845,x:41.5923,y:197.5782,startPosition:127},0).wait(1).to({rotation:12.3131,x:41.5151,y:197.5268,startPosition:128},0).wait(1).to({rotation:12.4383,x:41.4401,y:197.4767,startPosition:129},0).wait(1).to({rotation:12.5601,x:41.367,y:197.428,startPosition:130},0).wait(1).to({rotation:12.6785,x:41.296,y:197.3807,startPosition:131},0).wait(1).to({rotation:12.7935,x:41.227,y:197.3347,startPosition:132},0).wait(1).to({rotation:12.9051,x:41.1601,y:197.29,startPosition:133},0).wait(1).to({rotation:13.0134,x:41.0951,y:197.2467,startPosition:134},0).wait(1).to({rotation:13.1184,x:41.0322,y:197.2048,startPosition:135},0).wait(1).to({rotation:13.2201,x:40.9712,y:197.1641,startPosition:136},0).wait(1).to({rotation:13.3184,x:40.9122,y:197.1248,startPosition:137},0).wait(1).to({rotation:13.4136,x:40.8551,y:197.0868,startPosition:138},0).wait(1).to({rotation:13.5055,x:40.8,y:197.05,startPosition:139},0).to({rotation:14.9992,x:39.9,y:196.4,startPosition:170},31,cjs.Ease.cubicInOut).to({x:40.2,y:175.4,startPosition:211},41,cjs.Ease.quartInOut).to({rotation:29.9984,x:40.55,y:173.6,startPosition:324},113,cjs.Ease.quadInOut).to({rotation:14.9992,x:42.25,y:172.55,startPosition:418},94,cjs.Ease.quadInOut).to({rotation:0,x:39.45,y:165.45,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// il_rz
	this.instance_11 = new lib.il_rz("synched",0);
	this.instance_11.setTransform(-23.55,153.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({x:-27.6,startPosition:31},31,cjs.Ease.quartInOut).wait(1).to({rotation:0.0083,x:-27.596,y:153.6039,startPosition:32},0).wait(1).to({rotation:0.0188,x:-27.5908,y:153.6089,startPosition:33},0).wait(1).to({rotation:0.0318,x:-27.5845,y:153.6151,startPosition:34},0).wait(1).to({rotation:0.0472,x:-27.5769,y:153.6224,startPosition:35},0).wait(1).to({rotation:0.065,x:-27.5682,y:153.6309,startPosition:36},0).wait(1).to({rotation:0.0854,x:-27.5583,y:153.6405,startPosition:37},0).wait(1).to({rotation:0.1083,x:-27.5471,y:153.6514,startPosition:38},0).wait(1).to({rotation:0.1337,x:-27.5347,y:153.6635,startPosition:39},0).wait(1).to({rotation:0.1618,x:-27.5209,y:153.6768,startPosition:40},0).wait(1).to({rotation:0.1926,x:-27.5059,y:153.6914,startPosition:41},0).wait(1).to({rotation:0.2261,x:-27.4895,y:153.7073,startPosition:42},0).wait(1).to({rotation:0.2623,x:-27.4718,y:153.7245,startPosition:43},0).wait(1).to({rotation:0.3014,x:-27.4527,y:153.7431,startPosition:44},0).wait(1).to({rotation:0.3433,x:-27.4323,y:153.763,startPosition:45},0).wait(1).to({rotation:0.3881,x:-27.4104,y:153.7843,startPosition:46},0).wait(1).to({rotation:0.4359,x:-27.387,y:153.8069,startPosition:47},0).wait(1).to({rotation:0.4866,x:-27.3622,y:153.831,startPosition:48},0).wait(1).to({rotation:0.5404,x:-27.336,y:153.8565,startPosition:49},0).wait(1).to({rotation:0.5972,x:-27.3082,y:153.8835,startPosition:50},0).wait(1).to({rotation:0.6572,x:-27.2789,y:153.912,startPosition:51},0).wait(1).to({rotation:0.7204,x:-27.248,y:153.942,startPosition:52},0).wait(1).to({rotation:0.7867,x:-27.2156,y:153.9735,startPosition:53},0).wait(1).to({rotation:0.8564,x:-27.1816,y:154.0066,startPosition:54},0).wait(1).to({rotation:0.9293,x:-27.146,y:154.0412,startPosition:55},0).wait(1).to({rotation:1.0056,x:-27.1087,y:154.0774,startPosition:56},0).wait(1).to({rotation:1.0852,x:-27.0698,y:154.1152,startPosition:57},0).wait(1).to({rotation:1.1683,x:-27.0292,y:154.1546,startPosition:58},0).wait(1).to({rotation:1.2548,x:-26.9869,y:154.1957,startPosition:59},0).wait(1).to({rotation:1.3449,x:-26.9429,y:154.2385,startPosition:60},0).wait(1).to({rotation:1.4384,x:-26.8972,y:154.2829,startPosition:61},0).wait(1).to({rotation:1.5355,x:-26.8498,y:154.329,startPosition:62},0).wait(1).to({rotation:1.6362,x:-26.8006,y:154.3768,startPosition:63},0).wait(1).to({rotation:1.7405,x:-26.7496,y:154.4263,startPosition:64},0).wait(1).to({rotation:1.8485,x:-26.6969,y:154.4776,startPosition:65},0).wait(1).to({rotation:1.9601,x:-26.6423,y:154.5305,startPosition:66},0).wait(1).to({rotation:2.0753,x:-26.586,y:154.5853,startPosition:67},0).wait(1).to({rotation:2.1943,x:-26.5279,y:154.6417,startPosition:68},0).wait(1).to({rotation:2.3169,x:-26.468,y:154.6999,startPosition:69},0).wait(1).to({rotation:2.4431,x:-26.4063,y:154.7599,startPosition:70},0).wait(1).to({rotation:2.5731,x:-26.3428,y:154.8216,startPosition:71},0).wait(1).to({rotation:2.7067,x:-26.2776,y:154.885,startPosition:72},0).wait(1).to({rotation:2.8439,x:-26.2105,y:154.9501,startPosition:73},0).wait(1).to({rotation:2.9847,x:-26.1417,y:155.017,startPosition:74},0).wait(1).to({rotation:3.1291,x:-26.0712,y:155.0855,startPosition:75},0).wait(1).to({rotation:3.277,x:-25.9989,y:155.1557,startPosition:76},0).wait(1).to({rotation:3.4284,x:-25.9249,y:155.2276,startPosition:77},0).wait(1).to({rotation:3.5832,x:-25.8493,y:155.3011,startPosition:78},0).wait(1).to({rotation:3.7413,x:-25.772,y:155.3762,startPosition:79},0).wait(1).to({rotation:3.9027,x:-25.6932,y:155.4528,startPosition:80},0).wait(1).to({rotation:4.0672,x:-25.6128,y:155.5309,startPosition:81},0).wait(1).to({rotation:4.2348,x:-25.5309,y:155.6105,startPosition:82},0).wait(1).to({rotation:4.4054,x:-25.4476,y:155.6914,startPosition:83},0).wait(1).to({rotation:4.5788,x:-25.3629,y:155.7738,startPosition:84},0).wait(1).to({rotation:4.7549,x:-25.2768,y:155.8574,startPosition:85},0).wait(1).to({rotation:4.9336,x:-25.1895,y:155.9422,startPosition:86},0).wait(1).to({rotation:5.1147,x:-25.101,y:156.0282,startPosition:87},0).wait(1).to({rotation:5.298,x:-25.0114,y:156.1152,startPosition:88},0).wait(1).to({rotation:5.4835,x:-24.9208,y:156.2033,startPosition:89},0).wait(1).to({rotation:5.6708,x:-24.8293,y:156.2922,startPosition:90},0).wait(1).to({rotation:5.8599,x:-24.7369,y:156.382,startPosition:91},0).wait(1).to({rotation:6.0506,x:-24.6438,y:156.4725,startPosition:92},0).wait(1).to({rotation:6.2425,x:-24.55,y:156.5636,startPosition:93},0).wait(1).to({rotation:6.4356,x:-24.4556,y:156.6553,startPosition:94},0).wait(1).to({rotation:6.6296,x:-24.3609,y:156.7474,startPosition:95},0).wait(1).to({rotation:6.8243,x:-24.2657,y:156.8398,startPosition:96},0).wait(1).to({rotation:7.0195,x:-24.1703,y:156.9325,startPosition:97},0).wait(1).to({rotation:7.215,x:-24.0748,y:157.0253,startPosition:98},0).wait(1).to({rotation:7.4106,x:-23.9793,y:157.1181,startPosition:99},0).wait(1).to({rotation:7.6059,x:-23.8838,y:157.2109,startPosition:100},0).wait(1).to({rotation:7.801,x:-23.7885,y:157.3035,startPosition:101},0).wait(1).to({rotation:7.9954,x:-23.6936,y:157.3958,startPosition:102},0).wait(1).to({rotation:8.189,x:-23.5989,y:157.4877,startPosition:103},0).wait(1).to({rotation:8.3816,x:-23.5048,y:157.5792,startPosition:104},0).wait(1).to({rotation:8.5731,x:-23.4113,y:157.67,startPosition:105},0).wait(1).to({rotation:8.7631,x:-23.3185,y:157.7603,startPosition:106},0).wait(1).to({rotation:8.9516,x:-23.2264,y:157.8497,startPosition:107},0).wait(1).to({rotation:9.1383,x:-23.1351,y:157.9384,startPosition:108},0).wait(1).to({rotation:9.3231,x:-23.0449,y:158.0261,startPosition:109},0).wait(1).to({rotation:9.5058,x:-22.9556,y:158.1128,startPosition:110},0).wait(1).to({rotation:9.6863,x:-22.8674,y:158.1985,startPosition:111},0).wait(1).to({rotation:9.8644,x:-22.7804,y:158.2831,startPosition:112},0).wait(1).to({rotation:10.04,x:-22.6946,y:158.3664,startPosition:113},0).wait(1).to({rotation:10.2129,x:-22.6101,y:158.4486,startPosition:114},0).wait(1).to({rotation:10.3832,x:-22.5269,y:158.5294,startPosition:115},0).wait(1).to({rotation:10.5506,x:-22.4451,y:158.6088,startPosition:116},0).wait(1).to({rotation:10.715,x:-22.3648,y:158.6869,startPosition:117},0).wait(1).to({rotation:10.8765,x:-22.2859,y:158.7636,startPosition:118},0).wait(1).to({rotation:11.0349,x:-22.2085,y:158.8388,startPosition:119},0).wait(1).to({rotation:11.1901,x:-22.1327,y:158.9124,startPosition:120},0).wait(1).to({rotation:11.3421,x:-22.0584,y:158.9846,startPosition:121},0).wait(1).to({rotation:11.4908,x:-21.9857,y:159.0552,startPosition:122},0).wait(1).to({rotation:11.6363,x:-21.9147,y:159.1243,startPosition:123},0).wait(1).to({rotation:11.7784,x:-21.8452,y:159.1917,startPosition:124},0).wait(1).to({rotation:11.9172,x:-21.7774,y:159.2576,startPosition:125},0).wait(1).to({rotation:12.0525,x:-21.7113,y:159.3219,startPosition:126},0).wait(1).to({rotation:12.1845,x:-21.6468,y:159.3846,startPosition:127},0).wait(1).to({rotation:12.3131,x:-21.584,y:159.4456,startPosition:128},0).wait(1).to({rotation:12.4383,x:-21.5228,y:159.505,startPosition:129},0).wait(1).to({rotation:12.5601,x:-21.4633,y:159.5628,startPosition:130},0).wait(1).to({rotation:12.6785,x:-21.4055,y:159.6191,startPosition:131},0).wait(1).to({rotation:12.7935,x:-21.3493,y:159.6737,startPosition:132},0).wait(1).to({rotation:12.9051,x:-21.2947,y:159.7267,startPosition:133},0).wait(1).to({rotation:13.0134,x:-21.2418,y:159.7781,startPosition:134},0).wait(1).to({rotation:13.1184,x:-21.1905,y:159.8279,startPosition:135},0).wait(1).to({rotation:13.2201,x:-21.1408,y:159.8762,startPosition:136},0).wait(1).to({rotation:13.3184,x:-21.0928,y:159.9229,startPosition:137},0).wait(1).to({rotation:13.4136,x:-21.0463,y:159.968,startPosition:138},0).wait(1).to({rotation:13.5055,x:-21.05,y:160,startPosition:139},0).to({rotation:14.9992,x:23,y:144.95,startPosition:170},31,cjs.Ease.cubicInOut).to({x:0,y:106.35,startPosition:211},41,cjs.Ease.quartInOut).to({rotation:0,x:-1.15,y:102.15,startPosition:324},113,cjs.Ease.quadInOut).to({rotation:14.9992,x:0,y:106.35,startPosition:418},94,cjs.Ease.quadInOut).to({x:82.8,y:18.4,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// il_car
	this.instance_12 = new lib.il_car("synched",0);
	this.instance_12.setTransform(-30,69.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({x:-43.75,startPosition:31},31,cjs.Ease.quartInOut).wait(1).to({rotation:0.0083,x:-43.752,y:69.6012,startPosition:32},0).wait(1).to({rotation:0.0188,x:-43.7547,y:69.6027,startPosition:33},0).wait(1).to({rotation:0.0318,x:-43.7579,y:69.6045,startPosition:34},0).wait(1).to({rotation:0.0472,x:-43.7617,y:69.6066,startPosition:35},0).wait(1).to({rotation:0.065,x:-43.7661,y:69.6091,startPosition:36},0).wait(1).to({rotation:0.0854,x:-43.7712,y:69.612,startPosition:37},0).wait(1).to({rotation:0.1083,x:-43.7769,y:69.6152,startPosition:38},0).wait(1).to({rotation:0.1337,x:-43.7832,y:69.6188,startPosition:39},0).wait(1).to({rotation:0.1618,x:-43.7901,y:69.6228,startPosition:40},0).wait(1).to({rotation:0.1926,x:-43.7978,y:69.6271,startPosition:41},0).wait(1).to({rotation:0.2261,x:-43.8061,y:69.6318,startPosition:42},0).wait(1).to({rotation:0.2623,x:-43.8151,y:69.6369,startPosition:43},0).wait(1).to({rotation:0.3014,x:-43.8248,y:69.6424,startPosition:44},0).wait(1).to({rotation:0.3433,x:-43.8352,y:69.6483,startPosition:45},0).wait(1).to({rotation:0.3881,x:-43.8463,y:69.6546,startPosition:46},0).wait(1).to({rotation:0.4359,x:-43.8581,y:69.6613,startPosition:47},0).wait(1).to({rotation:0.4866,x:-43.8707,y:69.6685,startPosition:48},0).wait(1).to({rotation:0.5404,x:-43.884,y:69.676,startPosition:49},0).wait(1).to({rotation:0.5972,x:-43.8981,y:69.684,startPosition:50},0).wait(1).to({rotation:0.6572,x:-43.913,y:69.6925,startPosition:51},0).wait(1).to({rotation:0.7204,x:-43.9287,y:69.7013,startPosition:52},0).wait(1).to({rotation:0.7867,x:-43.9451,y:69.7107,startPosition:53},0).wait(1).to({rotation:0.8564,x:-43.9624,y:69.7205,startPosition:54},0).wait(1).to({rotation:0.9293,x:-43.9805,y:69.7307,startPosition:55},0).wait(1).to({rotation:1.0056,x:-43.9994,y:69.7415,startPosition:56},0).wait(1).to({rotation:1.0852,x:-44.0192,y:69.7527,startPosition:57},0).wait(1).to({rotation:1.1683,x:-44.0398,y:69.7644,startPosition:58},0).wait(1).to({rotation:1.2548,x:-44.0613,y:69.7765,startPosition:59},0).wait(1).to({rotation:1.3449,x:-44.0836,y:69.7892,startPosition:60},0).wait(1).to({rotation:1.4384,x:-44.1068,y:69.8024,startPosition:61},0).wait(1).to({rotation:1.5355,x:-44.1309,y:69.816,startPosition:62},0).wait(1).to({rotation:1.6362,x:-44.1559,y:69.8302,startPosition:63},0).wait(1).to({rotation:1.7405,x:-44.1817,y:69.8449,startPosition:64},0).wait(1).to({rotation:1.8485,x:-44.2085,y:69.8601,startPosition:65},0).wait(1).to({rotation:1.9601,x:-44.2362,y:69.8758,startPosition:66},0).wait(1).to({rotation:2.0753,x:-44.2648,y:69.892,startPosition:67},0).wait(1).to({rotation:2.1943,x:-44.2943,y:69.9087,startPosition:68},0).wait(1).to({rotation:2.3169,x:-44.3247,y:69.9259,startPosition:69},0).wait(1).to({rotation:2.4431,x:-44.356,y:69.9437,startPosition:70},0).wait(1).to({rotation:2.5731,x:-44.3882,y:69.962,startPosition:71},0).wait(1).to({rotation:2.7067,x:-44.4214,y:69.9808,startPosition:72},0).wait(1).to({rotation:2.8439,x:-44.4554,y:70.0001,startPosition:73},0).wait(1).to({rotation:2.9847,x:-44.4904,y:70.0199,startPosition:74},0).wait(1).to({rotation:3.1291,x:-44.5262,y:70.0402,startPosition:75},0).wait(1).to({rotation:3.277,x:-44.5629,y:70.061,startPosition:76},0).wait(1).to({rotation:3.4284,x:-44.6004,y:70.0823,startPosition:77},0).wait(1).to({rotation:3.5832,x:-44.6388,y:70.1041,startPosition:78},0).wait(1).to({rotation:3.7413,x:-44.678,y:70.1263,startPosition:79},0).wait(1).to({rotation:3.9027,x:-44.718,y:70.149,startPosition:80},0).wait(1).to({rotation:4.0672,x:-44.7589,y:70.1722,startPosition:81},0).wait(1).to({rotation:4.2348,x:-44.8004,y:70.1958,startPosition:82},0).wait(1).to({rotation:4.4054,x:-44.8427,y:70.2198,startPosition:83},0).wait(1).to({rotation:4.5788,x:-44.8858,y:70.2442,startPosition:84},0).wait(1).to({rotation:4.7549,x:-44.9294,y:70.2689,startPosition:85},0).wait(1).to({rotation:4.9336,x:-44.9738,y:70.2941,startPosition:86},0).wait(1).to({rotation:5.1147,x:-45.0187,y:70.3196,startPosition:87},0).wait(1).to({rotation:5.298,x:-45.0642,y:70.3453,startPosition:88},0).wait(1).to({rotation:5.4835,x:-45.1102,y:70.3714,startPosition:89},0).wait(1).to({rotation:5.6708,x:-45.1566,y:70.3978,startPosition:90},0).wait(1).to({rotation:5.8599,x:-45.2035,y:70.4244,startPosition:91},0).wait(1).to({rotation:6.0506,x:-45.2508,y:70.4512,startPosition:92},0).wait(1).to({rotation:6.2425,x:-45.2984,y:70.4782,startPosition:93},0).wait(1).to({rotation:6.4356,x:-45.3463,y:70.5054,startPosition:94},0).wait(1).to({rotation:6.6296,x:-45.3945,y:70.5327,startPosition:95},0).wait(1).to({rotation:6.8243,x:-45.4428,y:70.5601,startPosition:96},0).wait(1).to({rotation:7.0195,x:-45.4912,y:70.5875,startPosition:97},0).wait(1).to({rotation:7.215,x:-45.5397,y:70.615,startPosition:98},0).wait(1).to({rotation:7.4106,x:-45.5882,y:70.6425,startPosition:99},0).wait(1).to({rotation:7.6059,x:-45.6366,y:70.67,startPosition:100},0).wait(1).to({rotation:7.801,x:-45.685,y:70.6975,startPosition:101},0).wait(1).to({rotation:7.9954,x:-45.7332,y:70.7248,startPosition:102},0).wait(1).to({rotation:8.189,x:-45.7813,y:70.7521,startPosition:103},0).wait(1).to({rotation:8.3816,x:-45.829,y:70.7792,startPosition:104},0).wait(1).to({rotation:8.5731,x:-45.8765,y:70.8061,startPosition:105},0).wait(1).to({rotation:8.7631,x:-45.9237,y:70.8328,startPosition:106},0).wait(1).to({rotation:8.9516,x:-45.9704,y:70.8593,startPosition:107},0).wait(1).to({rotation:9.1383,x:-46.0167,y:70.8856,startPosition:108},0).wait(1).to({rotation:9.3231,x:-46.0626,y:70.9116,startPosition:109},0).wait(1).to({rotation:9.5058,x:-46.1079,y:70.9373,startPosition:110},0).wait(1).to({rotation:9.6863,x:-46.1527,y:70.9627,startPosition:111},0).wait(1).to({rotation:9.8644,x:-46.1968,y:70.9878,startPosition:112},0).wait(1).to({rotation:10.04,x:-46.2404,y:71.0125,startPosition:113},0).wait(1).to({rotation:10.2129,x:-46.2833,y:71.0368,startPosition:114},0).wait(1).to({rotation:10.3832,x:-46.3255,y:71.0607,startPosition:115},0).wait(1).to({rotation:10.5506,x:-46.367,y:71.0843,startPosition:116},0).wait(1).to({rotation:10.715,x:-46.4078,y:71.1074,startPosition:117},0).wait(1).to({rotation:10.8765,x:-46.4479,y:71.1301,startPosition:118},0).wait(1).to({rotation:11.0349,x:-46.4872,y:71.1524,startPosition:119},0).wait(1).to({rotation:11.1901,x:-46.5257,y:71.1743,startPosition:120},0).wait(1).to({rotation:11.3421,x:-46.5634,y:71.1956,startPosition:121},0).wait(1).to({rotation:11.4908,x:-46.6003,y:71.2166,startPosition:122},0).wait(1).to({rotation:11.6363,x:-46.6363,y:71.237,startPosition:123},0).wait(1).to({rotation:11.7784,x:-46.6716,y:71.257,startPosition:124},0).wait(1).to({rotation:11.9172,x:-46.706,y:71.2765,startPosition:125},0).wait(1).to({rotation:12.0525,x:-46.7396,y:71.2956,startPosition:126},0).wait(1).to({rotation:12.1845,x:-46.7723,y:71.3142,startPosition:127},0).wait(1).to({rotation:12.3131,x:-46.8042,y:71.3323,startPosition:128},0).wait(1).to({rotation:12.4383,x:-46.8353,y:71.3499,startPosition:129},0).wait(1).to({rotation:12.5601,x:-46.8655,y:71.367,startPosition:130},0).wait(1).to({rotation:12.6785,x:-46.8949,y:71.3837,startPosition:131},0).wait(1).to({rotation:12.7935,x:-46.9234,y:71.3998,startPosition:132},0).wait(1).to({rotation:12.9051,x:-46.9511,y:71.4155,startPosition:133},0).wait(1).to({rotation:13.0134,x:-46.9779,y:71.4308,startPosition:134},0).wait(1).to({rotation:13.1184,x:-47.004,y:71.4455,startPosition:135},0).wait(1).to({rotation:13.2201,x:-47.0292,y:71.4598,startPosition:136},0).wait(1).to({rotation:13.3184,x:-47.0536,y:71.4737,startPosition:137},0).wait(1).to({rotation:13.4136,x:-47.0772,y:71.4871,startPosition:138},0).wait(1).to({rotation:13.5055,x:-47.1,y:71.5,startPosition:139},0).to({rotation:14.9992,x:54.15,y:62.4,startPosition:170},31,cjs.Ease.cubicInOut).to({x:56.3,y:55.25,startPosition:211},41,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,rotation:29.9977,x:51.6,y:52.35,startPosition:324},113,cjs.Ease.quadInOut).to({regX:-1.1,regY:-4.5,rotation:14.9994,x:56.4,y:46.5,startPosition:418},94,cjs.Ease.quadInOut).to({regX:-1,scaleX:0.9999,scaleY:0.9999,rotation:29.9985,x:20.45,y:63.2,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// il_li
	this.instance_13 = new lib.il_li("synched",0);
	this.instance_13.setTransform(-13.55,-18.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({x:22.75,y:27.2,startPosition:31},31,cjs.Ease.quartInOut).wait(1).to({x:22.7533,y:27.1987,startPosition:32},0).wait(1).to({x:22.7575,y:27.197,startPosition:33},0).wait(1).to({x:22.7627,y:27.1949,startPosition:34},0).wait(1).to({x:22.7689,y:27.1925,startPosition:35},0).wait(1).to({x:22.776,y:27.1896,startPosition:36},0).wait(1).to({x:22.7841,y:27.1864,startPosition:37},0).wait(1).to({x:22.7933,y:27.1828,startPosition:38},0).wait(1).to({x:22.8035,y:27.1787,startPosition:39},0).wait(1).to({x:22.8147,y:27.1742,startPosition:40},0).wait(1).to({x:22.827,y:27.1693,startPosition:41},0).wait(1).to({x:22.8404,y:27.164,startPosition:42},0).wait(1).to({x:22.8549,y:27.1582,startPosition:43},0).wait(1).to({x:22.8705,y:27.152,startPosition:44},0).wait(1).to({x:22.8873,y:27.1453,startPosition:45},0).wait(1).to({x:22.9052,y:27.1382,startPosition:46},0).wait(1).to({x:22.9243,y:27.1306,startPosition:47},0).wait(1).to({x:22.9446,y:27.1225,startPosition:48},0).wait(1).to({x:22.9661,y:27.114,startPosition:49},0).wait(1).to({x:22.9888,y:27.1049,startPosition:50},0).wait(1).to({x:23.0128,y:27.0954,startPosition:51},0).wait(1).to({x:23.038,y:27.0853,startPosition:52},0).wait(1).to({x:23.0646,y:27.0748,startPosition:53},0).wait(1).to({x:23.0924,y:27.0637,startPosition:54},0).wait(1).to({x:23.1216,y:27.0521,startPosition:55},0).wait(1).to({x:23.1521,y:27.0399,startPosition:56},0).wait(1).to({x:23.1839,y:27.0272,startPosition:57},0).wait(1).to({x:23.2171,y:27.014,startPosition:58},0).wait(1).to({x:23.2517,y:27.0002,startPosition:59},0).wait(1).to({x:23.2877,y:26.9859,startPosition:60},0).wait(1).to({x:23.3251,y:26.971,startPosition:61},0).wait(1).to({x:23.364,y:26.9556,startPosition:62},0).wait(1).to({x:23.4042,y:26.9395,startPosition:63},0).wait(1).to({x:23.4459,y:26.9229,startPosition:64},0).wait(1).to({x:23.4891,y:26.9057,startPosition:65},0).wait(1).to({x:23.5337,y:26.888,startPosition:66},0).wait(1).to({x:23.5798,y:26.8696,startPosition:67},0).wait(1).to({x:23.6273,y:26.8507,startPosition:68},0).wait(1).to({x:23.6764,y:26.8312,startPosition:69},0).wait(1).to({x:23.7269,y:26.8111,startPosition:70},0).wait(1).to({x:23.7788,y:26.7904,startPosition:71},0).wait(1).to({x:23.8322,y:26.7691,startPosition:72},0).wait(1).to({x:23.8871,y:26.7473,startPosition:73},0).wait(1).to({x:23.9434,y:26.7248,startPosition:74},0).wait(1).to({x:24.0011,y:26.7019,startPosition:75},0).wait(1).to({x:24.0603,y:26.6783,startPosition:76},0).wait(1).to({x:24.1208,y:26.6542,startPosition:77},0).wait(1).to({x:24.1827,y:26.6296,startPosition:78},0).wait(1).to({x:24.2459,y:26.6044,startPosition:79},0).wait(1).to({x:24.3104,y:26.5787,startPosition:80},0).wait(1).to({x:24.3762,y:26.5525,startPosition:81},0).wait(1).to({x:24.4432,y:26.5258,startPosition:82},0).wait(1).to({x:24.5114,y:26.4987,startPosition:83},0).wait(1).to({x:24.5808,y:26.4711,startPosition:84},0).wait(1).to({x:24.6512,y:26.443,startPosition:85},0).wait(1).to({x:24.7226,y:26.4146,startPosition:86},0).wait(1).to({x:24.795,y:26.3858,startPosition:87},0).wait(1).to({x:24.8684,y:26.3566,startPosition:88},0).wait(1).to({x:24.9425,y:26.3271,startPosition:89},0).wait(1).to({x:25.0174,y:26.2972,startPosition:90},0).wait(1).to({x:25.093,y:26.2671,startPosition:91},0).wait(1).to({x:25.1692,y:26.2368,startPosition:92},0).wait(1).to({x:25.246,y:26.2062,startPosition:93},0).wait(1).to({x:25.3232,y:26.1755,startPosition:94},0).wait(1).to({x:25.4008,y:26.1446,startPosition:95},0).wait(1).to({x:25.4786,y:26.1136,startPosition:96},0).wait(1).to({x:25.5567,y:26.0825,startPosition:97},0).wait(1).to({x:25.6348,y:26.0514,startPosition:98},0).wait(1).to({x:25.713,y:26.0203,startPosition:99},0).wait(1).to({x:25.7911,y:25.9892,startPosition:100},0).wait(1).to({x:25.8691,y:25.9581,startPosition:101},0).wait(1).to({x:25.9469,y:25.9272,startPosition:102},0).wait(1).to({x:26.0243,y:25.8964,startPosition:103},0).wait(1).to({x:26.1013,y:25.8657,startPosition:104},0).wait(1).to({x:26.1778,y:25.8352,startPosition:105},0).wait(1).to({x:26.2538,y:25.805,startPosition:106},0).wait(1).to({x:26.3292,y:25.775,startPosition:107},0).wait(1).to({x:26.4038,y:25.7452,startPosition:108},0).wait(1).to({x:26.4777,y:25.7158,startPosition:109},0).wait(1).to({x:26.5508,y:25.6867,startPosition:110},0).wait(1).to({x:26.6229,y:25.658,startPosition:111},0).wait(1).to({x:26.6941,y:25.6296,startPosition:112},0).wait(1).to({x:26.7644,y:25.6017,startPosition:113},0).wait(1).to({x:26.8335,y:25.5742,startPosition:114},0).wait(1).to({x:26.9016,y:25.5471,startPosition:115},0).wait(1).to({x:26.9685,y:25.5204,startPosition:116},0).wait(1).to({x:27.0343,y:25.4942,startPosition:117},0).wait(1).to({x:27.0988,y:25.4685,startPosition:118},0).wait(1).to({x:27.1622,y:25.4433,startPosition:119},0).wait(1).to({x:27.2242,y:25.4186,startPosition:120},0).wait(1).to({x:27.285,y:25.3944,startPosition:121},0).wait(1).to({x:27.3445,y:25.3707,startPosition:122},0).wait(1).to({x:27.4026,y:25.3476,startPosition:123},0).wait(1).to({x:27.4594,y:25.3249,startPosition:124},0).wait(1).to({x:27.5149,y:25.3029,startPosition:125},0).wait(1).to({x:27.5691,y:25.2813,startPosition:126},0).wait(1).to({x:27.6218,y:25.2603,startPosition:127},0).wait(1).to({x:27.6732,y:25.2398,startPosition:128},0).wait(1).to({x:27.7233,y:25.2199,startPosition:129},0).wait(1).to({x:27.772,y:25.2005,startPosition:130},0).wait(1).to({x:27.8193,y:25.1817,startPosition:131},0).wait(1).to({x:27.8653,y:25.1633,startPosition:132},0).wait(1).to({x:27.91,y:25.1456,startPosition:133},0).wait(1).to({x:27.9533,y:25.1283,startPosition:134},0).wait(1).to({x:27.9952,y:25.1116,startPosition:135},0).wait(1).to({x:28.0359,y:25.0954,startPosition:136},0).wait(1).to({x:28.0752,y:25.0798,startPosition:137},0).wait(1).to({x:28.1132,y:25.0646,startPosition:138},0).wait(1).to({x:28.15,y:25.05,startPosition:139},0).to({x:28.75,y:24.8,startPosition:170},31,cjs.Ease.cubicInOut).to({x:22.35,y:11.4,startPosition:211},41,cjs.Ease.quartInOut).to({x:21.15,y:4.2,startPosition:324},113,cjs.Ease.quadInOut).to({x:22.35,y:11.4,startPosition:418},94,cjs.Ease.quadInOut).to({x:26.75,y:4.55,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// sh_y
	this.instance_14 = new lib.sh_y("synched",0);
	this.instance_14.setTransform(-27.6,256.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({x:-6.05,y:233.3,startPosition:31},31,cjs.Ease.quartInOut).to({startPosition:170},139,cjs.Ease.quadInOut).to({rotation:5.231,y:229,startPosition:211},41,cjs.Ease.quartInOut).to({rotation:7.7063,y:227.05,startPosition:324},113,cjs.Ease.quadInOut).to({rotation:0,x:-8.5,y:222.85,startPosition:418},94,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,rotation:-5.5138,x:5.3,y:239,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// sh_g
	this.instance_15 = new lib.sh_g("synched",0);
	this.instance_15.setTransform(-17.45,-18.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({x:3.65,y:23.3,startPosition:31},31,cjs.Ease.quartInOut).to({rotation:14.9992,x:1.8,y:26.3,startPosition:170},139,cjs.Ease.quadInOut).to({y:11.7,startPosition:211},41,cjs.Ease.quartInOut).to({y:9.3,startPosition:324},113,cjs.Ease.quadInOut).to({y:11.7,startPosition:418},94,cjs.Ease.quadInOut).to({x:16.75,y:5.75,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// sh_red
	this.instance_16 = new lib.sh_red("synched",0);
	this.instance_16.setTransform(344.8,245.15);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).to({rotation:14.9992,x:292.65,y:237.5,startPosition:31},31,cjs.Ease.quartInOut).to({rotation:6.7474,x:313.3,y:221.5,startPosition:170},139,cjs.Ease.quadInOut).to({rotation:6.7474,x:312.7,y:233.15,startPosition:211},41,cjs.Ease.quartInOut).to({x:313.4,y:229.55,startPosition:324},113,cjs.Ease.quadInOut).to({x:312.7,y:237.65,startPosition:418},94,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,rotation:-6.6859,x:302.75,y:231.15,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// sh_lt_b
	this.instance_17 = new lib.sh_ltb("synched",0);
	this.instance_17.setTransform(358.7,79.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).to({x:316.6,y:99.25,startPosition:31},31,cjs.Ease.quartInOut).to({x:319,y:83.9,startPosition:170},139,cjs.Ease.quadInOut).to({y:72.05,startPosition:211},41,cjs.Ease.quartInOut).to({x:322,y:69.65,startPosition:324},113,cjs.Ease.quadInOut).to({x:319,y:72.05,startPosition:418},94,cjs.Ease.quadInOut).to({rotation:-21.9594,x:293.2,y:19.4,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// sh_d_b
	this.instance_18 = new lib.sh_db("synched",0);
	this.instance_18.setTransform(124.4,-44.15);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).to({y:6,startPosition:31},31,cjs.Ease.quartInOut).to({rotation:4.9958,x:128.55,y:-1.65,startPosition:170},139,cjs.Ease.quadInOut).to({rotation:-4.4615,y:-0.65,startPosition:211},41,cjs.Ease.quartInOut).to({y:-2.45,startPosition:324},113,cjs.Ease.quadInOut).to({y:-0.65,startPosition:418},94,cjs.Ease.quadInOut).to({rotation:10.5375,x:115.5,y:-24.55,startPosition:440},22,cjs.Ease.quartInOut).wait(9));

	// txt3_bars
	this.instance_19 = new lib.Symbol2();
	this.instance_19.setTransform(152,86.35,1,1,0,0,0,122.2,21.9);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;

	this.instance_20 = new lib.CachedBmp_211();
	this.instance_20.setTransform(29.05,81.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_19}]},428).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).wait(8));
	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(428).to({_off:false},0).wait(1).to({regY:22,y:93.9,alpha:0.4491},0).wait(1).to({y:96.8,alpha:0.6049},0).wait(1).to({y:98.75,alpha:0.7092},0).wait(1).to({y:100.2,alpha:0.7863},0).wait(1).to({y:101.35,alpha:0.8454},0).wait(1).to({y:102.25,alpha:0.8917},0).wait(1).to({y:103,alpha:0.9276},0).wait(1).to({y:103.55,alpha:0.9551},0).wait(1).to({y:103.95,alpha:0.9753},0).wait(1).to({y:104.25,alpha:0.9893},0).wait(1).to({y:104.4,alpha:0.9973},0).wait(1).to({y:104.5,alpha:1},0).to({_off:true},1).wait(8));

	// txt3_meals
	this.instance_21 = new lib.Symbol3();
	this.instance_21.setTransform(222.7,87,1,1,0,0,0,52.1,11.8);
	this.instance_21.alpha = 0;
	this.instance_21._off = true;

	this.instance_22 = new lib.CachedBmp_212();
	this.instance_22.setTransform(170.6,93.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_21}]},425).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).wait(11));
	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(425).to({_off:false},0).wait(1).to({regX:52,x:222.6,y:94.45,alpha:0.4491},0).wait(1).to({y:97.35,alpha:0.6049},0).wait(1).to({y:99.3,alpha:0.7092},0).wait(1).to({y:100.75,alpha:0.7863},0).wait(1).to({y:101.9,alpha:0.8454},0).wait(1).to({y:102.8,alpha:0.8917},0).wait(1).to({y:103.55,alpha:0.9276},0).wait(1).to({y:104.1,alpha:0.9551},0).wait(1).to({y:104.5,alpha:0.9753},0).wait(1).to({y:104.8,alpha:0.9893},0).wait(1).to({y:104.95,alpha:0.9973},0).wait(1).to({y:105.05,alpha:1},0).to({_off:true},1).wait(11));

	// txt3_summer
	this.instance_23 = new lib.Symbol4();
	this.instance_23.setTransform(123.1,84.85,1,1,0,0,0,46,8.9);
	this.instance_23.alpha = 0;
	this.instance_23._off = true;

	this.instance_24 = new lib.CachedBmp_213();
	this.instance_24.setTransform(77.1,94,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_23}]},422).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).wait(14));
	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(422).to({_off:false},0).wait(1).to({regY:9,y:92.4,alpha:0.4491},0).wait(1).to({y:95.3,alpha:0.6049},0).wait(1).to({y:97.25,alpha:0.7092},0).wait(1).to({y:98.7,alpha:0.7863},0).wait(1).to({y:99.85,alpha:0.8454},0).wait(1).to({y:100.75,alpha:0.8917},0).wait(1).to({y:101.5,alpha:0.9276},0).wait(1).to({y:102.05,alpha:0.9551},0).wait(1).to({y:102.45,alpha:0.9753},0).wait(1).to({y:102.75,alpha:0.9893},0).wait(1).to({y:102.9,alpha:0.9973},0).wait(1).to({y:103,alpha:1},0).to({_off:true},1).wait(14));

	// txt3_free
	this.instance_25 = new lib.Symbol5();
	this.instance_25.setTransform(52.85,85,1,1,0,0,0,23.2,8.8);
	this.instance_25.alpha = 0;
	this.instance_25._off = true;

	this.instance_26 = new lib.CachedBmp_214();
	this.instance_26.setTransform(29.65,94.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_25}]},419).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_26}]},1).wait(17));
	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(419).to({_off:false},0).wait(1).to({y:92.45,alpha:0.4491},0).wait(1).to({y:95.35,alpha:0.6049},0).wait(1).to({y:97.3,alpha:0.7092},0).wait(1).to({y:98.75,alpha:0.7863},0).wait(1).to({y:99.9,alpha:0.8454},0).wait(1).to({y:100.8,alpha:0.8917},0).wait(1).to({y:101.55,alpha:0.9276},0).wait(1).to({y:102.1,alpha:0.9551},0).wait(1).to({y:102.5,alpha:0.9753},0).wait(1).to({y:102.8,alpha:0.9893},0).wait(1).to({y:102.95,alpha:0.9973},0).wait(1).to({y:103.05,alpha:1},0).to({_off:true},1).wait(17));

	// txt2_button
	this.instance_27 = new lib.txt2_button("synched",0);
	this.instance_27.setTransform(149.95,142.2);
	this.instance_27.alpha = 0;
	this.instance_27._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(434).to({_off:false},0).wait(1).to({y:150.2834,alpha:0.4887},0).wait(1).to({y:153.4662,alpha:0.6621},0).wait(1).to({y:155.6698,alpha:0.7801},0).wait(1).to({y:157.3545,alpha:0.869},0).wait(1).to({y:158.6962,alpha:0.9388},0).wait(1).to({y:159.7867,alpha:0.9949},0).wait(1).to({y:160.25,alpha:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1));

	// txt2_logos_v3
	this.instance_28 = new lib.txt2_logos_v3("synched",0);
	this.instance_28.setTransform(150,258.4);
	this.instance_28.alpha = 0;
	this.instance_28._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(254).to({_off:false},0).wait(1).to({regY:0.1,y:242.55,alpha:0.4491},0).wait(1).to({y:236.45,alpha:0.6049},0).wait(1).to({y:232.3,alpha:0.7092},0).wait(1).to({y:229.15,alpha:0.7863},0).wait(1).to({y:226.7,alpha:0.8454},0).wait(1).to({y:224.8,alpha:0.8917},0).wait(1).to({y:223.25,alpha:0.9276},0).wait(1).to({y:222.05,alpha:0.9551},0).wait(1).to({y:221.2,alpha:0.9753},0).wait(1).to({y:220.55,alpha:0.9893},0).wait(1).to({y:220.2,alpha:0.9973},0).wait(1).to({y:220.1,alpha:1},0).wait(1).to({regY:0,y:220.6},0).wait(182));

	// txt1_save
	this.instance_29 = new lib.txt_save("synched",0);
	this.instance_29.setTransform(146.45,124.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(128).to({startPosition:0},0).to({alpha:0},9).to({_off:true},1).wait(311));

	// txt2_v2
	this.instance_30 = new lib.txt2_v2("synched",0);
	this.instance_30.setTransform(149.2,97);
	this.instance_30.alpha = 0;
	this.instance_30._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(239).to({_off:false},0).wait(1).to({regX:1.5,x:150.7,y:104.45,alpha:0.4491},0).wait(1).to({y:107.35,alpha:0.6049},0).wait(1).to({y:109.3,alpha:0.7092},0).wait(1).to({y:110.75,alpha:0.7863},0).wait(1).to({y:111.9,alpha:0.8454},0).wait(1).to({y:112.8,alpha:0.8917},0).wait(1).to({y:113.55,alpha:0.9276},0).wait(1).to({y:114.1,alpha:0.9551},0).wait(1).to({y:114.5,alpha:0.9753},0).wait(1).to({y:114.8,alpha:0.9893},0).wait(1).to({y:114.95,alpha:0.9973},0).wait(1).to({y:115.05,alpha:1},0).wait(1).to({regX:0,x:149.2},0).wait(151).to({startPosition:0},0).wait(1).to({regX:1.5,x:150.7,y:115,alpha:0.9982},0).wait(1).to({y:114.9,alpha:0.9923},0).wait(1).to({y:114.8,alpha:0.9816},0).wait(1).to({y:114.55,alpha:0.9652},0).wait(1).to({y:114.3,alpha:0.9419},0).wait(1).to({y:113.85,alpha:0.9101},0).wait(1).to({y:113.35,alpha:0.8676},0).wait(1).to({y:112.65,alpha:0.8113},0).wait(1).to({y:111.75,alpha:0.7365},0).wait(1).to({y:110.6,alpha:0.6361},0).wait(1).to({y:109,alpha:0.4978},0).wait(1).to({y:106.85,alpha:0.2998},0).wait(1).to({y:103.6,alpha:0},0).to({_off:true},1).wait(32));

	// txt1
	this.instance_31 = new lib.title("synched",0);
	this.instance_31.setTransform(143.25,134.45);
	this.instance_31.alpha = 0;
	this.instance_31._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(137).to({_off:false},0).wait(1).to({regY:-0.1,y:134.35,alpha:0.1111},0).wait(1).to({alpha:0.2222},0).wait(1).to({alpha:0.3333},0).wait(1).to({alpha:0.4444},0).wait(1).to({alpha:0.5556},0).wait(1).to({alpha:0.6667},0).wait(1).to({alpha:0.7778},0).wait(1).to({alpha:0.8889},0).wait(1).to({alpha:1},0).wait(1).to({regY:0,y:134.45},0).wait(76).to({startPosition:0},0).wait(1).to({regY:-0.1,y:134.3,alpha:0.9982},0).wait(1).to({y:134.2,alpha:0.9923},0).wait(1).to({y:134.1,alpha:0.9816},0).wait(1).to({y:133.85,alpha:0.9652},0).wait(1).to({y:133.6,alpha:0.9419},0).wait(1).to({y:133.15,alpha:0.9101},0).wait(1).to({y:132.65,alpha:0.8676},0).wait(1).to({y:131.95,alpha:0.8113},0).wait(1).to({y:131.05,alpha:0.7365},0).wait(1).to({y:129.9,alpha:0.6361},0).wait(1).to({y:128.3,alpha:0.4978},0).wait(1).to({y:126.15,alpha:0.2998},0).wait(1).to({y:122.9,alpha:0},0).to({_off:true},1).wait(212));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#ECF8FD").s().p("A3aTiMAAAgnDMAu1AAAMAAAAnDg");
	this.shape.setTransform(150.075,124.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	// stageBackground
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("A4/1FMAx/AAAMAAAAqLMgx/AAAg");
	this.shape_1.setTransform(150,125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("A4/VGMAAAgqLMAx/AAAMAAAAqLg");
	this.shape_2.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(449));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(64.6,39.2,342.1,264.40000000000003);
// library properties:
lib.properties = {
	id: '51C29B3F566DCA459FEE44EC96F655BE',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/fsm_digital_300x250_v2_atlas_1.png", id:"fsm_digital_300x250_v2_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['51C29B3F566DCA459FEE44EC96F655BE'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;