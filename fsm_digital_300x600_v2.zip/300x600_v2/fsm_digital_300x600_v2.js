(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"fsm_digital_300x600_v2_atlas_1", frames: [[1232,0,521,286],[583,243,198,39],[1755,222,224,51],[783,243,100,38],[0,564,222,70],[651,435,529,97],[1903,471,132,74],[0,435,649,127],[1450,288,504,181],[583,0,647,241],[0,0,581,376],[1928,0,117,99],[1755,0,171,220],[1903,547,91,92],[800,534,156,122],[1375,471,192,166],[1928,101,115,90],[1761,471,140,139],[958,534,160,108],[1569,471,190,164],[651,534,147,132],[1182,435,191,169],[583,288,865,145]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_165 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_164 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_163 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_162 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_161 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_160 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_159 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_158 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_157 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_156 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_155 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_154 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_153 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_152 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_151 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_150 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_149 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_148 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_147 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_146 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_145 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_144 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Image_2 = function() {
	this.initialize(ss["fsm_digital_300x600_v2_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_save = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt_save
	this.instance = new lib.CachedBmp_165();
	this.instance.setTransform(-105.75,-58.1,0.4061,0.4061);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-105.7,-58.1,211.60000000000002,116.2);


(lib.t3summer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_summer
	this.instance = new lib.CachedBmp_164();
	this.instance.setTransform(-49.4,-9.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-49.4,-9.6,99,19.5);


(lib.t3meals = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_meals
	this.instance = new lib.CachedBmp_163();
	this.instance.setTransform(-56,-12.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56,-12.7,112,25.5);


(lib.t3free = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_free
	this.instance = new lib.CachedBmp_162();
	this.instance.setTransform(-25,-9.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-25,-9.5,50,19);


(lib.t3button = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2_button
	this.instance = new lib.CachedBmp_161();
	this.instance.setTransform(-55.45,-17.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55.4,-17.5,111,35);


(lib.t3bars = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_bars
	this.instance = new lib.CachedBmp_160();
	this.instance.setTransform(-132.2,-24.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-132.2,-24.3,264.5,48.5);


(lib.t2logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2_logos
	this.instance = new lib.CachedBmp_159();
	this.instance.setTransform(42.45,-18.65,0.5,0.5);

	this.instance_1 = new lib.Image_2();
	this.instance_1.setTransform(-122,-12.7,0.1698,0.1698);

	this.instance_2 = new lib.CachedBmp_158();
	this.instance_2.setTransform(-162.15,-31.7,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-162.1,-31.7,324.5,63.5);


(lib.t2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2
	this.instance = new lib.CachedBmp_157();
	this.instance.setTransform(-128.45,-41.9,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_156();
	this.instance_1.setTransform(-161.7,-60.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-161.7,-60.1,323.5,120.5);


(lib.t1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt1
	this.instance = new lib.CachedBmp_155();
	this.instance.setTransform(-145.25,-93.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-145.2,-93.9,290.5,188);


(lib.Symbol15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_dark_blue
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#224EA2").s().p("AGUIuQiAgfhPhgIguhAQgcgmgXgUQg0gthVgQQgvgJhtgDQh1gEhUgNQhtgShVgmQhhgrhFhHQhLhMgaheQgLgqgEg5IgCgvQgBgcAFgSQADgKAKgLIARgTQAeglARgRQAygwBCgkQB7hCCYgKQB6gHCQAdQBsAWCXAzQDJBDCBBDQCsBaBsB3QBzCAATCGQATB6hAB0QhAB1hxAyQhHAfhNAAQguAAgxgLg");
	this.shape.setTransform(0.026,0.0312);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(146).to({_off:true},1).wait(26).to({_off:false},0).wait(104).to({_off:true},1).wait(22).to({_off:false},0).wait(61).to({_off:true},1).wait(59).to({_off:false},0).wait(11).to({_off:true},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-87.3,-56.9,174.7,113.9);


(lib.Symbol14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_light_blue
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#568DCA").s().p("ACXK+QgpgChMgOQgigHgRgEQgdgIgVgLQgkgTgxg1QgYgagMgSQgRgagEgZQgFgjAUgwQARgpBaiEQBIhoAIhMQAHg4gWg6QgWg4gqgpQgwgvhDgWQghgLghgDQgSgCgcgHQgjgJgMgCIglgGQg2gJgYgFQgrgKgggQQgugXgdgoQgfgrAEgvQADggAUgeQASgcAegUQApgdBTgXQC+g1DFgSQBogIBdAAQAZABALABQATADAQAGQAPAHAZAFIAoAKQBVAXBLAqQAgASALARQAKAOAFAVQACANACAaIAYHGQACAiANASQAHAKAIASIANAdQAHAMAPAUQARAWAGAJQAmA+ADBDQADBAgeA8QgQAigdAiQgPASgOAMQgFAFgIAFIgPAIQgQAKgXAUIgmAhIhOA8Qg/AwgoAPQgqAPg2AAIgTAAg");
	this.shape.setTransform(0.0161,-0.005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(146).to({_off:true},1).wait(26).to({_off:false},0).wait(104).to({_off:true},1).wait(22).to({_off:false},0).wait(61).to({_off:true},1).wait(59).to({_off:false},0).wait(11).to({_off:true},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-65.3,-70.2,130.7,140.4);


(lib.Symbol13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_red
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EA6241").s().p("AAANeQgOgIgagXQh/htiehAQhMgfhWgTQgpgKgqgFQgQgDhOgFQg5gDgjgLQgzgPgjgkQgZgagVgpQgWgsgJg7QgUiPBJiAQBUiVDHhmQAYgMAogSIBBgcIAWgNQALgIATgHIAggLQBYgfA2gfQAXgOANgJQAQgNANgPQASgWANgTQAggwgFgoQgDgYgWglQgZgqgGgRQgMglAOgoQANgnAjgfQAugoBXgZQBngeBrgBQAbgBBBAHQA6AFAigCQAogDAwAMQAcAHA1ATQBVAfBCAqQCHBTAnBxIAIAaQARBIgiA3QgNAVgYAXIgrAnQhYBSgzC1IgnCUQgZBVgdA3QgXAtgrA5IhJBhQg4BMhpCfQhhCGhjA+QgaARgUACIgFAAQgUAAgWgNg");
	this.shape.setTransform(0.0058,0.0103);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(146).to({_off:true},1).wait(26).to({_off:false},0).wait(104).to({_off:true},1).wait(22).to({_off:false},0).wait(61).to({_off:true},1).wait(59).to({_off:false},0).wait(11).to({_off:true},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-92.4,-87.5,184.8,175);


(lib.Symbol12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_green
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AmdGbQg7gagPg7QgKgoAGg5QAKhCADghQADgfgBgtIAAhKIAAgXQAGiSBEhlQAlg4A3gjQA5gmA/gHQAwgFBMAOQBcAQAeABIA1ABQAbACAYALQA/AdAwAbQDUB7ALCQIABAPQAAChj8CIQjUBxlJA+QgVAEgTAAQgnAAgkgRg");
	this.shape.setTransform(0.0375,0.0047);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(146).to({_off:true},1).wait(26).to({_off:false},0).wait(104).to({_off:true},1).wait(22).to({_off:false},0).wait(61).to({_off:true},1).wait(59).to({_off:false},0).wait(11).to({_off:true},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-49.4,-42.8,98.9,85.6);


(lib.Symbol10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_yellow
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FCB11D").s().p("ACAINIoygaQhAgDgfgGQg0gKgjgZQgrgegXg4Qgag+AEhLQADg1AahhQANgtAFgYQALgpAAgbQABgSgGgQIgMgcQgPglAJg1QAHglAPgjQAPgkAUgaQAhgqAvgbQAegRA2gTQDihOCCgFQC/gIBvB6QASATBUB5QA9BYAzAcQAYAMAkAJIA+AOQBKASAhAvQAlAzAKBnQAHBDgDCCQgBA/gKAiQgRA2grAgQgiAZguAJQhgATh2ACIgVABQhEAAh6gGg");
	this.shape.setTransform(0.0118,0.0075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(146).to({_off:true},1).wait(26).to({_off:false},0).wait(104).to({_off:true},1).wait(22).to({_off:false},0).wait(61).to({_off:true},1).wait(59).to({_off:false},0).wait(11).to({_off:true},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.5,-53,141.1,106.1);


(lib.Symbol9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus
	this.instance = new lib.CachedBmp_154();
	this.instance.setTransform(-29.3,-24.75,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(146).to({_off:true},1).wait(26).to({_off:false},0).wait(104).to({_off:true},1).wait(22).to({_off:false},0).wait(61).to({_off:true},1).wait(59).to({_off:false},0).wait(11).to({_off:true},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.3,-24.7,58.5,49.5);


(lib.Symbol7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_carrot
	this.instance = new lib.CachedBmp_153();
	this.instance.setTransform(-42.85,-55.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(146).to({_off:true},1).wait(26).to({_off:false},0).wait(104).to({_off:true},1).wait(22).to({_off:false},0).wait(61).to({_off:true},1).wait(59).to({_off:false},0).wait(11).to({_off:true},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.8,-55,85.5,110);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_ritz
	this.instance = new lib.CachedBmp_152();
	this.instance.setTransform(-22.65,-22.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(146).to({_off:true},1).wait(26).to({_off:false},0).wait(104).to({_off:true},1).wait(22).to({_off:false},0).wait(61).to({_off:true},1).wait(59).to({_off:false},0).wait(11).to({_off:true},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22.6,-22.8,45.5,46);


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_banana
	this.instance = new lib.CachedBmp_151();
	this.instance.setTransform(-38.85,-30.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(146).to({_off:true},1).wait(26).to({_off:false},0).wait(104).to({_off:true},1).wait(22).to({_off:false},0).wait(61).to({_off:true},1).wait(59).to({_off:false},0).wait(11).to({_off:true},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38.8,-30.4,78,61);


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_milk
	this.instance = new lib.CachedBmp_150();
	this.instance.setTransform(-47.9,-41.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(146).to({_off:true},1).wait(26).to({_off:false},0).wait(104).to({_off:true},1).wait(22).to({_off:false},0).wait(61).to({_off:true},1).wait(59).to({_off:false},0).wait(11).to({_off:true},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.9,-41.6,96,83);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_orange
	this.instance = new lib.CachedBmp_149();
	this.instance.setTransform(-28.6,-22.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(146).to({_off:true},1).wait(26).to({_off:false},0).wait(104).to({_off:true},1).wait(22).to({_off:false},0).wait(61).to({_off:true},1).wait(59).to({_off:false},0).wait(11).to({_off:true},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-28.6,-22.4,57.5,45);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_apple
	this.instance = new lib.CachedBmp_148();
	this.instance.setTransform(-35.05,-34.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(146).to({_off:true},1).wait(26).to({_off:false},0).wait(104).to({_off:true},1).wait(22).to({_off:false},0).wait(61).to({_off:true},1).wait(59).to({_off:false},0).wait(11).to({_off:true},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-35,-34.6,70,69.5);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_apple_slice
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#224EA2").s().p("AAKDWQg/glgegtQghgvAGg8QAFhBAag2QAZg3AvgiQAzgmA4AHQAJACAAAJQAFAGgDAHIgeBIQgPAigSASQgHAIgRANIgOAJQgJAHgBAFQgBAGAHAJIAOAKQAMALAUANQAKAGgFALQgcBGgMBMIADACQALAGgFAMQgEAIgGAAQgDAAgDgCgAgViLQgpAtgRBGQgJAnABAcQAAAkARAcQAVAlAtAfQALhFAZhBQgngagOgVQgJgPALgQQAGgJARgPQAbgVAFgGQALgMALgVIAghHQhBACguAzg");
	this.shape.setTransform(2.0881,-1.134);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgUDKQgMgBgPgMQg0gsgDhlQgDhsAwhDQAcgnArgSQAXgKAXgDIABAAQAVgBAVAGIgZgDQALACAEAGQACAEAAAJQgBCuhBCfQgUAvgaAAIgDAAg");
	this.shape_1.setTransform(-3.0369,2.5762);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape}]},146).to({state:[]},1).to({state:[{t:this.shape_1},{t:this.shape}]},26).to({state:[{t:this.shape_1},{t:this.shape}]},104).to({state:[]},1).to({state:[{t:this.shape_1},{t:this.shape}]},22).to({state:[{t:this.shape_1},{t:this.shape}]},61).to({state:[]},1).to({state:[{t:this.shape_1},{t:this.shape}]},59).to({state:[{t:this.shape_1},{t:this.shape}]},11).to({state:[]},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.3,-22.7,26.6,45.5);


(lib.ill_money_r = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ill_money_r
	this.instance = new lib.CachedBmp_147();
	this.instance.setTransform(-26.75,-17.85,0.334,0.334);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.7,-17.8,53.4,36);


(lib.ill_money_g2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ill_money_g2
	this.instance = new lib.CachedBmp_146();
	this.instance.setTransform(-29.45,-25.3,0.3118,0.3118);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.4,-25.3,59.2,51.2);


(lib.ill_money_g1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ill_money_g1
	this.instance = new lib.CachedBmp_145();
	this.instance.setTransform(-27.55,-24.5,0.3754,0.3754);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.5,-24.5,55.2,49.6);


(lib.ill_money_b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ill_money_b
	this.instance = new lib.CachedBmp_144();
	this.instance.setTransform(-29.45,-25.75,0.3077,0.3077);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.4,-25.7,58.7,52);


(lib.Path_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AkWJKQgcgRgPgcQgPgbgGgnQgEgYgBguIgMnJIgEiyQgGhdgCgxQgEhXAOg1QALgqAigXQAfgUAugCQA7gCA0AmQAWAQBABDQBPBSBmA2QAYANAyAWQArAVAbATQAkAaAXAfQAaAjAEAmQADAkgOAqQgKAbgYAtIh+DtQgdA1gPAaQgaArgYAgQgwA8hAAsQhBArhKAXIglANQgYAKgNADQgHACgIAAQgWAAgXgOg");
	this.shape.setTransform(37.2646,59.9518);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0,0,74.5,119.9), null);


(lib.Path_19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAuA9QgHgEgIgIIgOgOIgzgzIgOgOQgJgIgDgIQgCgFAEgGQAEgHAGADQAIAEAIAIIAPAPIAzAzQAWAWAEAIQAEAHgGAGQgDADgEAAQgCAAgDgCg");
	this.shape.setTransform(6.1819,6.2868);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_19, new cjs.Rectangle(0,0,12.4,12.6), null);


(lib.Path_18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AA7BMIhlhkQgcgbgFgHQgGgHAGgJQAFgIAIAGQAPALAUAVIAhAiIBFBFQAIAIgIAIQgEAFgEAAQgEAAgEgEg");
	this.shape.setTransform(7.875,7.9698);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_18, new cjs.Rectangle(0,0,15.8,16), null);


(lib.Path_17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("ABABSIhIhJIglgkQgVgWgNgRQgFgGAFgIQAGgIAHAGQARAOAVAWIAkAnIBHBKQAHAHgHAIQgEADgDAAQgEAAgEgDg");
	this.shape.setTransform(8.231,8.5339);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_17, new cjs.Rectangle(0,0,16.5,17.1), null);


(lib.Path_16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAnA6QgQgWgcgfIgZgXQgRgOgHgLQgEgFADgIQAEgIAHAEQAOAHAQAQIAYAbQAVAVAYAfQAGAIgIAIQgDAEgEAAQgDAAgEgEg");
	this.shape.setTransform(5.7267,6.2049);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_16, new cjs.Rectangle(0,0,11.5,12.5), null);


(lib.Path_15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAhBAQgTgggXggQgdgggMgTQgEgGAFgIQAFgIAHAGQAMAKAOARIAWAeQAWAfASAhQAGAJgJAFQgEACgDAAQgEAAgEgGg");
	this.shape.setTransform(5.2977,7.0223);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_15, new cjs.Rectangle(0,0,10.6,14.1), null);


(lib.Path_14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AA2BTQgZgggjgsQgrgwgUgaQgEgGAFgIQAGgIAGAGQAfAdAiAsQARAUArA6QAGAIgHAIQgEADgDAAQgEAAgDgEg");
	this.shape.setTransform(7.1622,8.6472);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_14, new cjs.Rectangle(0,0,14.4,17.4), null);


(lib.Path_13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAsA/QgWgVgcghIgxg4QgHgHAHgHQAIgHAGAHIAyA1QAeAfASAXQAFAHgGAIQgDAEgDAAQgDAAgDgCg");
	this.shape.setTransform(5.8626,6.5161);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_13, new cjs.Rectangle(0,0,11.8,13.1), null);


(lib.Path_12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAtBTQgVgigfgsIg3hLQgGgHAHgHQAGgIAHAIQAzA5A9BjQAFAJgJAGQgDACgDAAQgFAAgEgGg");
	this.shape.setTransform(6.5783,8.8668);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_12, new cjs.Rectangle(0,0,13.2,17.8), null);


(lib.Path_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("ABABgIhGhbIglgsIgTgWQgMgNgEgLQgCgFAEgFQAEgGAFADQALAHAMAOIAVAZIAjAtQAiAqAaAqIAAAAQAFACACAFQACAEgBAEQgBAGgGACIgCAAIgBAAQgDAAgDgEg");
	this.shape.setTransform(7.9833,9.9998);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9, new cjs.Rectangle(0,0,16,20), null);


(lib.Path_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AA3BfQglg2hWh5QgGgHAHgIQAHgHAGAIQA5BKBDBkQAFAIgHAIQgEADgDAAQgDAAgDgEg");
	this.shape.setTransform(7.1953,9.8818);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_8, new cjs.Rectangle(0,0,14.4,19.9), null);


(lib.Path_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AAcAzQgdgrgpgsQgGgGAGgIQAGgIAGAGQAoAoAhAwQAGAIgHAIQgEAEgDAAQgEAAgDgFg");
	this.shape.setTransform(4.5645,5.5356);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6, new cjs.Rectangle(0,0,9.2,11.1), null);


(lib.Path_3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2DB6A8").s().p("AA6BXQgmgogfgnIghgoIgQgUQgJgMgFgKQgEgIAHgFQAHgFAGAGQAIAIAJAMIAQAVQANATARAVQAhAnAjAmQAHAHgHAIQgEADgEAAQgDAAgEgDg");
	this.shape_1.setTransform(7.6462,9.0365);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3_1, new cjs.Rectangle(0,0,15.3,18.1), null);


(lib.Symbol11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_green2
	this.instance = new lib.Path_3();
	this.instance.setTransform(-0.05,0.05,1,1,0,0,0,37.2,60);
	this.instance.alpha = 0.9492;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(146).to({_off:true},1).wait(26).to({_off:false},0).wait(104).to({_off:true},1).wait(22).to({_off:false},0).wait(61).to({_off:true},1).wait(59).to({_off:false},0).wait(11).to({_off:true},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-37.2,-59.9,74.5,119.9);


(lib.Symbol8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_lines
	this.instance = new lib.Path_3_1();
	this.instance.setTransform(-28.7,41.65,1,1,0,0,0,7.7,9);
	this.instance.compositeOperation = "multiply";

	this.instance_1 = new lib.Path_6();
	this.instance_1.setTransform(-11,41.1,1,1,0,0,0,4.5,5.5);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_8();
	this.instance_2.setTransform(-27.05,2.95,1,1,0,0,0,7.2,9.9);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_9();
	this.instance_3.setTransform(-2.6,26.25,1,1,0,0,0,8,10);
	this.instance_3.compositeOperation = "multiply";

	this.instance_4 = new lib.Path_12();
	this.instance_4.setTransform(-15.5,-8.6,1,1,0,0,0,6.5,8.8);
	this.instance_4.compositeOperation = "multiply";

	this.instance_5 = new lib.Path_13();
	this.instance_5.setTransform(4.6,9.8,1,1,0,0,0,5.9,6.5);
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.Path_14();
	this.instance_6.setTransform(-20.35,-32.75,1,1,0,0,0,7.2,8.7);
	this.instance_6.compositeOperation = "multiply";

	this.instance_7 = new lib.Path_15();
	this.instance_7.setTransform(-3.65,-16.2,1,1,0,0,0,5.3,7);
	this.instance_7.compositeOperation = "multiply";

	this.instance_8 = new lib.Path_16();
	this.instance_8.setTransform(17.75,1.8,1,1,0,0,0,5.7,6.2);
	this.instance_8.compositeOperation = "multiply";

	this.instance_9 = new lib.Path_17();
	this.instance_9.setTransform(-7.85,-42.2,1,1,0,0,0,8.2,8.5);
	this.instance_9.compositeOperation = "multiply";

	this.instance_10 = new lib.Path_18();
	this.instance_10.setTransform(12.2,-22.4,1,1,0,0,0,7.9,8);
	this.instance_10.compositeOperation = "multiply";

	this.instance_11 = new lib.Path_19();
	this.instance_11.setTransform(30.25,-5.15,1,1,0,0,0,6.2,6.2);
	this.instance_11.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},146).to({state:[]},1).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},26).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},104).to({state:[]},1).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},22).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},61).to({state:[]},1).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},59).to({state:[{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},11).to({state:[]},1).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.4,-50.7,72.8,101.4);


// stage content:
(lib.fsm_digital_300x600_v2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [448];
	// timeline functions:
	this.frame_448 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(448).call(this.frame_448).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvgEgXRAuuMAujAAAMAAAhdbMgujAAAg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	// Symbol_1
	this.instance = new lib.Symbol1("synched",0);
	this.instance.setTransform(325.05,-15.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:-5.9557,x:277.85,y:7.35,startPosition:28},28,cjs.Ease.quartInOut).to({startPosition:28},110,cjs.Ease.quadInOut).to({rotation:-20.2425,x:275.05,y:9.45,startPosition:73},29,cjs.Ease.quadInOut).to({x:277.05},74,cjs.Ease.quartInOut).to({rotation:0,x:279.05,y:12.7,startPosition:173},29,cjs.Ease.quartInOut).to({rotation:-14.9992,x:281.25,y:21.15,startPosition:300},105,cjs.Ease.quadInOut).to({x:276.05,y:18.65,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// Symbol_2
	this.instance_1 = new lib.Symbol2("synched",0);
	this.instance_1.setTransform(219.95,-44.15);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({rotation:-2.4102,x:199,y:31.65,startPosition:28},28,cjs.Ease.quartInOut).to({x:201,y:33.65},110,cjs.Ease.quadInOut).to({rotation:-8.1935,x:199.7,y:35.15,startPosition:73},29,cjs.Ease.quadInOut).to({x:201.7,y:37.15},74,cjs.Ease.quartInOut).to({rotation:0,x:198.7,y:49.15,startPosition:173},29,cjs.Ease.quartInOut).to({rotation:14.9992,x:207.05,startPosition:300},105,cjs.Ease.quadInOut).to({x:201.7,y:50.15,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// Symbol_3
	this.instance_2 = new lib.Symbol3("synched",0);
	this.instance_2.setTransform(340.4,156.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({rotation:4.4125,x:342.9,y:140.25,startPosition:28},28,cjs.Ease.quartInOut).to({startPosition:28},110,cjs.Ease.quadInOut).to({rotation:14.9992,x:209.5,y:163.05,startPosition:73},29,cjs.Ease.quadInOut).to({x:212.5},74,cjs.Ease.quartInOut).to({rotation:0,x:213.5,y:180.05,startPosition:173},29,cjs.Ease.quartInOut).to({rotation:14.9992,y:178.05,startPosition:300},105,cjs.Ease.quadInOut).to({x:217.5,y:183.05,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// Symbol_4
	this.instance_3 = new lib.Symbol4("synched",0);
	this.instance_3.setTransform(372.5,517.15);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({rotation:4.4125,x:363.55,y:417.3,startPosition:28},28,cjs.Ease.quartInOut).to({startPosition:28},110,cjs.Ease.quadInOut).to({rotation:14.9992,x:217.55,y:477.15,startPosition:73},29,cjs.Ease.quadInOut).to({x:215.55,y:480.15},74,cjs.Ease.quartInOut).to({rotation:0,x:217.85,y:415.15,startPosition:173},29,cjs.Ease.quartInOut).to({rotation:-14.9992,y:411.25,startPosition:300},105,cjs.Ease.quadInOut).to({rotation:0,x:215.85,y:428.15,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// Symbol_5
	this.instance_4 = new lib.Symbol5("synched",0);
	this.instance_4.setTransform(81.75,636.25);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({rotation:-4.4125,x:-20.2,y:612,startPosition:28},28,cjs.Ease.quartInOut).to({startPosition:28},110,cjs.Ease.quadInOut).to({rotation:-14.9992,x:107.75,y:521.3,startPosition:73},29,cjs.Ease.quadInOut).to({y:518.3},74,cjs.Ease.quartInOut).to({x:124.7,y:481.3,startPosition:173},29,cjs.Ease.quartInOut).to({regY:0.1,rotation:-14.9994,x:118.25,y:479.65,startPosition:300},105,cjs.Ease.quadInOut).to({regY:0,rotation:-14.9992,x:133.7,y:488.3,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// Symbol_6
	this.instance_5 = new lib.Symbol6("synched",0);
	this.instance_5.setTransform(-45.15,209.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:-38.7,y:208.45,startPosition:28},28,cjs.Ease.quartInOut).to({startPosition:28},110,cjs.Ease.quadInOut).to({regX:0.1,x:29.8,y:219.45,startPosition:73},29,cjs.Ease.quadInOut).to({regX:0.2,rotation:29.9992,y:219.5},74,cjs.Ease.quartInOut).to({regX:0,rotation:0,x:46.3,y:210.3,startPosition:173},29,cjs.Ease.quartInOut).to({rotation:-14.9992,startPosition:300},105,cjs.Ease.quadInOut).to({rotation:14.9992,x:46.25,y:208.3,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// Symbol_7
	this.instance_6 = new lib.Symbol7("synched",0);
	this.instance_6.setTransform(-35.7,85.25);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({rotation:4.4125,x:-55.9,y:89.6,startPosition:28},28,cjs.Ease.quartInOut).to({startPosition:28},110,cjs.Ease.quadInOut).to({rotation:14.9992,x:111.05,y:129.05,startPosition:73},29,cjs.Ease.quadInOut).to({y:126.05},74,cjs.Ease.quartInOut).to({rotation:0,x:135.3,y:147.85,startPosition:173},29,cjs.Ease.quartInOut).to({rotation:-14.9992,x:132.3,startPosition:300},105,cjs.Ease.quadInOut).to({x:130.3,y:142.85,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// Symbol_8
	this.instance_7 = new lib.Symbol8("synched",0);
	this.instance_7.setTransform(-36.4,135.95);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({rotation:-4.4125,x:25.95,y:113.75,startPosition:28},28,cjs.Ease.quartInOut).to({startPosition:28},110,cjs.Ease.quadInOut).to({rotation:-14.9992,x:27.35,y:117.95,startPosition:73},29,cjs.Ease.quadInOut).to({startPosition:73},74,cjs.Ease.quartInOut).to({rotation:-8.4763,x:30.9,y:102.05,startPosition:173},29,cjs.Ease.quartInOut).to({x:34.85,startPosition:300},105,cjs.Ease.quadInOut).to({rotation:6.5222,x:27.65,y:90.05,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// Symbol_9
	this.instance_8 = new lib.Symbol9("synched",0);
	this.instance_8.setTransform(-58.95,456.25);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({rotation:2.0515,x:69.85,y:466.9,startPosition:28},28,cjs.Ease.quartInOut).to({y:472.9},110,cjs.Ease.quadInOut).to({rotation:6.9746,x:43.55,y:444.15,startPosition:73},29,cjs.Ease.quadInOut).to({regX:0.1,regY:0.1,rotation:-8.024,x:45.65,y:446.3},74,cjs.Ease.quartInOut).to({regX:0,regY:0,rotation:0,x:66.55,y:402.5,startPosition:173},29,cjs.Ease.quartInOut).to({rotation:14.9992,x:85.5,startPosition:300},105,cjs.Ease.quadInOut).to({x:66.5,y:408.5,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// Symbol_10
	this.instance_9 = new lib.Symbol10("synched",0);
	this.instance_9.setTransform(6.3,605.75);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({rotation:-1.9745,x:-0.05,y:580.6,startPosition:28},28,cjs.Ease.quartInOut).to({x:-6.2},110,cjs.Ease.quadInOut).to({rotation:-6.7104,x:21.9,y:582,startPosition:73},29,cjs.Ease.quadInOut).to({startPosition:73},74,cjs.Ease.quartInOut).to({regY:0.1,rotation:83.6951,x:-30.9,y:515,startPosition:173},29,cjs.Ease.quartInOut).to({rotation:90.4127,x:-30,y:505,startPosition:300},105,cjs.Ease.quadInOut).to({regX:-0.1,rotation:98.6939,x:-16.9,y:499.95,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// Symbol_11
	this.instance_10 = new lib.Symbol11("synched",0);
	this.instance_10.setTransform(-26.95,371.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({rotation:2.0497,x:0.25,y:416.55,startPosition:28},28,cjs.Ease.quartInOut).to({startPosition:28},110,cjs.Ease.quadInOut).to({rotation:6.9676,x:1,y:372.5,startPosition:73},29,cjs.Ease.quadInOut).to({rotation:6.9676},74,cjs.Ease.quartInOut).to({rotation:14.9992,x:-16.95,y:371.5,startPosition:173},29,cjs.Ease.quartInOut).to({rotation:29.9977,y:377.5,startPosition:300},105,cjs.Ease.quadInOut).to({rotation:14.9992,x:-15.75,y:357.1,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// Symbol_12
	this.instance_11 = new lib.Symbol12("synched",0);
	this.instance_11.setTransform(-34,64.05);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({rotation:-4.4125,x:3.9,y:69.15,startPosition:28},28,cjs.Ease.quartInOut).to({startPosition:28},110,cjs.Ease.quadInOut).to({rotation:-14.9992,x:6,y:67.75,startPosition:73},29,cjs.Ease.quadInOut).to({startPosition:73},74,cjs.Ease.quartInOut).to({rotation:-8.4763,x:1,y:85.1,startPosition:173},29,cjs.Ease.quartInOut).to({rotation:6.5222,x:0.95,y:103.1,startPosition:300},105,cjs.Ease.quadInOut).to({x:3.7,y:71.1,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// Symbol_13
	this.instance_12 = new lib.Symbol13("synched",0);
	this.instance_12.setTransform(333.9,602);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({x:291.35,y:570.6,startPosition:28},28,cjs.Ease.quartInOut).to({startPosition:28},110,cjs.Ease.quadInOut).to({x:294.9,y:567.05,startPosition:73},29,cjs.Ease.quadInOut).to({startPosition:73},74,cjs.Ease.quartInOut).to({x:326.2,y:465.2,startPosition:173},29,cjs.Ease.quartInOut).to({rotation:-5.9663,x:334.55,startPosition:300},105,cjs.Ease.quadInOut).to({rotation:-9.2045,x:329.75,y:461.2,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// Symbol_14
	this.instance_13 = new lib.Symbol14("synched",0);
	this.instance_13.setTransform(344.85,129.75);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).to({rotation:-1.9019,x:329.9,y:146.15,startPosition:28},28,cjs.Ease.quartInOut).to({startPosition:28},110,cjs.Ease.quadInOut).to({rotation:-6.4658,x:291.9,y:148.25,startPosition:73},29,cjs.Ease.quadInOut).to({startPosition:73},74,cjs.Ease.quartInOut).to({rotation:0,x:289.9,y:163,startPosition:173},29,cjs.Ease.quartInOut).to({rotation:14.9992,startPosition:300},105,cjs.Ease.quadInOut).to({rotation:-8.9672,x:295.9,y:157,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// Symbol_15
	this.instance_14 = new lib.Symbol15("synched",0);
	this.instance_14.setTransform(57.7,-45.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_14).to({rotation:-1.608,x:59.85,y:-20.65,startPosition:28},28,cjs.Ease.quartInOut).to({startPosition:28},110,cjs.Ease.quadInOut).to({rotation:-5.4654,x:57.7,y:-17.85,startPosition:73},29,cjs.Ease.quadInOut).to({startPosition:73},74,cjs.Ease.quartInOut).to({rotation:8.7513,x:63.7,startPosition:173},29,cjs.Ease.quartInOut).to({regX:0.1,regY:-0.1,rotation:1.7987,x:71.85,y:-0.1,startPosition:300},105,cjs.Ease.quadInOut).to({regY:0,rotation:3.2584,x:74.8,y:-14.85,startPosition:421},62,cjs.Ease.quadInOut).wait(12));

	// i_m_b
	this.instance_15 = new lib.ill_money_b("synched",0);
	this.instance_15.setTransform(119.1,-51.6,1.625,1.625,0,0,0,-0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).to({x:210.3,y:149.75},28,cjs.Ease.cubicInOut).to({rotation:14.9989,x:213.3,y:146.7},86,cjs.Ease.cubicInOut).to({rotation:0,x:143.9,y:-53.4},24,cjs.Ease.cubicInOut).to({_off:true},3).wait(308));

	// i_m_r
	this.instance_16 = new lib.ill_money_r("synched",0);
	this.instance_16.setTransform(174.25,631.75,1.4971,1.4971,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_16).to({rotation:-59.9994,x:151.6,y:559},28,cjs.Ease.cubicInOut).to({rotation:-45,x:153.6,y:552.75},86,cjs.Ease.cubicInOut).to({rotation:-59.9994,x:150.6,y:553.05},24,cjs.Ease.cubicInOut).to({_off:true},3).wait(308));

	// i_m_g2
	this.instance_17 = new lib.ill_money_g2("synched",0);
	this.instance_17.setTransform(-59,456.2,1.3629,1.3629,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).to({regX:0.2,regY:0.3,scaleX:1.6034,scaleY:1.6034,rotation:-14.9992,x:183.5,y:448.45},28,cjs.Ease.cubicInOut).to({x:186.5,y:446.45},86,cjs.Ease.cubicInOut).to({x:373,y:426.45},24,cjs.Ease.cubicInOut).to({_off:true},3).wait(308));

	// i_m_g1
	this.instance_18 = new lib.ill_money_g1("synched",0);
	this.instance_18.setTransform(360.6,232.2,1.332,1.332,0,0,0,0.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).to({x:92.55,y:158.95},28,cjs.Ease.cubicInOut).to({x:93.55,y:164.95},86,cjs.Ease.cubicInOut).to({x:363,y:191.5},24,cjs.Ease.cubicInOut).to({_off:true},3).wait(308));

	// t3_bars
	this.instance_19 = new lib.t3bars("synched",0);
	this.instance_19.setTransform(149.05,263.35);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(423).to({_off:false},0).wait(1).to({y:270.8287,alpha:0.4491},0).wait(1).to({y:273.7002,alpha:0.6049},0).wait(1).to({y:275.6601,alpha:0.7092},0).wait(1).to({y:277.1327,alpha:0.7863},0).wait(1).to({y:278.2804,alpha:0.8454},0).wait(1).to({y:279.1889,alpha:0.8917},0).wait(1).to({y:279.9064,alpha:0.9276},0).wait(1).to({y:280.4644,alpha:0.9551},0).wait(1).to({y:280.8811,alpha:0.9753},0).wait(1).to({y:281.1714,alpha:0.9893},0).wait(1).to({y:281.3428,alpha:0.9973},0).wait(1).to({y:281.4,alpha:1},0).wait(1).to({startPosition:0},0).wait(13));

	// t3_meals
	this.instance_20 = new lib.t3meals("synched",0);
	this.instance_20.setTransform(225.15,264.1);
	this.instance_20.alpha = 0;
	this.instance_20._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(426).to({_off:false},0).wait(1).to({y:271.5787,alpha:0.4491},0).wait(1).to({y:274.4502,alpha:0.6049},0).wait(1).to({y:276.4101,alpha:0.7092},0).wait(1).to({y:277.8827,alpha:0.7863},0).wait(1).to({y:279.0304,alpha:0.8454},0).wait(1).to({y:279.9389,alpha:0.8917},0).wait(1).to({y:280.6564,alpha:0.9276},0).wait(1).to({y:281.2144,alpha:0.9551},0).wait(1).to({y:281.6311,alpha:0.9753},0).wait(1).to({y:281.9214,alpha:0.9893},0).wait(1).to({y:282.0928,alpha:0.9973},0).wait(1).to({y:282.15,alpha:1},0).wait(1).to({startPosition:0},0).wait(10));

	// t3_summer
	this.instance_21 = new lib.t3summer("synched",0);
	this.instance_21.setTransform(118,261.85);
	this.instance_21.alpha = 0;
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(429).to({_off:false},0).wait(1).to({regX:0.1,regY:0.1,x:118.1,y:269.4,alpha:0.4491},0).wait(1).to({y:272.3,alpha:0.6049},0).wait(1).to({y:274.25,alpha:0.7092},0).wait(1).to({y:275.7,alpha:0.7863},0).wait(1).to({y:276.85,alpha:0.8454},0).wait(1).to({y:277.75,alpha:0.8917},0).wait(1).to({y:278.5,alpha:0.9276},0).wait(1).to({y:279.05,alpha:0.9551},0).wait(1).to({y:279.45,alpha:0.9753},0).wait(1).to({y:279.75,alpha:0.9893},0).wait(1).to({y:279.9,alpha:0.9973},0).wait(1).to({y:280,alpha:1},0).wait(1).to({regX:0,regY:0,x:118,y:279.9},0).wait(7));

	// t3_free
	this.instance_22 = new lib.t3free("synched",0);
	this.instance_22.setTransform(42.55,262);
	this.instance_22.alpha = 0;
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(431).to({_off:false},0).wait(1).to({y:269.4787,alpha:0.4491},0).wait(1).to({y:272.3502,alpha:0.6049},0).wait(1).to({y:274.3101,alpha:0.7092},0).wait(1).to({y:275.7827,alpha:0.7863},0).wait(1).to({y:276.9304,alpha:0.8454},0).wait(1).to({y:277.8389,alpha:0.8917},0).wait(1).to({y:278.5564,alpha:0.9276},0).wait(1).to({y:279.1144,alpha:0.9551},0).wait(1).to({y:279.5311,alpha:0.9753},0).wait(1).to({y:279.8214,alpha:0.9893},0).wait(1).to({y:279.9928,alpha:0.9973},0).wait(1).to({y:280.05,alpha:1},0).wait(1).to({startPosition:0},0).wait(5));

	// t3_button
	this.instance_23 = new lib.t3button("synched",0);
	this.instance_23.setTransform(150,330.15);
	this.instance_23.alpha = 0;
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(433).to({_off:false},0).wait(1).to({y:337.6287,alpha:0.4491},0).wait(1).to({y:340.5002,alpha:0.6049},0).wait(1).to({y:342.4601,alpha:0.7092},0).wait(1).to({y:343.9327,alpha:0.7863},0).wait(1).to({y:345.0804,alpha:0.8454},0).wait(1).to({y:345.9889,alpha:0.8917},0).wait(1).to({y:346.7064,alpha:0.9276},0).wait(1).to({y:347.2644,alpha:0.9551},0).wait(1).to({y:347.6811,alpha:0.9753},0).wait(1).to({y:347.9714,alpha:0.9893},0).wait(1).to({y:348.1428,alpha:0.9973},0).wait(1).to({y:348.2,alpha:1},0).wait(1).to({startPosition:0},0).wait(3));

	// t2_logos
	this.instance_24 = new lib.t2logos("synched",0);
	this.instance_24.setTransform(152.65,631.7);
	this.instance_24.alpha = 0;
	this.instance_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(261).to({_off:false},0).wait(1).to({x:152.6375,y:605.1827,alpha:0.4491},0).wait(1).to({x:152.625,y:595.0013,alpha:0.6049},0).wait(1).to({x:152.6125,y:588.052,alpha:0.7092},0).wait(1).to({x:152.6,y:582.8307,alpha:0.7863},0).wait(1).to({x:152.5875,y:578.7613,alpha:0.8454},0).wait(1).to({x:152.575,y:575.54,alpha:0.8917},0).wait(1).to({x:152.5625,y:572.996,alpha:0.9276},0).wait(1).to({x:152.55,y:571.0173,alpha:0.9551},0).wait(1).to({x:152.5375,y:569.54,alpha:0.9753},0).wait(1).to({x:152.525,y:568.5107,alpha:0.9893},0).wait(1).to({x:152.5125,y:567.9027,alpha:0.9973},0).wait(1).to({x:152.5,y:567.7,alpha:1},0).wait(1).to({startPosition:0},0).wait(175));

	// t2_
	this.instance_25 = new lib.t2("synched",0);
	this.instance_25.setTransform(153.1,275.25);
	this.instance_25.alpha = 0;
	this.instance_25._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(245).to({_off:false},0).wait(1).to({regY:0.1,y:282.8,alpha:0.4491},0).wait(1).to({y:285.7,alpha:0.6049},0).wait(1).to({y:287.65,alpha:0.7092},0).wait(1).to({y:289.1,alpha:0.7863},0).wait(1).to({y:290.25,alpha:0.8454},0).wait(1).to({y:291.15,alpha:0.8917},0).wait(1).to({y:291.9,alpha:0.9276},0).wait(1).to({y:292.45,alpha:0.9551},0).wait(1).to({y:292.85,alpha:0.9753},0).wait(1).to({y:293.15,alpha:0.9893},0).wait(1).to({y:293.3,alpha:0.9973},0).wait(1).to({y:293.4,alpha:1},0).wait(1).to({regY:0,y:293.3},0).wait(150).to({startPosition:0},0).wait(1).to({regY:0.1,y:293.35,alpha:0.9982},0).wait(1).to({y:293.25,alpha:0.9923},0).wait(1).to({y:293.15,alpha:0.9816},0).wait(1).to({y:292.9,alpha:0.9652},0).wait(1).to({y:292.65,alpha:0.9419},0).wait(1).to({y:292.2,alpha:0.9101},0).wait(1).to({y:291.7,alpha:0.8676},0).wait(1).to({y:291,alpha:0.8113},0).wait(1).to({y:290.1,alpha:0.7365},0).wait(1).to({y:288.95,alpha:0.6361},0).wait(1).to({y:287.35,alpha:0.4978},0).wait(1).to({y:285.2,alpha:0.2998},0).wait(1).to({y:281.95,alpha:0},0).to({_off:true},1).wait(27));

	// t1
	this.instance_26 = new lib.t1("synched",0);
	this.instance_26.setTransform(147.05,304.9);
	this.instance_26.alpha = 0;
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(137).to({_off:false},0).wait(1).to({alpha:0.1},0).wait(1).to({alpha:0.2},0).wait(1).to({alpha:0.3},0).wait(1).to({alpha:0.4},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.6},0).wait(1).to({alpha:0.7},0).wait(1).to({alpha:0.8},0).wait(1).to({alpha:0.9},0).wait(1).to({alpha:1},0).wait(1).to({startPosition:0},0).wait(80).to({startPosition:0},0).wait(1).to({y:304.8762,alpha:0.9982},0).wait(1).to({y:304.7987,alpha:0.9923},0).wait(1).to({y:304.6596,alpha:0.9816},0).wait(1).to({y:304.4482,alpha:0.9652},0).wait(1).to({y:304.1505,alpha:0.9419},0).wait(1).to({y:303.7488,alpha:0.9101},0).wait(1).to({y:303.2195,alpha:0.8676},0).wait(1).to({y:302.5307,alpha:0.8113},0).wait(1).to({y:301.635,alpha:0.7365},0).wait(1).to({y:300.4618,alpha:0.6361},0).wait(1).to({y:298.8958,alpha:0.4978},0).wait(1).to({y:296.7212,alpha:0.2998},0).wait(1).to({y:293.45,alpha:0},0).to({_off:true},1).wait(207));

	// t1_save
	this.instance_27 = new lib.txt_save("synched",0);
	this.instance_27.setTransform(149.25,295.95,1.2311,1.2311);

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(124).to({startPosition:0},0).to({alpha:0},12,cjs.Ease.quadInOut).to({_off:true},1).wait(312));

	// background
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ECF8FD").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_1.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(449));

	// stageBackground
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("EgY/gwbMAx/AAAMAAABg3Mgx/AAAg");
	this.shape_2.setTransform(150,300);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("EgY/AwcMAAAhg3MAx/AAAMAAABg3g");
	this.shape_3.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).wait(449));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(47.2,197.6,382.2,491.9);
// library properties:
lib.properties = {
	id: '74284D70B1C74A4D92B57D17B2E4E9DF',
	width: 300,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/fsm_digital_300x600_v2_atlas_1.png", id:"fsm_digital_300x600_v2_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['74284D70B1C74A4D92B57D17B2E4E9DF'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;