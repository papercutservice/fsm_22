(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"fsm_digital_300x50_v1_atlas_1", frames: [[291,110,108,21],[291,80,122,28],[474,124,55,21],[0,80,289,53],[563,43,240,102],[563,0,1040,41],[0,0,561,78],[1605,0,433,70],[519,80,32,27],[415,80,57,49],[474,80,43,42]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CachedBmp_119 = function() {
	this.initialize(ss["fsm_digital_300x50_v1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_118 = function() {
	this.initialize(ss["fsm_digital_300x50_v1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_117 = function() {
	this.initialize(ss["fsm_digital_300x50_v1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_116 = function() {
	this.initialize(ss["fsm_digital_300x50_v1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_115 = function() {
	this.initialize(ss["fsm_digital_300x50_v1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_114 = function() {
	this.initialize(ss["fsm_digital_300x50_v1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_113 = function() {
	this.initialize(ss["fsm_digital_300x50_v1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_112 = function() {
	this.initialize(ss["fsm_digital_300x50_v1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_111 = function() {
	this.initialize(ss["fsm_digital_300x50_v1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_110 = function() {
	this.initialize(ss["fsm_digital_300x50_v1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_109 = function() {
	this.initialize(ss["fsm_digital_300x50_v1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t3summer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_summer
	this.instance = new lib.CachedBmp_119();
	this.instance.setTransform(-26.95,-5.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.9,-5.2,54,10.5);


(lib.t3meals = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_meals
	this.instance = new lib.CachedBmp_118();
	this.instance.setTransform(-30.6,-6.9,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-30.6,-6.9,61,14);


(lib.t3free = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_free
	this.instance = new lib.CachedBmp_117();
	this.instance.setTransform(-13.65,-5.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.6,-5.1,27.5,10.5);


(lib.t3bars = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt3_bars
	this.instance = new lib.CachedBmp_116();
	this.instance.setTransform(-72.15,-13.3,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-72.1,-13.3,144.5,26.5);


(lib.t2logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2_logos
	this.instance = new lib.CachedBmp_115();
	this.instance.setTransform(-60,-25.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60,-25.4,120,51);


(lib.t2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt2
	this.instance = new lib.CachedBmp_114();
	this.instance.setTransform(-259.4,-10,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_113();
	this.instance_1.setTransform(-140.2,-19.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-259.4,-19.5,520,39);


(lib.t1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// txt1
	this.instance = new lib.CachedBmp_112();
	this.instance.setTransform(-108.35,-17.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.3,-17.5,216.5,35);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_dark_blue
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#224EA2").s().p("ADFEQQg/gPgmgvIgXgfQgNgSgMgKQgZgWgogIQgYgEg1gCQg5gCgpgGQg1gJgpgSQgvgWgigiQglglgMguQgFgTgCgdIgBgWQgBgOADgJQABgFAFgFIAIgKQANgQAKgKQAXgXAigSQA8ggBKgFQA8gDBFAOQA1ALBJAYQBhAgBAAhQBUAsA0A7QA4A+AKBBQAJA8gfA4QgfA5g4AYQgjAQglAAQgXAAgXgGg");
	this.shape.setTransform(-0.0029,-0.0145);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.5,-27.7,85.1,55.5);


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// shape_red
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EA6241").s().p("Ah8EDQgKgEgKgWQgVgygngrQgSgUgXgTIgWgQIgbgQQgRgKgJgIQgVgUgBghQAAgQAGgUQAPgtAogcQAvggBLgCQAPgBAgACIAIAAQAFgBARACQAjADARgBQARgBAJgFQAJgDAGgEQAQgKAFgNQADgHgCgOQgBgRABgGQABgMAKgKQAKgKAPgEQAUgGAdAGQAiAFAiAQQAIAEATALQAQALAKAEQAVAIAZAbQAUAUAPAXQAcAugFAnQAAAFgCADQgFAYgSALQgHAEgLAEIgSAFQgmAMgqAvQg3A9gPALQgOAKgVALIgkASIhRAvQgxAagmAEIgHABQgHAAgDgCg");
	this.shape.setTransform(-0.0121,0.0042);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,-26.1,68.69999999999999,52.2);


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus
	this.instance = new lib.CachedBmp_111();
	this.instance.setTransform(-8.1,-6.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8.1,-6.8,16,13.5);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_milk
	this.instance = new lib.CachedBmp_110();
	this.instance.setTransform(-14.05,-12.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14,-12.2,28.5,24.5);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_apple
	this.instance = new lib.CachedBmp_109();
	this.instance.setTransform(-10.75,-10.6,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.7,-10.6,21.5,21);


(lib.Path_19 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgNAkQAAgEAEgPIAJgiIAEgTQACgDAEABQAEABAAAEQAAAEgEAOIgIAiQgDAPgCAEQgCACgEAAQgDgBgBgDg");
	this.shape.setTransform(1.3722,3.9389);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_19, new cjs.Rectangle(0,0,2.8,7.9), null);


(lib.Path_18 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgQAtQABgJAEgNIAGgXIALguQABgFAGABQAFACgBAFIgRBDQgCAQgDAHQgBAEgFAAQgFgBAAgFg");
	this.shape.setTransform(1.6811,5.0667);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_18, new cjs.Rectangle(0,0,3.4,10.2), null);


(lib.Path_16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgOAiQAAgMAIgXQADgOAHgSQABgEAGABQAFABgCAFIgLAfIgDAQQgBALgDAGQgBADgEAAIgBAAQgDAAgBgDg");
	this.shape.setTransform(1.4501,3.7687);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_16, new cjs.Rectangle(0,0.1,2.9,7.4), null);


(lib.Path_13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgLAnQgFgBACgFIAThDQABgEAFAAQAFABgBAEQgDAOgGAUIgLAjQgBADgDAAIgCAAg");
	this.shape.setTransform(1.566,3.8822);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_13, new cjs.Rectangle(0,0,3.1,7.8), null);


(lib.Path_9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgUA4QgBAAgBAAQAAAAgBAAQAAgBAAAAQgBgBAAgBQAAgGADgJIAFgOIAKgaQAJgZALgWQgBgEAFgCQADgBACACIABAAQAAABAAAAQABABAAAAQAAAAAAABQAAAAgBABIgdBOIgFAOQgCAIgEAFQAAAAAAABQgBAAAAAAQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape.setTransform(2.47,5.6633);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_9, new cjs.Rectangle(0,0,5,11.3), null);


(lib.Path_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgKAfQgEgBAAgEQAGgYAMgcQACgEAFABQAFABgCAEQgMAagGAaQgBADgEAAIgBAAg");
	this.shape.setTransform(1.4761,3.0931);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6, new cjs.Rectangle(0,0.1,3,6.1000000000000005), null);


(lib.Path_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2DB6A8").s().p("AgSA0QgEgCABgEIAhheQABgEAFABQAFABgBAFQgIAcgIAUIgIAZIgKAWQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAIgDgBg");
	this.shape.setTransform(2.1733,5.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0,0,4.4,10.5), null);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// illus_lines
	this.instance = new lib.Path_3();
	this.instance.setTransform(18.25,5.8,1,1,0,0,0,2.1,5.2);
	this.instance.compositeOperation = "multiply";

	this.instance_1 = new lib.Path_6();
	this.instance_1.setTransform(13.55,-1.45,1,1,0,0,0,1.4,3.1);
	this.instance_1.compositeOperation = "multiply";

	this.instance_2 = new lib.Path_9();
	this.instance_2.setTransform(5.35,-1.2,1,1,0,0,0,2.5,5.7);
	this.instance_2.compositeOperation = "multiply";

	this.instance_3 = new lib.Path_13();
	this.instance_3.setTransform(-3.35,-0.1,1,1,0,0,0,1.6,3.9);
	this.instance_3.compositeOperation = "multiply";

	this.instance_4 = new lib.Path_16();
	this.instance_4.setTransform(-10.05,-3.55,1,1,0,0,0,1.4,3.8);
	this.instance_4.compositeOperation = "multiply";

	this.instance_5 = new lib.Path_18();
	this.instance_5.setTransform(-18.75,4.75,1,1,0,0,0,1.7,5);
	this.instance_5.compositeOperation = "multiply";

	this.instance_6 = new lib.Path_19();
	this.instance_6.setTransform(-16,-7.05,1,1,0,0,0,1.4,4);
	this.instance_6.compositeOperation = "multiply";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(449));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20.4,-11,40.9,22.1);


// stage content:
(lib.fsm_digital_300x50_v1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [448];
	// timeline functions:
	this.frame_448 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(448).call(this.frame_448).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A3bD6IAAnzMAu3AAAIAAHzgA3YD4MAuxAAAIAAnuMguxAAAg");
	this.shape.setTransform(150,25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(449));

	// Symbol_1
	this.instance = new lib.Symbol1("synched",0);
	this.instance.setTransform(3.15,-18.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:20.75,y:16.6,startPosition:29},29,cjs.Ease.quartInOut).to({rotation:14.9992,x:17.05,y:16.5,startPosition:159},130,cjs.Ease.quadInOut).to({x:6.4,y:16.6,startPosition:188},29,cjs.Ease.quartInOut).to({regX:0.1,regY:0.1,rotation:29.9984,x:10.95,y:9.55,startPosition:393},205,cjs.Ease.quadInOut).to({regX:0,regY:0,rotation:14.9992,x:-21.4,y:-10,startPosition:431},38,cjs.Ease.quartInOut).wait(18));

	// Symbol_2
	this.instance_1 = new lib.Symbol2("synched",0);
	this.instance_1.setTransform(290.45,-16.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:281.4,y:15.4,startPosition:29},29,cjs.Ease.quartInOut).to({rotation:-14.9992,x:279.35,y:15.65,startPosition:159},130,cjs.Ease.quadInOut).to({x:290.55,y:8.1,startPosition:188},29,cjs.Ease.quartInOut).to({regX:0.1,regY:0.1,rotation:-29.9984,x:291.45,y:14.1,startPosition:393},205,cjs.Ease.quadInOut).to({regX:0,regY:0,rotation:-14.9992,x:320.95,y:-2.8,startPosition:431},38,cjs.Ease.quartInOut).wait(18));

	// Symbol_3
	this.instance_2 = new lib.Symbol3("synched",0);
	this.instance_2.setTransform(77.55,57.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({y:45,startPosition:29},29,cjs.Ease.quartInOut).to({x:82.85,y:49.75,startPosition:159},130,cjs.Ease.quadInOut).to({x:73.5,y:64.45,startPosition:188},29,cjs.Ease.quartInOut).to({startPosition:393},205,cjs.Ease.quadInOut).to({startPosition:431},38,cjs.Ease.quartInOut).wait(18));

	// Symbol_4
	this.instance_3 = new lib.Symbol4("synched",0);
	this.instance_3.setTransform(183.25,63.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:191.45,y:41.4,startPosition:29},29,cjs.Ease.quartInOut).to({rotation:-14.9992,x:198.85,y:41.35,startPosition:159},130,cjs.Ease.quadInOut).to({rotation:0,x:191.45,y:60.25,startPosition:188},29,cjs.Ease.quartInOut).to({startPosition:393},205,cjs.Ease.quadInOut).to({startPosition:431},38,cjs.Ease.quartInOut).wait(18));

	// Symbol_5
	this.instance_4 = new lib.Symbol5("synched",0);
	this.instance_4.setTransform(293.8,59);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({x:283.25,y:53.2,startPosition:29},29,cjs.Ease.quartInOut).to({rotation:-6.4746,x:288.15,y:53.8,startPosition:159},130,cjs.Ease.quadInOut).to({rotation:-5.9663,x:290.6,y:56.7,startPosition:188},29,cjs.Ease.quartInOut).to({rotation:1.4751,x:284.5,y:56.65,startPosition:393},205,cjs.Ease.quadInOut).to({rotation:-50.9654,x:329.95,y:32.4,startPosition:431},38,cjs.Ease.quartInOut).wait(18));

	// Symbol_6
	this.instance_5 = new lib.Symbol6("synched",0);
	this.instance_5.setTransform(-17.95,51.55);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:-9.3,y:46.45,startPosition:29},29,cjs.Ease.quartInOut).to({rotation:-5.447,x:-2.25,y:49.75,startPosition:159},130,cjs.Ease.quadInOut).to({rotation:14.9992,x:-16.75,y:48.4,startPosition:188},29,cjs.Ease.quartInOut).to({rotation:9.787,x:-4.5,y:52.5,startPosition:393},205,cjs.Ease.quadInOut).to({rotation:59.998,x:-31.15,y:24.8,startPosition:431},38,cjs.Ease.quartInOut).wait(18));

	// t3_bars
	this.instance_6 = new lib.t3bars("synched",0);
	this.instance_6.setTransform(92.7,7.5);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(428).to({_off:false},0).wait(1).to({regX:0.1,x:92.8,y:14.95,alpha:0.4491},0).wait(1).to({y:17.85,alpha:0.6049},0).wait(1).to({y:19.8,alpha:0.7092},0).wait(1).to({y:21.25,alpha:0.7863},0).wait(1).to({y:22.4,alpha:0.8454},0).wait(1).to({y:23.3,alpha:0.8917},0).wait(1).to({y:24.05,alpha:0.9276},0).wait(1).to({y:24.6,alpha:0.9551},0).wait(1).to({y:25,alpha:0.9753},0).wait(1).to({y:25.3,alpha:0.9893},0).wait(1).to({y:25.45,alpha:0.9973},0).wait(1).to({y:25.55,alpha:1},0).wait(1).to({regX:0,x:92.7},0).wait(7).to({startPosition:0},0).wait(1));

	// t3_meals
	this.instance_7 = new lib.t3meals("synched",0);
	this.instance_7.setTransform(134.25,7.9);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(426).to({_off:false},0).wait(1).to({regX:-0.1,regY:0.1,x:134.15,y:15.45,alpha:0.4491},0).wait(1).to({y:18.35,alpha:0.6049},0).wait(1).to({y:20.3,alpha:0.7092},0).wait(1).to({y:21.75,alpha:0.7863},0).wait(1).to({y:22.9,alpha:0.8454},0).wait(1).to({y:23.8,alpha:0.8917},0).wait(1).to({y:24.55,alpha:0.9276},0).wait(1).to({y:25.1,alpha:0.9551},0).wait(1).to({y:25.5,alpha:0.9753},0).wait(1).to({y:25.8,alpha:0.9893},0).wait(1).to({y:25.95,alpha:0.9973},0).wait(1).to({y:26.05,alpha:1},0).wait(1).to({regX:0,regY:0,x:134.25,y:25.95},0).wait(9).to({startPosition:0},0).wait(1));

	// t3_summer
	this.instance_8 = new lib.t3summer("synched",0);
	this.instance_8.setTransform(75.75,6.7);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(424).to({_off:false},0).wait(1).to({y:14.1787,alpha:0.4491},0).wait(1).to({y:17.0502,alpha:0.6049},0).wait(1).to({y:19.0101,alpha:0.7092},0).wait(1).to({y:20.4827,alpha:0.7863},0).wait(1).to({y:21.6304,alpha:0.8454},0).wait(1).to({y:22.5389,alpha:0.8917},0).wait(1).to({y:23.2564,alpha:0.9276},0).wait(1).to({y:23.8144,alpha:0.9551},0).wait(1).to({y:24.2311,alpha:0.9753},0).wait(1).to({y:24.5214,alpha:0.9893},0).wait(1).to({y:24.6928,alpha:0.9973},0).wait(1).to({y:24.75,alpha:1},0).wait(1).to({startPosition:0},0).wait(11).to({startPosition:0},0).wait(1));

	// t3_free
	this.instance_9 = new lib.t3free("synched",0);
	this.instance_9.setTransform(34.6,6.75);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(419).to({_off:false},0).wait(1).to({regX:0.1,regY:0.1,x:34.7,y:14.3,alpha:0.4491},0).wait(1).to({y:17.2,alpha:0.6049},0).wait(1).to({y:19.15,alpha:0.7092},0).wait(1).to({y:20.6,alpha:0.7863},0).wait(1).to({y:21.75,alpha:0.8454},0).wait(1).to({y:22.65,alpha:0.8917},0).wait(1).to({y:23.4,alpha:0.9276},0).wait(1).to({y:23.95,alpha:0.9551},0).wait(1).to({y:24.35,alpha:0.9753},0).wait(1).to({y:24.65,alpha:0.9893},0).wait(1).to({y:24.8,alpha:0.9973},0).wait(1).to({y:24.9,alpha:1},0).wait(1).to({regX:0,regY:0,x:34.6,y:24.8},0).wait(16).to({startPosition:0},0).wait(1));

	// t2_logo
	this.instance_10 = new lib.t2logo("synched",0);
	this.instance_10.setTransform(297.4,25.05);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(428).to({_off:false},0).wait(1).to({regY:0.1,x:292.7,y:25.45,alpha:0.4491},0).wait(1).to({x:288,y:25.55,alpha:0.6049},0).wait(1).to({x:283.3,y:25.65,alpha:0.7092},0).wait(1).to({x:278.6,y:25.7,alpha:0.7863},0).wait(1).to({x:273.9,y:25.75,alpha:0.8454},0).wait(1).to({x:269.25,y:25.8,alpha:0.8917},0).wait(1).to({x:264.55,alpha:0.9276},0).wait(1).to({x:259.85,y:25.85,alpha:0.9551},0).wait(1).to({x:255.15,alpha:0.9753},0).wait(1).to({x:250.45,alpha:0.9893},0).wait(1).to({x:245.75,alpha:0.9973},0).wait(1).to({x:241.1,y:25.9,alpha:1},0).wait(1).to({regY:0,y:25.8},0).wait(7).to({startPosition:0},0).wait(1));

	// t2
	this.instance_11 = new lib.t2("synched",0);
	this.instance_11.setTransform(150,6.95);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(180).to({_off:false},0).wait(1).to({regX:0.6,x:150.6,y:14.4,alpha:0.4491},0).wait(1).to({y:17.3,alpha:0.6049},0).wait(1).to({y:19.25,alpha:0.7092},0).wait(1).to({y:20.7,alpha:0.7863},0).wait(1).to({y:21.85,alpha:0.8454},0).wait(1).to({y:22.75,alpha:0.8917},0).wait(1).to({y:23.5,alpha:0.9276},0).wait(1).to({y:24.05,alpha:0.9551},0).wait(1).to({y:24.45,alpha:0.9753},0).wait(1).to({y:24.75,alpha:0.9893},0).wait(1).to({y:24.9,alpha:0.9973},0).wait(1).to({y:25,alpha:1},0).wait(1).to({regX:0,x:150},0).wait(198).to({startPosition:0},0).wait(1).to({regX:0.6,x:150.6,y:24.95,alpha:0.9982},0).wait(1).to({y:24.85,alpha:0.9923},0).wait(1).to({y:24.75,alpha:0.9816},0).wait(1).to({y:24.5,alpha:0.9652},0).wait(1).to({y:24.25,alpha:0.9419},0).wait(1).to({y:23.8,alpha:0.9101},0).wait(1).to({y:23.3,alpha:0.8676},0).wait(1).to({y:22.6,alpha:0.8113},0).wait(1).to({y:21.7,alpha:0.7365},0).wait(1).to({y:20.55,alpha:0.6361},0).wait(1).to({y:18.95,alpha:0.4978},0).wait(1).to({y:16.8,alpha:0.2998},0).wait(1).to({y:13.55,alpha:0},0).to({_off:true},1).wait(44));

	// t1
	this.instance_12 = new lib.t1("synched",0);
	this.instance_12.setTransform(151.1,26.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(150).to({startPosition:0},0).wait(1).to({y:26.5762,alpha:0.9982},0).wait(1).to({y:26.4987,alpha:0.9923},0).wait(1).to({y:26.3596,alpha:0.9816},0).wait(1).to({y:26.1482,alpha:0.9652},0).wait(1).to({y:25.8505,alpha:0.9419},0).wait(1).to({y:25.4488,alpha:0.9101},0).wait(1).to({y:24.9195,alpha:0.8676},0).wait(1).to({y:24.2307,alpha:0.8113},0).wait(1).to({y:23.335,alpha:0.7365},0).wait(1).to({y:22.1618,alpha:0.6361},0).wait(1).to({y:20.5958,alpha:0.4978},0).wait(1).to({y:18.4212,alpha:0.2998},0).wait(1).to({y:15.15,alpha:0},0).to({_off:true},1).wait(285));

	// background
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#ECF8FD").s().p("A3bD6IAAnzMAu3AAAIAAHzg");
	this.shape_1.setTransform(150,25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(449));

	// stageBackground
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("A4/ldMAx/AAAIAAK7Mgx/AAAg");
	this.shape_2.setTransform(150,25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("A4/FeIAAq7MAx/AAAIAAK7g");
	this.shape_3.setTransform(150,25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).wait(449));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(40.6,-3.8,370,88.89999999999999);
// library properties:
lib.properties = {
	id: 'AA316231177AB94095E3A7FF317F2E2F',
	width: 300,
	height: 50,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/fsm_digital_300x50_v1_atlas_1.png", id:"fsm_digital_300x50_v1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['AA316231177AB94095E3A7FF317F2E2F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;